<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);

    if (isset($_SESSION['editmode']) && ($_SESSION['editmode'] == 'SUPER' || $_SESSION['editmode'] <> 'TRUE')) {
        include_once 'includes/access_isset.php';
    }

    include_once 'config.php';
    include_once 'includes/functions.php';

    if (isset($_GET["det"]) && is_numeric($_GET["det"])) {
        $get_id_det = $_GET["det"] ?? 0;
    } else {
        $get_id_det = 0;
    }
        
    $get_scstr = $_GET["scstr"] ?? '';
    $get_infname = $_GET["infname"] ??'';
    $get_page = $_GET["page"] ?? 0;
    $get_sctype = $_GET["sctype"] ?? 0;

    $query1 = "select * from eg_bahan where id='$get_id_det'";
    $result1 = mysqli_query($GLOBALS["conn"], $query1);
    $num_results_affected = mysqli_num_rows($result1);

    if ($num_results_affected <= 0) {
        echo "<html><body><div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>ERROR</strong></span><h2>Error: Item not exist.</h2><em>System Response Code</em></div></body></html>";
        exit;
    }

    $myrow = mysqli_fetch_array($result1);
        $id5=$myrow["id"] ?? '';
        $tajuk5=$myrow["38title"] ?? '';
        $location5=$myrow["38location"] ?? '';
        $link5=$myrow["38link"] ?? '';
        $isbn5 = $myrow["38isbn"] ?? '';
        $issn5 = $myrow["38issn"] ?? '';
        $edition5 = $myrow["38edition"] ?? '';
        $publication5 = $myrow["38publication"] ?? '';
        $physicaldesc5 = $myrow["38physicaldesc"] ?? '';
        $series5 = $myrow["38series"] ?? '';
        $notes5 = $myrow["38notes"] ?? '';
        $source5 = $myrow["38source"] ?? '';
        $pengarang5=$myrow["38author"] ?? '';
        $callnumber5=$myrow["38localcallnum"] ?? '';
        $jenis5=$myrow["39type"] ?? '';
        $subjectheading5 =$myrow["39subjectheading"] ?? '';
        $imageatt5=$myrow["39imageatt"] ?? '';
        $pdfattach5=$myrow["39pdfattach"] ?? '';
        $tarikh_masuk5=$myrow["40inputdate"] ?? '';
        $input_oleh5=$myrow["40inputby"] ?? '';
        $lastupdateby5=$myrow["40lastupdateby"] ?? '';
        $instimestamp5 =$myrow["40instimestamp"] ?? '';
        $hits5=$myrow["41hits"] ?? '';
        $language5=$myrow["39language"] ?? '';
        
        $query2 = "select * from eg_bahan2 where eg_bahan_id = $get_id_det";
        $result2 = mysqli_query($GLOBALS["conn"], $query2);
        $myrow2=mysqli_fetch_array($result2);
            $callnum5_b=$myrow2["38localcallnum_b"] ?? '';
            $pengarang5_d=$myrow2["38author_d"] ?? '';
            $tajuk5_b=$myrow2["38title_b"] ?? '';
            $tajuk5_c=$myrow2["38title_c"] ?? '';
            $publication5_b=$myrow2["38publication_b"] ?? '';
            $publication5_c=$myrow2["38publication_c"] ?? '';
            $physicaldesc5_b=$myrow2["38physicaldesc_b"] ?? '';
            $physicaldesc5_c=$myrow2["38physicaldesc_c"] ?? '';
            $physicaldesc5_e=$myrow2["38physicaldesc_e"] ?? '';
            $series5_v=$myrow2["38series_v"] ?? '';
            $sumber5_b=$myrow2["38source_b"] ?? '';
            $sumber5_e=$myrow2["38source_e"] ?? '';
            $lokasi5_b=$myrow2["38location_b"] ?? '';
            $lokasi5_c=$myrow2["38location_c"] ?? '';
?>
<html lang='en'>

<head>

    <title><?php echo $product_name;?> : Record Details Administration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
    <script>
        function openPopup(url) {
         window.open(url, "popup_id", "scrollbars=yes,resizable=no,width=890,height=580");
         return false;
        }
    </script>
    
    <script language="javascript" type="text/javascript">
    function popupCopies(url) {
        newwindow=window.open(url,'name','height=500,width=480');
        if (window.focus) {newwindow.focus()}
        return false;
    }
    </script>
    
</head>

<body>

    <?php
        include_once 'includes/loggedinfo.php';
    ?>
    
    <hr>

    <div style='width:100%;text-align:center;'>
        <?php
                echo "<table border='0' style='width:100%;' bgcolor='white'>";
                        echo "<tr bgcolor=#FFFE96 align=center><td colspan=2><b>Record Details</b> : </td></tr>";
                        echo "<tr><td width=150 align='right'><b>Control Number :</b></td><td bgcolor=white style='text-align:left;'>$id5</td></tr>";
                        echo "<tr><td align='right'><b>Hits :</b></td><td style='text-align:left;'>";
                            if (isset($_SESSION['editmode']) && $_SESSION['editmode'] == 'SUPER') {
                                echo "<a title='Hits for $id5' target='_blank' href='reports/adsreport_ipitems.php?det=$id5'>$hits5</a>";
                            } else {
                                echo "$hits5";
                            }
                        echo "</td></tr>";
                        
                        echo "<tr><td align='right'><b>Type :</b></td><td bgcolor=white style='text-align:left;'>".idToType($jenis5)."</td></tr>";
                    
                        if ($subjectheading5 <> null) {
                            $subjectheadings = explode("|", $subjectheading5);
                            $total = count($subjectheadings) - 1;
                            $i = 1;$returnSH='';
                            foreach ($subjectheadings as $subjectheading) {
                                $subjectheading = trim($subjectheading);
                                $returnSH .= subjectFromAcronym($subjectheading) ?? '';
                                if ($i < $total) {$returnSH .= "<br/>";}
                                $i=$i+1;
                            }
                            echo "<tr><td align='right' valign=top><b>Subject Heading:</b></td><td bgcolor=white style='text-align:left;'>$returnSH</td></tr>";
                        }
                        
                        if ($isbn5 != '') {
                            echo "<tr><td align='right'><b>ISBN :</b></td><td bgcolor=white style='text-align:left;'>$isbn5</td></tr>";
                        }

                        if ($issn5 != '') {
                            echo "<tr><td align='right'><b>ISSN :</b></td><td bgcolor=white style='text-align:left;'>$issn5</td></tr>";
                        }

                        if ($language5 != '') {
                            echo "<tr><td align='right'><b>Language :</b></td><td bgcolor=white style='text-align:left;'>$language5</td></tr>";
                        }

                        if ($callnumber5 != '') {
                            echo "<tr><td align='right'><b>Call number :</b></td><td bgcolor=white style='text-align:left;'>$callnumber5 $callnum5_b</td></tr>";
                        }

                        if ($pengarang5 != '') {
                            echo "<tr><td align='right'><b>Author :</b></td><td bgcolor=white style='text-align:left;'>$pengarang5</td></tr>";
                        }

                        echo "<tr><td align='right'><b>Title :</b></td><td bgcolor=white style='text-align:left;'>$tajuk5 / $tajuk5_b $tajuk5_c</td></tr>";
                        
                        if ($edition5 != '') {
                            echo "<tr><td align='right'><b>Edition :</b></td><td bgcolor=white style='text-align:left;'>$edition5</td></tr>";
                        }

                        if ($publication5 != '') {
                            echo "<tr><td align='right'><b>Publication :</b></td><td bgcolor=white style='text-align:left;'>$publication5 : $publication5_b $publication5_c</td></tr>";
                        }

                        if ($physicaldesc5 != '') {
                            echo "<tr><td align='right'><b>Physical Description :</b></td><td bgcolor=white style='text-align:left;'>$physicaldesc5 ;$physicaldesc5_b $physicaldesc5_c $physicaldesc5_e</td></tr>";
                        }

                        if ($series5 != '') {
                            echo "<tr><td align='right'><b>Series :</b></td><td bgcolor=white style='text-align:left;'>$series5</td></tr>";
                        }

                        if ($notes5 != '') {
                            echo "<tr><td align='right'><b>Notes :</b></td><td bgcolor=white style='text-align:left;'>$notes5</td></tr>";
                        }
            
                        if ($source5 != '') {
                            echo "<tr><td align='right'><b>Corporate Name :</b></td><td bgcolor=white style='text-align:left;'>$source5</td></tr>";
                        }
                        
                        if ($location5 != '') {
                            echo "<tr><td align='right'><b>Location :</b></td><td bgcolor=white style='text-align:left;'>$location5</td></tr>";
                        }
                                                            
                        if ($link5 <> null) {
                            $link5 = urldecode($link5);
                            
                            if (substr($link5, 0, 4) != 'http') {$link5 = 'http://'.$link5;}
                            
                            echo "<tr><td align='right'><b>Web Link :</b></td><td bgcolor=white style='text-align:left;'><a href='$link5' target='_blank'>$link5</a></td></tr>";
                        }
                        
                        $dir_year5 = substr("$tarikh_masuk5", -4);
                                                        
                        if ($pdfattach5 == 'TRUE') {
                            if (is_file("$pdf_upload_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf")) {
                                echo "<tr><td align='right'><b>PDF File :</b></td><td bgcolor=white style='text-align:left;'><a href='$pdf_upload_directory/$dir_year5/$id5"."_"."$instimestamp5.pdf' target='_blank'>$id5"."_"."$instimestamp5.pdf</a></td></tr>";
                            } else {
                                echo "<tr><td align='right'><b>PDF File :</b></td><td bgcolor=white style='text-align:left;'>$id5"."_"."$instimestamp5.pdf <em>(This file appear to be missing. Need urgent attention.)</em></td></tr>";
                            }
                        }
                    
                        if ($imageatt5 == 'TRUE') {
                            if (is_file("$cover_upload_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg")) {
                                echo "<tr><td align='right'><b>JPG Related Image :</b></td><td bgcolor=white style='text-align:left;'><a target='_blank' href='$cover_upload_directory/$dir_year5/$id5"."_"."$instimestamp5.jpg' title='$tajuk5'>$id5"."_"."$instimestamp5.jpg</a></td></tr>";
                            } else {
                                echo "<tr><td align='right'><b>JPG Related Image :</b></td><td bgcolor=white style='text-align:left;'>$id5"."_"."$instimestamp5.jpg <em>(This image appear to be missing. Need urgent attention.)</em></td></tr>";
                            }
                        }
                echo "</table>";

                echo "<br/><table width=100% border=0 bgcolor=white>";
                        //copies section
                        if (isset($_SESSION['editmode']) && ($_SESSION['editmode'] == 'SUPER' || $_SESSION['editmode'] == 'TRUE')) {
                            echo "<tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'>";
                                echo "<b>Copies</b> : ";
                                echo "<input type=button value='Add new copies' onclick=\"return popupCopies('admin/copies_add.php?bahan_id=$id5')\"> ";
                                echo "<input type=button onClick=\"document.location.reload(true)\" value=Refresh> ";
                            echo "</td></tr>";
                            $queryC = "select * from eg_bahan_copies where eg_bahan_id='$id5'";
                            $resultC = mysqli_query($GLOBALS["conn"], $queryC);
                            while ($myrowC=mysqli_fetch_array($resultC)) {
                                echo "<tr>";
                                    $copies_id=$myrowC["id"];
                                    $copies_accession_number=$myrowC["39accessnum"];
                                    $copies_status=$myrowC["39status"];
                                    $copies_addedon=$myrowC["39addedon"];
                                    $copies_lastchange=$myrowC["39lastchange"];
                                    $copies_invoice_a=$myrowC["39invoice_a"];
                                    $copies_invoice_b=$myrowC["39invoice_b"];
                                    $copies_invoice_c=$myrowC["39invoice_c"];

                                    echo "<td valign=top align=right>";
                                        echo "$copies_accession_number";
                                        if ($copies_status != 'CIRCULATED') {
                                            echo "<br/><input type=button value='Delete' onclick=\"return popupCopies('admin/copies_delete.php?id=$copies_id')\">";
                                        }
                                    echo "</td>";
                                    echo "<td style='text-align:left;'>";
                                        echo "$copies_status ";
                                        echo " <input type='button' value='Change' onclick=\"window.open('admin/change_status.php?cid=$copies_id','windowName', 'width=480,height=320,scrollbars=no')\"><br/>";
                                            echo "Price: $currency_SHORT".$copies_invoice_a." | Supplier: ".$copies_invoice_b." | Invoice Number: ".$copies_invoice_c."<br/>";
                                            echo "Added : ".date('D, Y-m-d h:i:s a', $copies_addedon)."<br/>Changed : ".date('D, Y-m-d h:i:s a', $copies_lastchange);
                                    echo "</td>";
                                echo "</tr>";
                            }
                                                
                            echo "<tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Administrative</b></td></tr>";
                            echo "<tr bgcolor='D2FFF9'><td align='right' style='width:150px;'><b>Input date :</b></td><td style='text-align:left;'>$tarikh_masuk5</td></tr>";
                            echo "<tr bgcolor='D2FFF9'><td align='right'><b>Input by : </b></td><td style='text-align:left;'>".patronUsernametoName($input_oleh5)."</td></tr>";
                            
                            if (isset($_SESSION['editmode']) && $_SESSION['editmode'] == 'SUPER') {
                                echo "<tr bgcolor='D2FFF9'><td align='right'><b>Last update by : </b></td><td style='text-align:left;'>".patronUsernametoName($lastupdateby5)."</td></tr>";
                            }
                                
                            echo "<tr bgcolor='D2FFF9'><td align='right'><b>Option :</b></td><td style='text-align:left;'>";
            
                            if ($_SESSION['editmode'] == 'SUPER') {
                                    if (isset($_GET['delr']) && $_GET['delr'] == 'true') {
                                        echo "<a href='delreq.php?del=$id5";
                                    } elseif (isset($_GET['delr']) && $_GET['delr'] == 'rep') {
                                        echo "<a href='reports/adsreport_details.php?del=$id5&inf=$input_oleh5&infname=$get_infname&page=$get_page";
                                    } elseif (isset($_GET['delr']) && $_GET['delr'] == 'urep') {
                                        echo "<a href='reports/adsreport_details_user.php?del=$id5&inf=$input_oleh5&infname=$get_infname&page=$get_page";
                                    } elseif (isset($_GET['delr']) && $_GET['delr'] == 'sjdir') {
                                        echo "<a href='browsers/subject_details.php?del=$id5&subid=".$_GET['subid']."&page=".$_GET['page'];
                                    } else {
                                        echo "<a href='index2.php?del=$id5";
                                        if (isset($_GET['scstr'])) {
                                            echo "&scstr=".$_GET['scstr'];
                                        }
                                        if (isset($_GET['scflag']) && ($_GET['scflag'] != '')) {echo "&scflag=".$_GET['scflag'];}
                                        if (isset($_GET['sctype']) && ($_GET['sctype'] != '')) {echo "&sctype=".$_GET['sctype'];}
                                        echo "&page=$get_page";
                                    }
                                    
                                    if ($pdfattach5 == 'TRUE') {
                                        echo "&delfilename=$dir_year5/$id5"."_"."$instimestamp5";
                                    }
                                    
                                    echo "' onclick=\"return confirm('Are you sure to delete this record ?');\">Delete</a>";
                                } else {
                                    echo "Delete";
                                }
                                
                            //the display of the Update button depends on where details.php is called from
                            if (isset($_GET['delr']) && $_GET['delr'] == 'rep') {
                                echo " | <a onclick=\"return openPopup(this.href);\" href='admin/upd.php?upd=$id5&delr=rep'>Update</a>";
                            } else {
                                echo " | <a onclick=\"return openPopup(this.href);\" href='admin/upd.php?upd=$id5'>Update</a>";
                            }

                            echo "</td></tr>";
                        } else {
                            echo "<tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Copies Availability</b> :</td></tr>";
                            echo "<tr><td style='text-align:right;width:50%;'><u>Acccession Number</u></td><td style='text-align:left;'><u>Current Status</u></td></tr>";
                            $queryC = "select * from eg_bahan_copies where eg_bahan_id='$id5'";
                            $resultC = mysqli_query($GLOBALS["conn"], $queryC);
                            while ($myrowC=mysqli_fetch_array($resultC)) {
                                echo "<tr>";
                                    $copies_id=$myrowC["id"];
                                    $copies_accession_number=$myrowC["39accessnum"];
                                    $copies_status=$myrowC["39status"];
                                    $copies_addedon=$myrowC["39addedon"];
                                    $copies_lastchange=$myrowC["39lastchange"];
                                    echo "<td style='text-align:right;'>$copies_accession_number</td>";
                                    echo "<td style='text-align:left;'>$copies_status</td>";
                                echo "</tr>";
                            }
                        }
                echo "</table><br/>";

                echo "[ <a href=\"javascript:javascript:history.go(-1)\">Back to previous page</a> ]";
            
        ?>
    </div>

    <hr>
        
    <?php include_once './includes/footerbar.php';?>

</body>

</html>
