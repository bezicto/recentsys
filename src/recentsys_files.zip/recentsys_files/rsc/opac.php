<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once 'config.php';
    include_once 'includes/functions.php';
    unset($_SESSION['username']);
    $_SESSION['ref'] = 'opac.php';
    
    require_once './includes/mobiledetect.php';
    $detect = new Mobile_Detect;

    if (isset($_GET["scstr"]) && $_GET["scstr"] <> '') {
        $scstr_value = stripslashes(str_replace('"', '&#34;', $_GET["scstr"]));
    }
?>
<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Guest Mode</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1">
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
    <style>
        #navbar {
        background-color: #333;
        position: fixed;
        top: -100px;
        width: 100%;
        display: block;
        transition: top 0.3s;
        color: white;
        text-align:center;
        }

        #navbar a {
        float: left;
        display: block;
        color: #f2f2f2;
        text-align: center;
        padding: 15px;
        text-decoration: none;
        font-size: 17px;
        }

        #navbar a:hover {
        background-color: #ddd;
        color: black;
        }
    </style>
</head>

<body style='margin:0;'>
    <div id="navbar">
        <form style="margin-left:20px;margin-top:20px;margin-bottom:20px;" action="opac.php" method="get" enctype="multipart/form-data">
        Enter terms: <input type="text" name="scstr" style="width:50%;" maxlength="255" value="<?php echo $scstr_value ?? "";?>"/>
            <input type="hidden" name="sctype" value="All Type" />
            <input type="submit" name="scflag" value="Search" />
        </form>
    </div>
    
    <?php
        include_once './includes/loggedinfo.php';
    ?>
                            
    <div style='text-align:center;width:100%;'>
        <?php
            if (!$detect->isMobile()) {
                include_once './includes/popularkeywords.php';
            }
        ?>
        <br/><em>Enter your search terms and press Search to continue.</em>
        
        <form action="opac.php" method="get" enctype="multipart/form-data">
            <br/><input type="text" name="scstr" style="width:50%;" maxlength="255" value="<?php echo $scstr_value ?? "";?>"/>
            <input type="hidden" name="sctype" value="All Type" />
            <input type="submit" name="scflag" value="Search" />
            <br/><br/>
        </form>
    </div>
                                
    <?php
        include_once './includes/browser_bar.php';
    ?>
        
    <div style='margin-top:auto;text-align:center;width:100%;'>
        <?php
            //start paging 1
            include_once './includes/paging-p1.php';
                    
            $scstr2 = '';
            if ((isset($_GET["scflag"]) && $_GET["scflag"] == 'Search') || (isset($_GET['sctype']) && $_GET['sctype'] <> null)) {
                    $latest1 = "FALSE";
                    $sctype2 = $_GET["sctype"];
                    $scstr2 = $_GET["scstr"];
                    include_once './includes/index2_s_rmvcommonword.php';
                    include_once './includes/index2_insertintostat.php';
                    include_once './includes/index2_s_allseing.php';
                } else {
                    $latest1 = "TRUE";
                    $query1 = "select SQL_CALC_FOUND_ROWS * from eg_bahan order by id desc LIMIT $offset, $rowsPerPage";
                }
                
                $time_start = getmicrotime();
                $result1 = mysqli_query($GLOBALS["conn"], $query1);
                
                //start paging 2
                include_once './includes/paging-p2.php';
    
                $time_end = getmicrotime();
                $time = round($time_end - $time_start, 5);
                
                $sortby = '';
                if ($latest1 == "FALSE") {
                    echo "<table bgcolor=white width=100% border=0><tr><td>";
                        echo "<b>Total records found :</b> $num_results_affected <em>$sortby</em> <b>in</b> $time"."s";
                    echo "</td></tr></table>";
                    include_once './includes/index2_sgmtdsrch.php';
                } else {
                    echo "<table width=100% border=0 bgcolor=white><tr><td><b>Latest addition to the database : </b></td></tr></table>";
                }
                            
                echo "<table border='0' width='100%' bgcolor='white'>";

                $n = $offset + 1;
                while ($myrow=mysqli_fetch_array($result1)) {
                    echo "<tr bgcolor='white' class='yellowHover'>";
                        $id2=$myrow["id"];
                        $tajuk2=$myrow["38title"];
                        $jenis2=$myrow["39type"];
                        $pengarang2=$myrow["38author"];
                        $sumber2=$myrow["38source"];
                        $tarikh_masuk2=$myrow["40inputdate"];
                        $hits2=$myrow["41hits"];
                        $link2=$myrow["38link"];
                        $pdfattach2=$myrow["39pdfattach"];
                        $localcallnum2 =$myrow["38localcallnum"];
                        $publication2 =$myrow["38publication"];
                        $instimestamp2 =$myrow["40instimestamp"];
                        
                        $query2 = "select 38title_b,38title_c from eg_bahan2 where eg_bahan_id=$id2";
                        $result2 = mysqli_query($GLOBALS["conn"], $query2);
                        $myrow2=mysqli_fetch_array($result2);
                            $tajuk2_b=$myrow2["38title_b"] ?? '';
                            $tajuk2_c=$myrow2["38title_c"] ?? '';
                        
                        echo "<td valign=top align=center width=40>";
                            echo "<a href=javascript:window.scrollTo(0,0)><img src='./images/topofpage.gif' border=0 title='Go to top of this page'></a><br/><b>$n</b>";
                        echo "</td>";
                        
                        if (!$detect->isMobile()) {
                            echo "<td valign=top align=center width=28>";
                                echo "<b>".idToType($jenis2)."</b><br/><img width=24 src='./images/docA.gif'>";
                            echo "</td>";
                        }
                        
                        echo "<td style='text-align:left;vertical-align:top;'>";
                            if ($scstr2 <> null) {
                                echo " <a title='Click here to view detail' class='myclassOri' href='details.php?det=$id2&highlight=$scstr2'>".highlight($tajuk2." / ".$tajuk2_b." ".$tajuk2_c, $scstr2)."</a>";//results will be highlighted
                            } else {
                                echo " <a title='Click here to view detail' class='myclassOri' href='details.php?det=$id2'>$tajuk2 / $tajuk2_b $tajuk2_c</a>";
                            }
                            echo " (<em>$hits2 hits</em>)";
                                            
                            if ($pengarang2 != '') {
                                echo "<br/><a title='Click here to search more titles from this author' class=myclass2 href='opac.php?scstr=$pengarang2&sctype=Author&scflag=Search'>$pengarang2</a>";
                            } else {
                                echo "<br/>$publication2";
                            }
        
                            if ($sumber2 != '') {
                                echo "<br/>$sumber2";
                            }
                                                        
                            if ($detect->isMobile()) {
                                echo "<hr>";
                            }
                        echo "</td>";
                    echo "</tr>";
                    $n = $n +1 ;
                }
                echo "</table>";
                
            //start paging 3
            include_once './includes/paging-p3.php';
        
        ?>
    </div>
    
    <hr>
    
    <?php
    if (!$detect->isMobile()) {
        include_once './includes/footerbar.php';
        echo "<a href='index.php'><img src='./images/key.png' border=0></a>";
    }
    ?>

    <script>
    window.onscroll = function() {scrollFunction()};
    function scrollFunction() {
    if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
        document.getElementById("navbar").style.top = "0";
    } else {
        document.getElementById("navbar").style.top = "-100px";
    }
    }
    </script>
    
</body>

</html>
