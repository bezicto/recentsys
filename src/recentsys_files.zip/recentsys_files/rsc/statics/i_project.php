<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../config.php';
    require_once '../includes/mobiledetect.php';
    $detect = new Mobile_Detect;
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> : Project Information</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
</head>

<body>
    <?php include_once '../includes/loggedinfo.php';?>
    
    <table style='border:0px;width:100%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='border:0px;'><td colspan=2 style='border:0px;text-align:center;'><h3 style='text-decoration: underline;'>Project Information</h3></td></tr>
        <tr><td colspan=2 style='border:0px;text-align:center;'>
                <img width=350 src="../images/company.png" alt="Powered by ReCENTSYS Cloud">
                <br/>Resource Centre System Small Library Edition (ReCentSYS SL) was been developed to cater the need of simple library system in use for schools or other small to mid size organization to handle their collections.
                It was developed from ground up at Tuanku Bainun Library and has been used in many schools that took part in our CSR and outreach programs in rebuilding/reorganizing their library collections.
                        
                <br/><br/><br/>
                <b><u>Development</u></b><br/>
                
                <br/><img src='../images/logo_upsi.png' width=250 alt="Organization Logo"><br/><br/>
                Project Lead and Developer: Khairul Asyrani bin Sulaiman<br/>
                Support Database Layout / Cataloguing Compliance: Mohd. Hizam bin Samin<br/><br/>
        </td></tr>
    </table>

    <hr/>
    <?php include_once '../includes/footerbar.php';?>
</body>

</html>
