<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../config.php';
    require_once '../includes/mobiledetect.php';
    $detect = new Mobile_Detect;
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> : About</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
        
    <?php include_once '../includes/loggedinfo.php';?>
    
    <table style='width:100%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr><td colspan=2 style='text-align:center;'><h3 style='text-decoration: underline;'>About</h3><br/></td></tr>
        <tr><td colspan=2 style='text-align:center;background-color:#ffffff;'>
            <img width=250 src="../<?php echo $logo_image_path;?>" alt="Powered by ReCENTSYS Cloud"/><br/><br/>
            <br/><br/><?php echo $about_text;?>
        </td></tr>
    </table>

    <hr>
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
