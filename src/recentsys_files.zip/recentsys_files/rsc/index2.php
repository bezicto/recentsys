<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once 'config.php';
    include_once 'includes/functions.php';
    include_once './includes/del_code.php';
    $_SESSION['ref'] = 'index2.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Administration</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
    <script>
        function authorAlarm(itemId, valueId)
        {
            if ((document.getElementById(itemId).value == valueId))
            {
                alert('This search ('+valueId+') will be using its unique search engine. All filtering criteria and options will not be valid (even if you selected any).');
            }
        }
    </script>
</head>

<body>
    <?php
        include_once './includes/loggedinfo.php';

        if (!isset($_SESSION['username'])) {
            echo "<table bgcolor=\"80aaef\" width=100% border=0 align=\"center\"><tr bgcolor=\"80aaef\"><td>";
                echo "You do not have the right to be here. Please contact the administrator.<br/>";
            echo "</td></tr></table>";
            echo "</body></html>";
            exit;
        }

        echo "<table bgcolor=\"80aaef\" width=100% border=0 align=\"center\">";
            echo "<tr bgcolor=\"80aaef\"><td style='vertical-align:top;'>";
                echo "Hi, <b>".$_SESSION['fullname']."</b>";
                echo "<br/><image src='images/small_input.png' width=12>&nbsp<a href=reports/adsreport_details.php>My&nbspInput</a> ";
                echo "<image src='images/small_password.png' width=12>&nbsp<a class='toggleopacity' href='./admin/passchange.php?upd=.g'>Change&nbspPassword</a> ";
                echo "<image src='images/small_logout.png' width=12>&nbsp<a class='toggleopacity' href='index.php'>Logout</a>";
            echo "</td>";
            echo "<td align='right'>";
                echo " <a class='toggleopacity' href='./admin/reg.php'><img height=64 src='./images/newb_add.png' border=0 title='Add new material into the database'></a>";
                $img_en = "";if ($useCode == 'barcode') {$img_en = "_bc";}
                echo " <a class='toggleopacity' href='./admin/qr_bprintrange.php'><img height=64 src='./images/newb_print$img_en.png' border=0 title='Print barcode range for reading materials'></a>";
                echo " <a class='toggleopacity' href='./admin/charge.php'><img height=64 src='./images/newb_charge$img_en.png' border=0 title='Charge (Borrow) Module'></a>";
                echo " <a class='toggleopacity' href='./admin/discharge.php'><img height=64 src='./images/newb_discharge$img_en.png' border=0 title='Discharge (Return) Module'></a>";
                echo " <a class='toggleopacity' href='./admin/paysearch.php'><img height=64 src='./images/newb_fines.png' border=0 title='Late Discharge Fines'></a>";
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='reports/adsreport.php'><img height=64 src='./images/newb_reports.png' border=0 title='System generated report'></a>";}
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='./admin/dupfinder.php'><img height=64 src='./images/newb_duplicate.png' border=0 title='List duplicated items'></a>";}
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='./admin/addholiday.php'><img height=64 src='./images/newb_holidays.png' border=0 title='Holiday Listing'></a>";}
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='./admin/addtype.php'><img height=64 src='./images/newb_types.png' border=0 title='Add or remove item type'></a>";}
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='./admin/addsubject.php'><img height=64 src='./images/newb_subjects.png' border=0 title='Add or remove subject headings'></a>";}
                if ($_SESSION['editmode'] == 'SUPER') {echo " <a class='toggleopacity' href='./admin/chanuser.php'><img height=64 src='./images/newb_users.png' border=0 title='User accounts information'></a>";}
            echo "</td></tr>";
        echo "</table>";
    ?>
                        
        <hr><br/>

        <div style='text-align:center;width:100%;'>
            <em>Enter your search terms and press Search to continue.</em>
            <form action="index2.php" method="get" enctype="multipart/form-data">
                
                <input type="text" name="scstr" size="80" maxlength="255" value="<?php if (isset($_GET["scstr"]) && $_GET["scstr"] <> '') {echo $scstr2 = str_replace(['"',"'"], "", $_GET["scstr"]);}?>"/>
                
                <b>in: </b>
                
                <select id="sctype" name="sctype" onchange="authorAlarm('sctype','Author');authorAlarm('sctype','Control Number');" style="font-size:11px;">
                <?php
                    $sctype2 = $_GET["sctype"] ?? 0;
                        
                    echo '<option value="All Type" ';if ($sctype2 == 'All Type') {echo 'selected';} echo ' >Title: All Type</option> ';
                    
                    $queryU = "select 38typeid, 38type from eg_jenisbahan";
                    $resultU = mysqli_query($GLOBALS["conn"], $queryU);
                    while ($row=mysqli_fetch_array($resultU)) {
                        echo '<option value="'.$row['38typeid'].'"';if ($row['38typeid']==$sctype2) {echo ' selected';} echo '>Title: '. $row['38type'] . '</option>'."\n";
                    }
            
                    if (isset($_SESSION['username'])) {
                        echo '<option value="Control Number" ';if ($sctype2 == 'Control Number') {echo 'selected';} echo ' >Control Number</option>';
                    }
                    
                    echo '<option value="Author" ';if ($sctype2 == 'Author') {echo 'selected';} echo ' >Author</option> ';
                ?>
                </select>
                                                        
                <br/><br/><input type="submit" name="scflag" value="Search" />
            </form>
        </div><br/>
                            
        <?php include_once './includes/browser_bar.php';?>
                            
        <div style='text-align:center;width:100%;'>
            <?php
                //start paging 1
                include_once './includes/paging-p1.php';
                
                if ((isset($_GET["scflag"]) && $_GET["scflag"] == 'Search') || (isset($_GET["sctype"]) && $_GET["sctype"] <> null)) {
                    $latest1 = "FALSE";
                    $sctype2 = $_GET["sctype"];
                    $scstr2 = str_replace(['"',"'","select","delete","or","and"], "", $_GET["scstr"]);
                    include_once './includes/index2_s_boolean.php';
                } else {
                    $latest1 = "TRUE";
                    $query1 = "select SQL_CALC_FOUND_ROWS *  from eg_bahan order by id desc LIMIT $offset, $rowsPerPage";
                    $sctype2 = 0;
                    $scstr2 = "";
                }
                                        
                $time_start = getmicrotime();
                $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                                        
                //start paging 2
                include_once './includes/paging-p2.php';

                $time_end = getmicrotime();
                $time = round($time_end - $time_start, 5);

                if ($latest1 == "FALSE") {
                    echo "<table width=100% border=0 bgcolor=white><tr><td>";
                        echo "<b>Total records found :</b> $num_results_affected ";
                        echo "<b>in</b> $time seconds <b>for</b> <em>".stripslashes(str_replace('"', '&#34;', $scstr2))."</em>";
                    echo "</td></tr></table>";
                    include_once './includes/index2_sgmtdsrch.php';
                } else {
                    echo "<table width=100% border=0 bgcolor=white><tr><td><b>Latest addition to the database : </b></td></tr></table>";
                }
        
                echo "<table border='0' width='100%' bgcolor='white'>";
                                                                    
                $n = $offset + 1;
        
                while ($myrow=mysqli_fetch_array($result1)) {
                    echo "<tr bgcolor='white' class='yellowHover'>";
                    
                    $id2=$myrow["id"];
                    $tajuk2=$myrow["38title"];
                    $jenis2=$myrow["39type"];
                    $pengarang2=$myrow["38author"];
                    $link2=$myrow["38link"];
                    $tarikh_masuk2=$myrow["40inputdate"];
                    $hits2=$myrow["41hits"];
                    $input_masuk2=$myrow["40inputby"];
                    $pdfattach2=$myrow["39pdfattach"];
                    $localcallnum2 =$myrow["38localcallnum"];
                    $instimestamp2 =$myrow["40instimestamp"];

                    $query2 = "select 38title_b,38title_c from eg_bahan2 where eg_bahan_id=$id2";
                    $result2 = mysqli_query($GLOBALS["conn"], $query2);
                    $myrow2=mysqli_fetch_array($result2);
                        $tajuk2_b=$myrow2["38title_b"] ?? '';
                        $tajuk2_c=$myrow2["38title_c"] ?? '';
                                        
                    echo "<td valign=top align=center width=40>";
                        echo "<a href=javascript:window.scrollTo(0,0)><img src='./images/topofpage.gif' border=0 title='Go to top of this page'></a><br/>$n";
                    echo "</td>";
                                        
                    echo "<td valign=top style='text-align:left;'>";
                        echo "<a class=myclassOri href='details.php?det=$id2";
                        if ($scstr2 != '') {
                            echo "&scstr=".urlencode($scstr2);
                        }
                        if (isset($_GET['scflag']) && ($_GET['scflag'] != '')) {echo "&scflag=".$_GET['scflag'];}
                        if (isset($_GET['sctype']) && ($_GET['sctype'] != '')) {echo "&sctype=".$_GET['sctype'];}
                        echo "&page=$pageNum'>";
                        if ($scstr2 <> null) {
                            echo highlight($tajuk2." / ".$tajuk2_b." ".$tajuk2_c, $scstr2)."</a>";
                        } else {
                            echo "$tajuk2 / $tajuk2_b $tajuk2_c</a>";
                        }
                                            
                        if ($pengarang2 != '') {
                            echo "<br/><a class=myclass2 href='index2.php?scstr=$pengarang2&sctype=Author&scflag=Search'>$pengarang2</a>";
                        }

                        $queryTy = "select 38type from eg_jenisbahan where 38typeid = '$jenis2'";
                        $resultTy = mysqli_query($GLOBALS["conn"], $queryTy);
                        $myrowTy=mysqli_fetch_array($resultTy);
                        $jenisTy=$myrowTy["38type"];
                        echo "<br/><b>Type :</b> $jenisTy";
                        
                        echo "<br/><b>Hits :</b> ";
                        if ($_SESSION['editmode'] == 'SUPER') {
                            echo "<a title='Hits for $id2' target='_blank' href='reports/adsreport_ipitems.php?det=$id2'>$hits2</a>";
                        } else {
                            echo "$hits2";
                        }
                        
                        echo " Loan stat :";
                        $queryL = "select 39accessnum from eg_bahan_copies where eg_bahan_id=$id2";
                        $resultL = mysqli_query($GLOBALS["conn"], $queryL);
                        $totalLnx = 0;
                        while ($myrowL=mysqli_fetch_array($resultL)) {
                            $accessnum2=$myrowL["39accessnum"];
                            $queryLnx = "select count(39accessnum) as total from eg_bahan_charge where 39accessnum='$accessnum2'";
                            $resultLnx = mysqli_query($GLOBALS["conn"], $queryLnx);
                            $myrowLnx=mysqli_fetch_array($resultLnx);
                            $totalLnx = $totalLnx + $myrowLnx["total"];
                        }
                        echo "$totalLnx ";
                                                
                        $dir_year2 = substr("$tarikh_masuk2", -4);
                            if ($pdfattach2 == 'TRUE') {
                                echo "<b>View Options :</b> ";
                                if (is_file("$pdf_upload_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf")) {
                                    echo "<a href='$pdf_upload_directory/$dir_year2/$id2"."_"."$instimestamp2.pdf' target='_blank'><img src='./images/pdfIcon.gif' border=0 alt='Click to view' title='File available'></a>";
                                } else {
                                    echo "<img src='./images/pdfnoIcon.gif' border=0 alt='Click to view' title='File missing. Attention needed.'>";
                                }
                            }
                            
                        echo "<br/><br/>";
                    echo "</td>";
                                                    
                    echo "<td width=100>";
                        echo "<b>Added by :<br/></b>".patronUsernametoName($input_masuk2)." <br/><b>Date Added :</b> $tarikh_masuk2 ";
                    echo "</td>";
                    
                    echo "</tr>";
                    $n = $n +1 ;
                }
                echo "</table>";
                                    
            //start paging 3
            include_once './includes/paging-p3.php';
        
            ?>
        </div>
    
        <hr>
        
    <?php include_once './includes/footerbar.php';?>

</body>

</html>
