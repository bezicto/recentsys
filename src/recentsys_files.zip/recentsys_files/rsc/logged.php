<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once 'includes/access_isset_myacc.php';
    include_once 'config.php';
    include_once 'includes/functions.php';
?>

<?php
    //renew
    if (isset($_GET['rid']) && is_numeric($_GET['rid'])) {
        //1. get1. get when charged
        $queryA = "select 39charged_on,39duedate from eg_bahan_charge where id=".$_GET['rid'];
        $resultA = mysqli_query($GLOBALS["conn"], $queryA);
        $myrowA=mysqli_fetch_array($resultA);
        $charge_onA = $myrowA["39charged_on"];
    
        $multiplyA = $myrowA["39duedate"] + 2;// eg. 0=7hari, 1=14hari, 2=21hari ....sebab itu kena tambah 2
    
        if ($multiplyA <= $max_renew_count + 1) {
            //2. get loan eligibility for patron
            $max_dayA = maxday($_SESSION["username_myacc"]);
    
            //3. add to $charge_on
            $new_dueA = $charge_onA + (($max_dayA*$multiplyA)*86400);
    
            //4. save and increase 39duedate +1
            $duedateInsert = $myrowA["39duedate"] + 1;//just add one because display will add +2 later
            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan_charge SET 39duedate=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ii", $duedateInsert, $_GET['rid']);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            echo "<script>location.href='logged.php';</script>";
        } else {
            echo "<script>alert('Anda tidak dibenarkan untuk mempembaharui pinjaman kerana telah melebihi had dibenarkan.');</script>";
        }
    }
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> | My Account</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    <table style='width:100%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:white;'>
            <td>Patron information</td><td style='width:200;text-align:right;'>
            <a class='toggleopacity' href='admin/passchange.php?upd=.g'><img alt='Change Password' src='./images/changepassword.gif' border=0 title='Change your login password'></a>
            <a href='index.php'><img src='images/logout.gif' alt='Logout'></a>
            </td>
        </tr>
        <tr style='background-color:lightgrey;'>
            <td colspan=2>
                <?php echo getUserInfo($_SESSION["username_myacc"]);?>
            </td>
        </tr>
    </table>
            
    <br/>
    
    <table style='width:100%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:white;text-align:center;'>
            <td style='background-color:#F8EE96;'>On-loan items history and fines (if applicable)</td>
        </tr>
        <tr style='background-color:white;'>
            <td>
                <table style='width:100%;margin-left:auto;margin-right:auto;background-color:white;'>
                <tr style='background-color:lightgrey;'>
                    <td style='width:5%;text-align:center;'>#</td>
                    <td style='text-align:center;'>Title</td>
                    <td style='text-align:center;'>Charged on</td>
                    <td style='text-align:center;'>Due Date</td>
                    <td style='text-align:center;'>Renew<br/>count</td>
                    <td style='text-align:center;'>Discharged on</td>
                    <td style='text-align:center;'>Late ?</td>
                    <td style='text-align:center;width:70;'>Fines</td>
                </tr>
                <?php
                    $queryT = "select * from eg_bahan_charge where 39patron='".$_SESSION['username_myacc']."'";
                    $resultT = mysqli_query($GLOBALS["conn"], $queryT);
                    $n = 1;
                    $totalunpaid = 0.00;
                    $beforepaymenton = "0000";
                    $beforepaymentrcv = "0000";
                    while ($myrow=mysqli_fetch_array($resultT)) {
                        $id=$myrow["id"];
                        $patron=$myrow["39patron"];
                        $accessnum=$myrow["39accessnum"];
                        $charged_on=$myrow["39charged_on"];
                        $duedate_mp=$myrow["39duedate"];
                        $dc_on=$myrow["40dc_on"];
                        $dc=$myrow["40dc"];
                        $dc_enforcedfine=$myrow["40dc_enforcedfine"];
                        $received_amount=$myrow["41f_received_amount"];
                        $paid_on=$myrow["41f_paidon"];
                        $paidrb=$myrow["41f_received"];
                        $paid_rid=$myrow["41f_receipt_id"];
                        
                        if ($myrow["41f_pay"] == 'YES') {
                            $f_pay=" PAID";
                        } else {
                            $f_pay=" UNPAID";
                        }
                
                        $maxSecond = ((maxday($patron)*($duedate_mp+1))*86400);//to calculate duedate
                        $beginOfDay_for_charged_on = strtotime("midnight", $charged_on);// start of the day for the charged day
                        $duedate = $beginOfDay_for_charged_on + $maxSecond + 86399;// + 86399 to extend to midnight
                        $duedate = shiftDueDate($duedate);//shifting duedate if holiday

                        if ($dc_on <> null && $dc_on != 0) {
                            $minusdays = ($dc_on - $duedate)/86400 + 1;
                        } else {
                            $minusdays = (time() - $duedate)/86400 + 1;
                        }
                                                        
                        echo "<tr bgcolor='EBF0FE'><td>$n</td>";
                        echo "<td>".getTitle($accessnum)."</td>";
                        echo "<td>".date('D, Y-m-d', $charged_on)."</td>";
                        echo "<td>".date('D, Y-m-d', $duedate);

                        //display the link to renew only if the number of renewals is less than 2 or the date is lower than the due date
                        if ($dc != 'DC' && $duedate_mp < $max_renew_count && time() <= $duedate) {
                            echo " [<a href='logged.php?rid=$id' onclick=\"return confirm('Are you sure to renew this loaned item ?');\">Renew</a>]";
                        }
                        echo "</td>";
                        echo "<td style='text-align:center;'>$duedate_mp</td>";
                        if ($dc_on != '') {
                            echo "<td>".date('D, Y-m-d', $dc_on)."</td>";
                        } else {
                            echo "<td>-</td>";
                        }
                        echo "<td style='text-align:center;'>";
                        if ($dc_on != '' || $dc_on != null) {
                            if ($dc_on <= $duedate) {
                                echo "No";
                            } else {
                                echo floor($minusdays)."<br/>days";
                            }
                        } else {
                            if (time() > $duedate) {
                                echo floor($minusdays)." days";
                            } else {
                                echo "N/A";
                            }
                        }
                        echo "</td>";
                        echo "<td style='text-align:center;'>";
                            if ($myrow["41f_pay"] == 'YES') {
                                if ($beforepaymenton == $paid_on && $beforepaymentrcv == $paidrb) {
                                    echo "<em>Paid as above <br/>Receipt: $paid_rid.</em>";
                                } else {
                                    echo "$currency_SHORT ".$received_amount." <br/>$f_pay ".date('D, Y-m-d', $paid_on)."<br/>Receipt: $paid_rid";
                                }
                            } else {
                                if ($dc_on != null) {
                                    $minusdays = ($dc_on - $duedate)/86400;
                                    if ($minusdays >= 0) {
                                        echo "$currency_SHORT ".calculatedFines(floor($minusdays), $accessnum, $dc_enforcedfine)." $f_pay";
                                        if ($myrow["41f_pay"] != 'YES') {
                                            $totalunpaid = $totalunpaid + calculatedFines(floor($minusdays), $accessnum, $dc_enforcedfine);
                                        }
                                    } else {
                                        echo "-";
                                    }
                                } else {
                                    if (time() > $duedate) {
                                        $minusdays = (time() - $duedate)/86400;
                                        echo "$currency_SHORT ".calculatedFines(floor($minusdays), $accessnum, getIDCurrentEnforcedFine(getTypeID($accessnum)))." $f_pay";
                                            if ($myrow["41f_pay"] != 'YES') {
                                                $totalunpaid = $totalunpaid + calculatedFines(floor($minusdays), $accessnum, getIDCurrentEnforcedFine(getTypeID($accessnum)));
                                            }
                                        echo " UNDISCHARGE";
                                    } else {
                                        echo "-";
                                    }
                                }
                            }
                        echo "</td>";
                        echo "</tr>";
                    
                        $beforepaymenton = $paid_on;
                        $beforepaymentrcv = $paidrb;
                        $n = $n + 1;
                    }
                ?>
                <tr style='background-color:lightgrey;'>
                    <td colspan=7 style='text-align:right'>Total Unpaid :</td>
                    <td style='text-align:center;'><?php echo $totalunpaid;?></td>
                </tr>
                <tr style='background-color:white;'>
                    <td colspan=8 style='text-align:right'>Proceed to the service counter for payment of any available fines.</td>
                </tr>
                </table>
            </td>
        </tr>
        <tr><td><?php include_once './includes/footerbar.php';?></td></tr>
    </table>

</body>

</html>

<?php exit;?>
