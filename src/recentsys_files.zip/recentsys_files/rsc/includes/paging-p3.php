<?php
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");
    
    echo "<br/><table align=center border=0 width=100% bgcolor=white>";
    echo "<tr bgcolor=lightgreen>";

    $urlappender = "";
    if (isset($_GET['scflag']) && ($_GET['scflag'] != '')) {$urlappender .= "&scflag=".$_GET['scflag'];}
    if (isset($_GET['sctype']) && ($_GET['sctype'] != '')) {$urlappender .= "&sctype=".$_GET['sctype'];}
    
    $scstr2 = urlencode($scstr2);//fix anything to do with boolean operators
    
    if ($maxPage > 1) {
        if ($pageNum > 1) {
            $page = $pageNum - 1;
            $prev = " [ <a href=\"$self?scstr=$scstr2$urlappender&page=$page\">Previous</a> ] ";
            
            $first = " [ <a href=\"$self?scstr=$scstr2$urlappender&page=1\">First</a> ] ";
        } else {
            $prev  = ' [Previous] ';
            $first = ' [First] ';
        }

        if ($pageNum < $maxPage) {
            $page = $pageNum + 1;
            $next = " [ <a href=\"$self?scstr=$scstr2$urlappender&page=$page\">Next</a> ] ";
            $last = " [ <a href=\"$self?scstr=$scstr2$urlappender&page=$maxPage\">Last</a> ] ";
        }  else {
            $next = ' [Next] ';
            $last = ' [Last] ';
        }
        
        if ($num_results_affected > $rowsPerPage) {
            echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
        }
    }
    
    echo "</tr>";
    echo "</table>";
