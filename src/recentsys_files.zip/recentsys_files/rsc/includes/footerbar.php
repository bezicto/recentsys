<?php
defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

echo "<table width=100% border=0 align=\"center\">";
    echo "<tr><td align=center height=29>";
        echo "Licensed to $licensed_info";
        echo "<br/>Copyright ".date('Y')." : Perpustakaan Tuanku Bainun, Universiti Pendidikan Sultan Idris";
        echo "<br/>$version_num";
    echo "</td></tr>";
echo "</table>";
