 <?php

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

    if (is_uploaded_file($_FILES[$allowed_fieldname]['tmp_name'])) {
        move_uploaded_file($_FILES[$allowed_fieldname]['tmp_name'], $uploaddir.'/'.$idUpload.'_'.$timestampUpload.'.'.$extension);
    }
