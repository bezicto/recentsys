<?php

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");
    
    if ($sctype2 == 'All Type') {
        if ($scstr2 == '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_bahan order by id desc LIMIT $offset, $rowsPerPage";
        } else {
            include 'index2_s_rmvcommonword.php';
            $query1 = "select SQL_CALC_FOUND_ROWS *, match (38title) against ('$scstr2' in boolean mode) as score from eg_bahan where 38title <> '' and";
            $query1 .= " match (38title) against ('$scstr2' in boolean mode)";
            $query1 .= " order by score desc LIMIT $offset, $rowsPerPage";
        }
    } elseif (isset($_SESSION['username']) && ($sctype2 == 'Control Number')) {
        include_once 'index2_s_ctrlnum.php';
    } elseif ($sctype2 == 'Author') {
        include_once 'index2_s_author.php';
    } else {
        if ($scstr2 == '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_bahan where 39type = '$sctype2' order by id desc LIMIT $offset, $rowsPerPage";
        } else {
            include 'index2_s_rmvcommonword.php';
            $query1 = "select SQL_CALC_FOUND_ROWS *, match (38title) against ('$scstr2' in boolean mode) as score from eg_bahan where 39type = '$sctype2' and";
            $query1 .= " match (38title) against ('$scstr2' in boolean mode)";
            $query1 .= " order by score desc LIMIT $offset, $rowsPerPage";
        }
    }
