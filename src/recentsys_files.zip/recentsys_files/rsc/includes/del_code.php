<?php

defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

//only SUPER user will enable to delete items
if (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null && $_SESSION['editmode'] == 'SUPER') {
    $get_id_del = $_GET["del"];
    
    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan2 WHERE eg_bahan_id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan2_indicator WHERE eg_bahan_id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan_det WHERE eg_bahan_id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan_copies WHERE eg_bahan_id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

     $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan_isbn WHERE eg_bahan_id=?");
    mysqli_stmt_bind_param($stmt, "i", $get_id_del);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    if (isset($_GET["delfilename"])) {
        $get_delfilename = $_GET["delfilename"];
        if (is_file("$pdf_upload_directory/".$get_delfilename.".pdf")) {
            unlink("$pdf_upload_directory/".$get_delfilename.".pdf");
        }
        if (is_file("$cover_upload_directory/".$get_delfilename.".jpg")) {
            unlink("$cover_upload_directory/".$get_delfilename.".jpg");
        }
    }
} elseif (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null && $_SESSION['editmode'] == 'TRUE') {
    echo "<script language=\"javascript\" type=\"text/javascript\">";
    echo "alert('Trying doing something illegal arent you ?');";//when TRUE user try to manipulate the GET method, alert will appear.
    echo "</script>";
}
