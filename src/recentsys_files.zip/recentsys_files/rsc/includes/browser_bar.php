<?php defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");?>
<table style='width:100%;margin-left:auto;margin-right:auto;background-color:white;'>
    <tr>
    <td style='background-color:#80aaef;height:29;text-align:right;'>
    <b>Browser :</b>
    <input type="button" value="Subject" onClick="location.href='browsers/subject.php'">
    </td></tr>
</table>
