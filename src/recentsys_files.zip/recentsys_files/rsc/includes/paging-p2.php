<?php

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

    $row = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
    $num_results_affected = $row[0];
    $maxPage = ceil($num_results_affected/$rowsPerPage);
    $self = $_SERVER['PHP_SELF'];
