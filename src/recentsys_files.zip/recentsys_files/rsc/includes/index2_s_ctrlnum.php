<?php

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

    if (is_numeric($scstr2)) {
        if ($scstr2 <> '') {
            $query1 = "select SQL_CALC_FOUND_ROWS * from eg_bahan where id=$scstr2 LIMIT $offset, $rowsPerPage";
        } else {
            $query1 = "select SQL_CALC_FOUND_ROWS *  from eg_bahan LIMIT $offset, $rowsPerPage";
        }
    } else {
        echo "<script language=\"javascript\" type=\"text/javascript\">";
        echo "alert('The input you have typed is not numerical. Please retype.');";
        echo "</script>";
        $query1 = "select SQL_CALC_FOUND_ROWS *  from eg_bahan LIMIT $offset, $rowsPerPage";
    }
