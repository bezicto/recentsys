<?php
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

    $queryP = "select 37keyword, 37type, 37freq  from eg_userlog where 37lastlog like '".date("D d/m/Y")."%' order by 37freq desc LIMIT 0, 10";//limit kepada 10 rekod terkini
    $resultP = mysqli_query($GLOBALS["conn"], $queryP);
    $num_resultsP = mysqli_num_rows($resultP);
    
    if ($num_resultsP <> 0) {
        $n=1;
        echo "<table border='0' width='100%' align=center bgcolor=#FFFE96>";
        echo "<tr bgcolor=white><td colspan=5><img src='./images/favorites.gif'>";
        echo "<b>Today's popular searches :</b></tr>";
        while ($myrow=mysqli_fetch_array($resultP)) {
                if (($n == 6) || ($n == 1)) {
                    echo "<tr><td>";
                } else {
                    echo "<td>";
                }
                
                $keywordP=$myrow["37keyword"];
                $typeP=$myrow["37type"];
                
                $keywordPex=urlencode($keywordP);//to encode + sign properly before displaying to popular searches
                echo "<a href='opac.php?scstr=$keywordPex&sctype=$typeP'>$keywordP";
                if ($typeP == 'Author') {
                    echo " (Author)";
                }
                echo "</a></td>";
                
                if (($n == 5) || ($n == 10)) {
                    echo "</td></tr>";
                } else {
                    echo "</td>";
                }
                
                $n++;
            }
        echo "</table>";
    }
