<?php

    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

    if ($_GET['scstr'] <> null) {
        $arrays_T = (explode(" ", $scstr2));
        $dotarrays_T = sizeof($arrays_T) - 1;
        
        if ($dotarrays_T <> 0) {
            echo "<table border='0' width='100%' align=center bgcolor='white'>";
            echo "<tr><td colspan=5>";
                echo "<b>Try these exploded search terms : </b>";
                for ($numbering_scheme_T=0;$numbering_scheme_T<=$dotarrays_T;$numbering_scheme_T++) {
                    $currentarray = just_clean(stripslashes($arrays_T[$numbering_scheme_T]));
                    echo "<a href='".$_SESSION['ref']."?scstr=$currentarray";
                    if (isset($_GET['scflag']) && ($_GET['scflag'] != '')) {echo "&scflag=".$_GET['scflag'];}
                    if (isset($_GET['sctype']) && ($_GET['sctype'] != '')) {echo "&sctype=".$_GET['sctype'];}
                    echo "'>$currentarray</a> ";
                }
                echo "<br/><br/></td></tr>";
            echo "</table>";
        }
    }
