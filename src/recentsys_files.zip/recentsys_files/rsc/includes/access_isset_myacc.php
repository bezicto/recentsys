<?php
if (!isset($_SESSION['username_myacc'])) {
    echo "<p align=center>You do not have the right to be here. Please contact the administrator.</div>";
    exit;
}
