<?php
    
    function countOnlineDuration($timenow, $lastlogin)
    {
        $now_array=explode(' ', $timenow);
        $lasttime_array=explode(' ', $lastlogin);
        
        $now_ampm=explode(':', $now_array[2]);
        if ($now_array[3] == 'pm' && $now_ampm[0] <> 12) {
            $now_ampm[0]=$now_ampm[0]+12;
        }

        $now_array[2]=$now_ampm[0].":".$now_ampm[1];
    
        $lasttime_ampm=explode(':', $lasttime_array[2]);
        if ($lasttime_array[3] == 'pm' && $lasttime_ampm[0] <> 12) {
            $lasttime_ampm[0]=$lasttime_ampm[0]+12;
        }

        $lasttime_array[2]=$lasttime_ampm[0].":".$lasttime_ampm[1];
                                                    
        $now_days=explode('/', $now_array[1]);
        $now_days=implode('-', $now_days);
        $lasttime_days=explode('/', $lasttime_array[1]);
        $lasttime_days=implode('-', $lasttime_days);
        
        $now = strtotime(date($now_days." ".$now_array[2]));
        $lasttime = strtotime($lasttime_days." ".$lasttime_array[2]);
        
        $dateDiff = $now-$lasttime;
        $fullDays = floor($dateDiff/(60*60*24));
        $fullHours = floor(($dateDiff-($fullDays*60*60*24))/(60*60));
        $fullMinutes = floor(($dateDiff-($fullDays*60*60*24)-($fullHours*60*60))/60);
        return "<b>Logged:</b> $fullDays days, $fullHours hrs, $fullMinutes mins.";
    }
    
    function getmicrotime()
    {
        list($usec, $sec) = explode(" ", microtime());
        return (float)$usec + (float)$sec;
    }

    function just_clean($string)
    {
        $specialCharacters = array(
        '#' => '',
        '$' => '',
        '%' => '',
        '&' => '',
        '@' => '',
        '.' => '',
        '�' => '',
        '+' => '',
        '=' => '',
        '�' => '',
        '\\' => '',
        '/' => ''
        );

        foreach ($specialCharacters as $character => $replacement) {
            $string = str_replace($character, '' . $replacement . '', $string);
        }

        // Remove all remaining other unknown characters
        $string = preg_replace('/[^a-zA-Z0-9\-]/', '', $string);
        $string = preg_replace('/^-+/', '', $string);
        $string = preg_replace('/-+$/', '', $string);
        $string = preg_replace('/-{2,}/', '', $string);

        return $string;
    }

    function highlight($text, $words)
    {
        $words = trim($words);
        $wordsArray = explode(' ', $words);
        foreach ($wordsArray as $word) {
            if (strlen(trim($word)) > 2) {
                $word = just_clean($word);//remove unwanted special characters, replace it with nothing
                
                //mekanisma kawalan untuk buang sekiranya penggguna terlebih space
                if ($word != '') {
                        $hlstart = '<font style="BACKGROUND-COLOR: yellow">';
                        $hlend = '</font>';
                        $text = preg_replace("/$word/i", $hlstart.'\\0'.$hlend, $text);//php7
                    }
            }
        }
        return $text;
    }

    function displayFines($typeid)
    {
        $query3 = "select * from eg_jenisbahan_fines where 38typeid = $typeid order by id desc limit 1";
        $result3 = mysqli_query($GLOBALS["conn"], $query3);
        $myrow3=mysqli_fetch_array($result3);
        if (!isset($myrow3["39fines_initdays"])) {
            return "Unset";
        } else {
            return "Initial : ".$myrow3["39fines_initdays"]." days (".$myrow3["39fines_initamount"]."/".$myrow3["39fines_subsequenceamount"].")";
        }
    }
    
    function getIDCurrentEnforcedFine($typeid)
    {
        $queryEF = "select id from eg_jenisbahan_fines where 38typeid = $typeid order by id desc limit 1";
        $resultEF = mysqli_query($GLOBALS["conn"], $queryEF);
        $myrowEF=mysqli_fetch_array($resultEF);
        return $myrowEF["id"];
    }
    
    function getTypeID($accessnum)
    {
        $queryJenis = "select eg_bahan.39type from eg_bahan_copies, eg_bahan where eg_bahan_copies.eg_bahan_id=eg_bahan.id and eg_bahan_copies.39accessnum='$accessnum'";
        $resultJenis = mysqli_query($GLOBALS["conn"], $queryJenis);
        $myrowJenis=mysqli_fetch_array($resultJenis);
        return $myrowJenis["39type"];
    }

    //old version of shiftDueDate, kept for backward compatibility
    /*
    function shiftDueDate($duedate)
    {
        $queryW = "select * from eg_working_days";
        $resultW = mysqli_query($GLOBALS["conn"], $queryW);
        $myrowW = mysqli_fetch_array($resultW);
        
        $duedate_DayName = date('D', $duedate);
        a:
        if ($myrowW["mon"] == '0' && $duedate_DayName == 'Mon') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["tue"] == '0' && $duedate_DayName == 'Tue') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["wed"] == '0' && $duedate_DayName == 'Wed') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["thu"] == '0' && $duedate_DayName == 'Thu') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["fri"] == '0' && $duedate_DayName == 'Fri') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["sat"] == '0' && $duedate_DayName == 'Sat') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        if ($myrowW["sun"] == '0' && $duedate_DayName == 'Sun') {$duedate = $duedate + 86400;$duedate_DayName = date('D', $duedate);goto a;}
        
        $queryH = "select UNIX_TIMESTAMP(STR_TO_DATE(38hol_date,'%d/%m/%Y')) as '38hol_date2' from eg_holiday order by 38hol_date2";
        $resultH = mysqli_query($GLOBALS["conn"], $queryH);
        while ($myrowH=mysqli_fetch_array($resultH)) {
            $dateH=$myrowH["38hol_date2"] + 86399;
            if ($dateH == $duedate) {
                $duedate = $duedate + 86400;
            }
        }
        return $duedate;
    }*/
    
    //new version of shiftDueDate with improved logic to avoid infinite loops
    function shiftDueDate($duedate)
    {
        $queryW = "select * from eg_working_days";
        $resultW = mysqli_query($GLOBALS["conn"], $queryW);
        $myrowW = mysqli_fetch_array($resultW);
        
        // Map day names to database columns
        $dayMap = [
            'Mon' => 'mon',
            'Tue' => 'tue',
            'Wed' => 'wed',
            'Thu' => 'thu',
            'Fri' => 'fri',
            'Sat' => 'sat',
            'Sun' => 'sun'
        ];
        
        // Skip non-working days
        $maxIterations = 365; // Prevent infinite loop
        $iterations = 0;
        
        while ($iterations < $maxIterations) {
            $duedate_DayName = date('D', $duedate);
            
            if (isset($dayMap[$duedate_DayName]) && $myrowW[$dayMap[$duedate_DayName]] == '0') {
                $duedate += 86400; // Add 1 day
                $iterations++;
            } else {
                break;
            }
        }
        
        // Check and skip holidays - need to re-check after skipping non-working days
        $queryH = "select UNIX_TIMESTAMP(STR_TO_DATE(38hol_date,'%d/%m/%Y')) as '38hol_date2' from eg_holiday";
        $resultH = mysqli_query($GLOBALS["conn"], $queryH);
        
        $holidays = [];
        while ($myrowH = mysqli_fetch_array($resultH)) {
            $holidays[] = (int)$myrowH["38hol_date2"];
        }
        
        // Keep advancing if due date falls on a holiday
        $maxHolidayChecks = 100;
        $holidayChecks = 0;
        
        while ($holidayChecks < $maxHolidayChecks) {
            $duedateNormalized = strtotime(date('Y-m-d', $duedate));
            
            if (in_array($duedateNormalized, $holidays)) {
                $duedate += 86400;
                $holidayChecks++;
                
                // Re-check for non-working days after skipping holiday
                $duedate_DayName = date('D', $duedate);
                if (isset($dayMap[$duedate_DayName]) && $myrowW[$dayMap[$duedate_DayName]] == '0') {
                    // Loop will continue to next iteration automatically
                }
            } else {
                break;
            }
        }
        
        return $duedate;
    }
    
    function calculatedFines($days, $accessnum, $enforcedfine_id)
    {
        $queryFines = "select * from eg_jenisbahan_fines where id=$enforcedfine_id and 38typeid=".getTypeID($accessnum);
        $resultFines = mysqli_query($GLOBALS["conn"], $queryFines);
        if (mysqli_query($GLOBALS["conn"], $queryFines)) {
            $myrowFines=mysqli_fetch_array($resultFines);
            $fines_initdays=$myrowFines["39fines_initdays"];
            $fines_initamount=$myrowFines["39fines_initamount"];
            $fines_subsequenceamount=$myrowFines["39fines_subsequenceamount"];

            $after_init = $days - $fines_initdays;
            if ($after_init <= 0) {
                $fines_pay = $days * $fines_initamount;
            } else {
                $fines_pay = $fines_initdays * $fines_initamount;
                $fines_pay = $fines_pay + ($after_init * $fines_subsequenceamount);
            }
            return $fines_pay;
        } else {
            return 0;
        }
    }
    function getTitle($accessnum)
    {
        $queryB = "select eg_bahan_id from eg_bahan_copies where 39accessnum='$accessnum'";
        $resultB = mysqli_query($GLOBALS["conn"], $queryB);
        $myrowB=mysqli_fetch_array($resultB);
    
        $queryC = "select 38title from eg_bahan where id=".$myrowB["eg_bahan_id"];
        $resultC = mysqli_query($GLOBALS["conn"], $queryC);
        $myrowC=mysqli_fetch_array($resultC);
    
        return $myrowC["38title"];
    }
    function getUserInfo($username)
    {
        $queryB = "select name,username,division,lastlogin from eg_auth where username='$username'";
        $resultB = mysqli_query($GLOBALS["conn"], $queryB);
        $myrowB=mysqli_fetch_array($resultB);
    
        $text = "Logged as : ".$myrowB["name"]."";
        $text .= "<br/>Identification ID : ".$myrowB["username"]."";
        $text .= "<br/>From : ".$myrowB["division"]."";
        $text .= "<br/>Last login: ".$myrowB["lastlogin"]."";
        return $text;
    }

    function getUserType($patron_id)
    {
        $queryT = "select allowed from eg_auth where username='$patron_id'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["allowed"];
    }

    function maxday($patron_id)
    {
        $queryS = "select max_day from eg_auth_allowedloan where usertype='".getUserType($patron_id)."'";
        $resultS = mysqli_query($GLOBALS["conn"], $queryS);
        $myrowS=mysqli_fetch_array($resultS);
        return $myrowS["max_day"];
    }

    function existPatron($patron_id)
    {
        $queryT = "select count(id) as exist1 from eg_auth where username='$patron_id'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["exist1"];
    }
    
    function existCopies($accessnum)
    {
        $queryT = "select count(id) as exist1 from eg_bahan_copies where 39accessnum='$accessnum'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["exist1"];
    }
    
    function isAvailable($accessnum)
    {
        $queryT = "select 39status from eg_bahan_copies where 39accessnum='$accessnum'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        if ($myrowT["39status"] == 'AVAILABLE') {
            return "TRUE";
        } else {
            return "FALSE";
        }
    }
        
    function isPatronEligibility($patron_id)
    {
        $queryT = "select count(39patron) as jumlahMasihDiPinjam from eg_bahan_charge where 39patron='$patron_id' and 40dc!='DC'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        
        $queryS = "select max_loanitem from eg_auth_allowedloan where usertype='".getUserType($patron_id)."'";
        $resultS = mysqli_query($GLOBALS["conn"], $queryS);
        $myrowS=mysqli_fetch_array($resultS);
        
        if ($myrowT["jumlahMasihDiPinjam"] < $myrowS["max_loanitem"]) {
            return "TRUE";
        } else {
            return "FALSE";
        }
    }
    
    function getTypeName($accessnum)
    {
        $queryJenis = "select 38type from eg_jenisbahan where 38typeid=".getTypeID($accessnum);
        $resultJenis = mysqli_query($GLOBALS["conn"], $queryJenis);
        $myrowJenis=mysqli_fetch_array($resultJenis);
        return $myrowJenis["38type"];
    }

    function existCharge($accessnum)
        {
            $queryT = "select count(id) as exist1 from eg_bahan_charge where 39accessnum='$accessnum' and 40dc != 'DC'";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $myrowT=mysqli_fetch_array($resultT);
            return $myrowT["exist1"];
        }
    
    function idToType($typeid)
    {
        $query3 = "select 38type from eg_jenisbahan where 38typeid = $typeid";
        $result3 = mysqli_query($GLOBALS["conn"], $query3);
        $myrow3=mysqli_fetch_array($result3);
        return $myrow3["38type"];
    }

    function namePatron($pid)
    {
        $queryT = "select name from eg_auth where id='$pid'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["name"];
    }

    function patronIdToUsername($pid)
    {
        $queryT = "select username from eg_auth where id='$pid'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["username"];
    }

    function patronUsernametoName($pname)
    {
        $queryT = "select name from eg_auth where username='$pname'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        return $myrowT["name"] ?? '';
    }
    
    function patronUsernameToID($patron_id)
    {
        $queryT = "select id from eg_auth where username='$patron_id'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        if (isset($myrowT["id"])) {
            return $myrowT["id"];
        } else {
            return 0;
        }
    }

    function checkAccessionNumber($accessnum)
    {
        $queryT = "select count(id) as exist1 from eg_bahan_copies where 39accessnum='$accessnum'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT=mysqli_fetch_array($resultT);
        if ($myrowT["exist1"] == 0) {
            return 'FALSE';
        } else {
            return 'TRUE';
        }
    }

    function subjectFromAcronym($acronym)
    {
        $queryT = "select 43subject from eg_subjectheading where 43acronym='$acronym'";
        $resultT = mysqli_query($GLOBALS["conn"], $queryT);
        $myrowT = mysqli_fetch_array($resultT);
        if (isset($myrowT["43subject"])) {
            return $myrowT["43subject"];
        } else {
            return '';
        }
    }

    function return_bytes($val)
    {
        $val = trim($val);
        $last = strtolower($val[strlen($val)-1]);
        $val = (int)$val;
        
        $multipliers = [
            'g' => 1024 * 1024 * 1024,
            'm' => 1024 * 1024,
            'k' => 1024
        ];
        
        if (isset($multipliers[$last])) {
            $val *= $multipliers[$last];
        }
        
        return $val;
    }
