<?php defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");?>

<?php

    $currentdir = substr(getcwd(), -5);//get the current working directory
    if ($currentdir == 'admin' || $currentdir == 'ports' || $currentdir == 'atics' || $currentdir == 'wsers') {
        $appendroot = '../';
    } else {
        $appendroot = '';
    }
   
?>
    <table style='background-color:#80aaef;width:100%;margin-left:auto;margin-right:auto;'>
    <tr style='background-color:#80aaef;'><td style='height:29;text-align:right;'>
            <strong style='font-size:12pt;color:white;'><?php echo $product_name;?></strong>
            <div style='text-align:right;'>
            <?php
                if (!isset($_SESSION['username'])) {
                    echo "<a href=\"".$appendroot."opac.php?cl=ear\" CLASS=\"nav\">Start</a> | ";
                } else {
                    echo "<a href=\"".$appendroot."index2.php?cl=ear\" CLASS=\"nav\">Start</a> | ";
                }
            ?>
            <a href='<?php echo $appendroot;?>statics/i_project.php' CLASS="nav">RecentSYS SL Project</a> |
            <a href='<?php echo $appendroot;?>statics/i_about.php' CLASS="nav">About</a></div>
    </td></tr>
    </table>
