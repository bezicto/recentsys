<?php
if ($_SESSION['editmode'] <> 'SUPER' && $_SESSION['editmode'] <> 'TRUE') {
    echo "<p align=center>You do not have the right to be here. Please contact the administrator.</div>";
    exit;
}
