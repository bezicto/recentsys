 <?php

defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");

if ($inputdateUpload == null) {
    $dir_year = date("Y");
} else {
    $dir_year = substr("$inputdateUpload", -4);
}

if (is_dir("$allowed_uploaddir/$dir_year")) {
    $uploaddir = "$allowed_uploaddir/$dir_year";
} else {
    mkdir("$allowed_uploaddir/$dir_year", 0777, true);
    $uploaddir = "$allowed_uploaddir/$dir_year";
    file_put_contents("$allowed_uploaddir/$dir_year/index.php", "<html lang='en'><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1><div>You don't have permission to access this directory on this server.</div></body></html>");
}

// Check Entension
$extension = pathinfo($_FILES[$allowed_fieldname]['name']);
$extension = $extension["extension"];
$allowed_paths = explode(", ", $allowed_ext);
for ($i = 0; $i < count($allowed_paths); $i++) {
    if ($allowed_paths[$i] == "$extension") {
        $ok = "1";
    }
}

// Check File Extension
if ($ok == "1") {
    if ($_FILES[$allowed_fieldname]['size'] > $max_size) {
        $successupload = 'FALSE SIZE';
    } else {
        $successupload = 'TRUE';
    }
} else {
    $successupload = 'FALSE EXTENSION';
}
