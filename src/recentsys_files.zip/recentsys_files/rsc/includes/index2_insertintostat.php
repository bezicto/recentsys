<?php
    
    defined('includeExist') || die("<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>");
    
    if ($scstr2 <> '' || !isset($_GET["page"])) {
        if ($sctype2 != 'Author') {
            $sctype21 = 'All Type';
        } else {
            $sctype21 = 'Author';
        }

        $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT id, 37keyword, 37freq FROM eg_userlog WHERE 37keyword=? AND 37type=?");
        mysqli_stmt_bind_param($stmt, "ss", $scstr2, $sctype21);
        mysqli_stmt_execute($stmt);
        $resultPattern = mysqli_stmt_get_result($stmt);
        $num_results_Pattern = mysqli_num_rows($resultPattern);
        $myrow=mysqli_fetch_array($resultPattern);
        mysqli_stmt_close($stmt);
        
        $datePattern = date("D d/m/Y h:i a");
        if ($num_results_Pattern == 0) {
            $freqPattern = 1;
            $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_userlog VALUES (NULL, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "ssis", $scstr2, $sctype21, $freqPattern, $datePattern);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        } else {
            $freqPattern=$myrow["37freq"];
            $idPattern=$myrow["id"];
            $freqPattern = $freqPattern + 1;
            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_userlog SET 37freq=?, 37lastlog=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "isi", $freqPattern, $datePattern, $idPattern);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        $ip = $_SERVER['REMOTE_ADDR'];
        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_userlog_det VALUES (NULL, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "ssss", $scstr2, $datePattern, $ip, $sctype21);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
