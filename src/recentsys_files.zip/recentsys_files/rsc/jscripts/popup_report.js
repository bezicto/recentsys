function openPopup(url) {
    window.open(url, "popup_id", "scrollbars=no,resizable=no,width=390,height=200");
    return false;
}