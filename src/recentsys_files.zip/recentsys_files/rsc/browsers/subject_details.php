<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../config.php';
    include_once '../includes/del_code.php';
    require_once '../includes/mobiledetect.php';
    $detect = new Mobile_Detect;

    if (isset($_GET["subid"]) && is_numeric($_GET["subid"])) {
        $get_subid = $_GET["subid"];
    } else {
        $get_subid = 0;
    }
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> : Subject Browser</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    

    <?php
        include_once '../includes/loggedinfo.php';
            
        $queryU = "select 43acronym from eg_subjectheading where 43subjectid=$get_subid";
        $resultU = mysqli_query($GLOBALS["conn"], $queryU);
        $rowU = mysqli_fetch_array($resultU);
        
        $get_subacr = 'N/A';
        if (isset($rowU['43acronym'])) {
            $get_subacr = $rowU['43acronym'];
        }
        
        include_once '../includes/paging-p1.php';
        
        $query1 = "select id, 38title, 39type, 38source from eg_bahan where 39subjectheading like '%$get_subacr|%' order by 38title LIMIT $offset, $rowsPerPage";
        $result1 = mysqli_query($GLOBALS["conn"], $query1);

        //paging 2 start
        $query2 = "select count(id) as total2 from eg_bahan where 39subjectheading like '%$get_subacr|%'";
        $result2 = mysqli_query($GLOBALS["conn"], $query2);

        $myrow2=mysqli_fetch_array($result2);
        $count2=$myrow2["total2"];
        $maxPage = ceil($count2/$rowsPerPage);
        $self = $_SERVER['PHP_SELF'];
        //paging 2 end
    ?>
                        
    <hr>
    
    <div style='text-align:center;width:100%;'>

        <table style='margin-left:auto;margin-right:auto;width:100%;'>
            <tr style='background-color:#FFFE96;'><td><div style='text-align:center;width:100%;'>Subject Heading Code: <?php echo "<b>$get_subacr</b> (<em>$count2 items</em>)";?></td></tr>
        </table>

        <table style='width:100%;margin-left:auto;margin-right:auto;background-color:#EDF0F6;'>
        <tr style='background-color:lightgrey;'><td>#</td><td>Title</td><td style='width:150;'>Type</td></tr></tr>
        <?php
                $n = $offset + 1;
                
                while ($myrow=mysqli_fetch_array($result1)) {
                    echo "<tr bgcolor='EDF0F6' class='yellowHover'>";
                    
                    $id2=$myrow["id"];
                    $type2=$myrow["39type"];
                    $title2=$myrow["38title"];
                    $source2=$myrow["38source"];

                        $query2 = "select 38title_b,38title_c from eg_bahan2 where eg_bahan_id = $id2";
                        $result2 = mysqli_query($GLOBALS["conn"], $query2);
                        $myrow2=mysqli_fetch_array($result2);
                            $title2_b=$myrow2["38title_b"] ?? '';
                            $title2_c=$myrow2["38title_c"] ?? '';
                    
                    echo "<td width=40>$n</td><td style='text-align:left;'>";
                    if (!isset($_SESSION['username'])) {
                        echo "<a href='../details.php?det=$id2'>$title2 $title2_b $title2_c</a>";
                    } else {
                        echo "<a href='../details.php?det=$id2&delr=sjdir&subid=$get_subid&page=$pageNum'>$title2 $title2_b $title2_c</a>";
                    }
                    echo"</td>";
                    
                    $queryTy = "select 38type from eg_jenisbahan where 38typeid = '$type2'";
                    $resultTy = mysqli_query($GLOBALS["conn"], $queryTy);
                    $myrowTy=mysqli_fetch_array($resultTy);
                    $jenisTy=$myrowTy["38type"];
                    echo "<td>$jenisTy</td></tr>";
                                                            
                    $n = $n +1 ;
                }
        ?>
        </table>
        
        <?php
            //paging 3 start
            echo "<table align=center border=0 width=450>";
            echo "<tr bgcolor=lightgreen>";
            if ($pageNum > 1) {
                $page = $pageNum - 1;
                $prev = " [ <a href=\"$self?subid=$get_subid&page=$page\">Previous</a> ] ";
                
                $first = " [ <a href=\"$self?subid=$get_subid&page=1\">First</a> ] ";
            }  else {
                $prev  = ' [Previous] ';
                $first = ' [First] ';
            }
    
            if ($pageNum < $maxPage) {
                $page = $pageNum + 1;
                $next = " [ <a href=\"$self?subid=$get_subid&page=$page\">Next</a> ] ";
                
                $last = " [ <a href=\"$self?subid=$get_subid&page=$maxPage\">Last</a> ] ";
            } else {
                $next = ' [Next] ';
                $last = ' [Last] ';
            }
            
            if ($count2 > $rowsPerPage) {
                echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
            }
            //paging 3 ended
            echo "</tr>";
            echo "</table>";
        ?>
        
        <br/><br/>
        [ <a href="subject.php">Go to subject browser</a> ]

        
    </div>
    
    <br/><br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
