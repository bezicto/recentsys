<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../config.php';
    require_once '../includes/mobiledetect.php';
    $detect = new Mobile_Detect;
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> : Subject Browser</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>

    <?php include_once '../includes/loggedinfo.php';?>

    <hr>
    
    <div style='text-align:center;width:100%;'>
        <table style='width:350;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:white;text-align:center;'><td><b>Subject Browser Classification</b><br/></td></tr>
            <tr style='background-color:#FFFE96;'><td>
            <div style='text-align:center;width:100%;'>
                <?php
                    
                    $queryU = "select 43subjectid, 43acronym, 43subject from eg_subjectheading";
                    $resultU = mysqli_query($GLOBALS["conn"], $queryU);
                    while ($row=mysqli_fetch_array($resultU)) {
                        $id = $row['43subjectid'];
                        $acronym = $row['43acronym'];
                        
                        $querySubBahan = "select count(id) as totalSubBahan from eg_bahan where 39subjectheading like '%$acronym|%' ";
                        $resultSubBahan = mysqli_query($GLOBALS["conn"], $querySubBahan);
                        $myrowSubBahan=mysqli_fetch_array($resultSubBahan);
                        $countSubBahan=$myrowSubBahan["totalSubBahan"];//calculating subject heading per material
                        echo "<a href='subject_details.php?subid=$id'>".$row['43subject']."</a> ($countSubBahan)<br/><br/>";
                    }
                ?>
            </div>
            </td></tr>
        </table>
    
        <br/><br/>
            
        <?php
            echo "[ <a href='../".$_SESSION['ref']."'>Back to start page</a> ]";
        ?>
        
    </div>
    
    <br/><br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
