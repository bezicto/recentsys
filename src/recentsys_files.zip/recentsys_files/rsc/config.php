<?php
    if (isset($_SESSION['config_locality'])) {
        include_once $_SESSION['config_locality'];

        //version info
        $version_num = "Version 7.0 Build 20260130.1116 Internal Beta.";

        //icon and logo paths
        $mini_icon_path = "../".$_SESSION["parent_dir"].$mini_icon;
        $logo_image_path  = "../".$_SESSION["parent_dir"].$logo_image;

        //pdf upload directory
        $pdf_upload_directory = "../".$_SESSION["parent_dir"]."/docs";
        //cover upload directory
        $cover_upload_directory = "../".$_SESSION["parent_dir"]."/albums";

    }  else {
        //redirect to index if improper access
        header('Location: '.'../index.php');
        exit;
    }
