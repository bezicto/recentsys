<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once 'config.php';
    require_once './includes/mobiledetect.php';
    $detect = new Mobile_Detect;
    
    if (isset($_SESSION['username'])) {
        $tempusername = $_SESSION['username'];
        $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET online='OFF' WHERE username=?");
        mysqli_stmt_bind_param($stmt, "s", $tempusername);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        unset($_SESSION['username']);
        unset($_SESSION['fullname']);
        unset($_SESSION['editmode']);
        unset($_SESSION['lastlogin']);
        unset($_SESSION['ref']);
    } elseif (isset($_SESSION['username_myacc'])) {
        unset($_SESSION['username_myacc']);
        unset($_SESSION['lastlogin']);
    }
    
    if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enter OPAC') {
        echo "<script>document.location.href='opac.php'</script>";
    } elseif (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'My Account Portal') {
        echo "<script>document.location.href='login.php'</script>";
    }

    $datelog = date("D d/m/Y h:i a");

    //preventing CSRF
    include_once 'includes/token_validate.php';
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> | Indexing Database</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">
    function toggle_it() {
        var x = document.getElementById("adminlogin");
        if (x.style.display === "none") {
            x.style.display = "block";
        } else {
            x.style.display = "none";
        }
    }
    </script>
</head>

<body>
    <br/><br/><br/>
    
    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        
        <tr>
            <td colspan=2 style='text-align:center;'>
                <br/><img width=350 src="<?php echo $logo_image_path;?>" alt="Powered by ReCENTSYS Cloud"/>
                <br/><br/>
                <form action="index.php" method="post">
                        <button class="unstyled-button" type="submit" name="submitted" value='Enter OPAC'>
                            <img src='./images/webopacbutton.png' width=120 alt="OPAC">
                        </button>
                        
                        <button class="unstyled-button" type="submit" name="submitted" value='My Account Portal'>
                            <img src='./images/myaccountbutton.png' width=120 alt="My Account">
                        </button>
                        
                        <a href="#" onClick="toggle_it()"><img src='./images/adminloginbutton.png' width=120 border=0 alt="Admin"></a>
                </form>
            </td>
        </tr>
    </table>
    
    <div id="adminlogin" style="text-align:center;display:none;">
    
            <form action="index.php" method="post">
                <br/><b>Admin&nbspName: </b><br/><input type="text" name="username" size="25" maxlength="25"/>
                <br/><b>Password: </b><br/><input type="password" name="password" size="25" maxlength="25"/>

                <br/><br/>
                <input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?? '' ?>">
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="submit" class="form-submit-button" name="Submit1" value="Login" />
            </form>
        
    </div>
    
    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {

            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT id, username, name, aes_decrypt(passphrase,'$ppaeskeysys') as password, allowed, lastlogin, online, devmode FROM eg_auth WHERE username=?");
            mysqli_stmt_bind_param($stmt, "s", $_POST['username']);
            mysqli_stmt_execute($stmt);
            $result_login = mysqli_stmt_get_result($stmt);
            $num_results_affected_login = mysqli_num_rows($result_login);
            mysqli_stmt_close($stmt);
            
            echo "<table align='center' width=90%><tr><td style='text-align:center;'>Status : ";
            
            if ($num_results_affected_login <> 0) {
                    while ($myrow=mysqli_fetch_array($result_login)) {
                            $id2=$myrow["id"];
                            $username2=$myrow["username"];
                            $fullname2=$myrow["name"];
                            $password2=$myrow["password"];
                            $allowed2=$myrow["allowed"];
                            $date2=$myrow["lastlogin"];
                            $online2=$myrow["online"];
                            $devmode2=$myrow["devmode"];
                    }
            
                    if ($allowed2 == 'TRUE' || $allowed2 == 'SUPER') {
                        $allowed3='TRUE';
                    } else {
                        $allowed3='FALSE';
                    }
                                                                                                                            
                    if ($_POST['username'] == $username2 && $_POST['password'] == $password2 && $allowed3 == 'TRUE') {
                        if ($online2 == 'OFF' || $allowed2 == 'SUPER') {
                                echo "Authentication complete. You will be directed in no time.";
                                $_SESSION['username']=$_POST['username'];
                                $_SESSION['fullname']=$fullname2;
                                $_SESSION['editmode']=$allowed2;
                                $_SESSION['lastlogin']=$date2;
                                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET lastlogin=?, online='ON' WHERE id=?");
                                mysqli_stmt_bind_param($stmt, "si", $datelog, $id2);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_close($stmt);
                                echo "<script>document.location.href='index2.php'</script>";
                        } else {
                            echo "Improper log-out session detected. Contact your administrator.";
                        }
                    } elseif ($_POST['username'] == $username2 && $_POST['password'] == $password2 && $allowed3 == 'FALSE') {
                        echo "Inactive or patron account detected! You're not permitted to enter the system.";
                    } else {
                        echo "Incorrect authentication information detected !";
                    }
            } else {
                echo "Cannot find username !";
            }
        
            echo "</td></tr></table><br/>";
        }
    ?>

<table style='width:90%;margin-left:auto;margin-right:auto;'>
    <tr><td colspan=2><?php include_once './includes/footerbar.php';?></td></tr>
</table>
    
</body>

</html>

<?php exit;?>
