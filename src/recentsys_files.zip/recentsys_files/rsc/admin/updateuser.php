<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Update</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>

    <?php
        if (isset($_GET["edt"]) && $_GET["edt"] <> null && is_numeric($_GET["edt"])) {
            $get_id_upd = $_GET["edt"];

            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT username, allowed, division, name, devmode FROM eg_auth WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_upd);
            mysqli_stmt_execute($stmt);
            $result3 = mysqli_stmt_get_result($stmt);
            $myrow3=mysqli_fetch_array($result3);
            mysqli_stmt_close($stmt);
            $username3=$myrow3["username"];
            $division3=$myrow3["division"];
            $name3=$myrow3["name"];
            $devmode3=$myrow3["devmode"];
            $allowed3=$myrow3["allowed"];
    ?>
                               
            <table style='width:52%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:#F8EE96;'><td colspan=2 style='text-align:center;'><b>Please update the record below :</b></td></tr>
            <tr style='background-color:lightgrey;'><td colspan=2 style='text-align:center;'><br/>
                <form action="updateuser.php" method="post">
                    <table style='margin-left:auto;margin-right:auto;'>
                    <tr>
                        <td style='text-align:right;width:30%'><b>IC/ID </b></td>
                        <td style='text-align:left;'>
                            <?php
                                if ($username3 == 'admin') {
                                    echo "<input readonly=readonly type='text' name='username3' size='40' maxlength='255' value='";
                                    if ($username3 <> null) {echo $username3;}
                                    echo "'>";
                                } else {
                                    echo "<input readonly=readonly type='number' name='username3' size='40' maxlength='255' value='";
                                        if ($username3 <> null) {echo $username3;}
                                    echo "'> (<em>numbers only</em>)";
                                }
                            ?>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style='text-align:right;'><b>Full Name </b></td>
                        <td style='text-align:left;'><input type="text" name="name3" size="40" maxlength="255" value="<?php if ($name3 <> null) {echo $name3;} ?>"/></td>
                    </tr>
                    <tr>
                        <td style='text-align:right;'><b>Address </b></td>
                        <td style='text-align:left;'><textarea name="division3" cols="38" rows="5"><?php if ($division3 <> null) {echo $division3;} ?></textarea></td>
                    </tr>
                    <tr>
                    
                    <td style='text-align:right;'><b>User Level </b></td>
                    <td style='text-align:left;'><select name="allowed3">
                    <?php
                        $queryB = "select * from eg_auth_allowedloan";
                        $resultB = mysqli_query($GLOBALS["conn"], $queryB);

                        while ($myrowB=mysqli_fetch_array($resultB)) {
                            $usertypeB=$myrowB["usertype"];
                            $usertypedescB=$myrowB["usertypedesc"];
                            echo "<option value='$usertypeB'";
                            if ($usertypeB == $allowed3) {echo " selected";}
                            echo ">$usertypeB - $usertypedescB</option>";
                        }
                    ?>
                    </select></td>
                    </tr>
                    
                    <input type="hidden" name="submitted" value="TRUE" />
                    <input type="hidden" name="id3" value="<?php echo $_GET['edt'];?>" />
                    <tr><td colspan=2 style='text-align:center;'><br/><input type="submit" name="Submit1" value="Update"/></td></tr>
                    </table>
                </form>
            </td></tr>
            </table>
                    
    <?php
        }//if edt <> null
                    
        if (isset($_POST["submitted"])) {
            $name4 = $_POST["name3"];
            $username4 = $_POST["username3"];
            $division4 = $_POST["division3"];
            $devmode4= "NO";
            $id4 = $_POST["id3"];
            $allowed4 = $_POST["allowed3"];
            
            echo "<table border=1 width=50% align=center><tr><td bgcolor=white><div style='text-align:center;width:100%;'>";
            if (!empty($name4) && !empty($username4) && !empty($division4)) {
                echo "<img src='../images/tick.gif'><br/>The record has been updated. Click <em>Back</em> to see the updated user listing.";
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET name=?, username=?, division=?, devmode=?, allowed=? WHERE id=?");
                mysqli_stmt_bind_param($stmt, "sssssi", $name4, $username4, $division4, $devmode4, $allowed4, $id4);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                echo "<img src='../images/caution.jpg'><br/>Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.";
            }
            echo "</div></td></tr></table>";
        }//if submitted
    ?>
                
    <?php
        echo "<div style='width:100%;text-align:center;'>[ <a href=\"../admin/chanuser.php\">Back to users account page</a> ]</div><hr>";
    ?>
                
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
