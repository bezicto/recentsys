<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<head>
    <title>Membership Barcode Generator</title>
        <script src="../jscripts/jquery-1.5.2.min.js" type="text/javascript"></script>
        <script src="../jscripts/jquery-barcode.js" type="text/javascript"></script>
        <script src="../jscripts/jquery.qrcode.js" type="text/javascript"></script>
        <script src="../jscripts/qrcode.js" type="text/javascript"></script>
        <script>
            $(document).ready(function() {
            // get parameter from URL, urldecoded
            var strText = document.URL;

            // display the QR code
            jQuery('#selecteddiv').qrcode({
                text : strText
            });
            });
        </script>
</head>

<body>
<?php
    if ($_GET["start"] <> null && $_GET["end"] <> null && is_numeric($_GET["start"]) && is_numeric($_GET["end"])) {
        $query3 = "select id,username,name from eg_auth where id between ".$_GET['start']." and ".$_GET['end'];
        $result3 = mysqli_query($GLOBALS["conn"], $query3);
        $count3 = mysqli_num_rows($result3);
        $n=0;
        
        while ($myrow3=mysqli_fetch_array($result3)) {
            $id3 = $myrow3["id"];
            $username3 = $myrow3["username"];
            $name3 = $myrow3["name"];

            if ($n == 0 || $n % 4 == 0) {
                echo "<table align=center width='100%'>";
                echo "<tr>";
            }
?>

            <td style='text-align:right;width:20%;'>
                <table style='width:100px;border:1px solid;margin-left:auto;margin-right:auto;border-collapse: collapse;'>
                <tr>
                <td style='padding: 10px;text-align:center;'>
                    <div id='qrcodeCanvas<?php echo $id3;?>'></div>

                    <?php
                        echo "<br/><b>$name3</b><br/><span style='font-size:8px;'>$licensed_info</span>";
                    ?>
                        <script>
                            //display barcode to screen
                            $("#barcodeCanvas<?php echo $id3;?>").barcode({code:"<?php echo $username3;?>", crc:false}, "code128",{barWidth:1, barHeight:30});

                            // get the url to be converted to qr code
                            var strText = "<?php echo $username3;?>";
                            
                            // display qr code to screen
                            jQuery('#qrcodeCanvas<?php echo "$id3";?>').qrcode({
                                text : strText
                            });
                        </script>
                </td>
                </tr>
                </table>
            <br/><?php echo $id3;?>
            </td>

<?php
            if (($n+1) % 4 == 0 || $n == $count3) {
                echo "</tr><tr><td><br/><br/></td></tr>";
                echo "</table>";
            }
            
            $n=$n+1;
        }
    }
    
?>
</body>
