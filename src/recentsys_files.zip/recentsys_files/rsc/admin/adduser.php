<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Add User</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    
    
    <?php include_once '../includes/loggedinfo.php';?>
        
    <hr><br/>
    
    <?php
    
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'TRUE') {
            $staffid1 = $_POST["staffid1"];
            $fullname1 = $_POST["fullname1"];
            $division1 = $_POST["division1"];
            $allowed1 = $_POST["allowed1"];
            
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT username FROM eg_auth WHERE username = ?");
            mysqli_stmt_bind_param($stmt, "s", $staffid1);
            mysqli_stmt_execute($stmt);
            $result_username = mysqli_stmt_get_result($stmt);
            $num_results_affected_username = mysqli_num_rows($result_username);
            mysqli_stmt_close($stmt);
            
            echo "<table border=0 width=52% align=center><tr><td bgcolor=white style='text-align:center;'>";
            
            if ($num_results_affected_username == 0) {
                    if (!empty($staffid1) && !empty($fullname1) && !empty($division1) && !empty($allowed1)) {
                        echo "<img src='../images/tick.gif'><br/>User <b>$fullname1</b> has been input into the database !";
                        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_auth VALUES (NULL, ?, AES_ENCRYPT('1','$ppaeskeysys'), ?, ?, ?, '', 'OFF', 'NO')");
                        mysqli_stmt_bind_param($stmt, "ssss", $staffid1, $allowed1, $fullname1, $division1);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled. Check if any field(s) left emptied before posting.";
                    }
            } elseif ($num_results_affected_username >= 1) {
                echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled. Duplicate IC/ID detected.";
            }
            
            echo "</td></tr></table>";
        }
        
    ?>
    
    <table style='width:52%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Add new user </b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:100%;text-align:center;'><br/>
        <form action="adduser.php" method="post" enctype="multipart/form-data">

                <b>IC/ID </b><br/>
                <input type="number" name="staffid1" size="40" maxlength="255"/><br/>(<em>numbers only</em>)<br/><br/>
            
                <b>Full Name </b><br/>
                <input type="text" name="fullname1" size="40" maxlength="255"/><br/><br/>
                                    
                <b>Address </b><br/>
                <textarea name="division1" cols="38" rows="5"></textarea><br/><br/>
       
                <b>User Level </b><br/>
                <select name="allowed1">
                <?php
                    $queryB = "select * from eg_auth_allowedloan";
                    $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                
                    while ($myrow=mysqli_fetch_array($resultB)) {
                            $usertypeB=$myrow["usertype"];
                            $usertypedescB=$myrow["usertypedesc"];
                            echo "<option value='$usertypeB'>$usertypeB - $usertypedescB</option>";
                        }
                ?>
                </select><br/><br/>
                
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="submit" name="Submit1" value="Insert" />

        </form>
        </td></tr>
    </table>
    
    <br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../admin/chanuser.php">Back to users account page</a> ]</div>
    
    <br/><hr>

    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
