<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<!DOCTYPE HTML>
<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Print Barcode Range</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
        
    <hr><br/>
        
    <table style='width:52%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Display Barcode for materials with following accession range:</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:370;'><br/>
        <form target='_blank' action="qr_bprintpreview_range.php" method="get" enctype="multipart/form-data">

            <table style='margin-left:auto;margin-right:auto;'>
                <tr>
                <td><b>Range Start </b></td>
                <td><input type="text" name="start" size="20" maxlength="20"/></td>
                </tr>
                
                <tr>
                <td><b>Range End </b></td>
                <td><input type="text" name="end" size="20" maxlength="20"/></td>
                </tr>

                <tr><td colspan=2 style='text-align:center;'><br/><input type="submit" name="submitted" value="Display" /></td></tr>
            </table>
        </form>
        </td></tr>
    </table>
    
    <br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    
    <br/><hr>

    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
