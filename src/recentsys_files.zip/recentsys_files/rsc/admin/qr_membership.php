<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<head>
    <title>Membership Barcode Generator</title>
      <script src="../jscripts/jquery-1.5.2.min.js" type="text/javascript"></script>
      <script src="../jscripts/jquery.qrcode.js" type="text/javascript"></script>
      <script src="../jscripts/qrcode.js" type="text/javascript"></script>
      <script src="../jscripts/jquery-barcode.min.js" type="text/javascript"></script>
      <script>
          $(document).ready(function() {
            // get parameter from URL, urldecoded
            var strText = document.URL;

            // display the QR code
            jQuery('#selecteddiv').qrcode({
                text : strText
            });
          });
    </script>
</head>

<body>

<?php
    if ($_GET["pid"] <> null && is_numeric($_GET["pid"])) {
        $get_id = $_GET["pid"];

        $query3 = "select username,name from eg_auth where id = $get_id";
        $result3 = mysqli_query($GLOBALS["conn"], $query3);
        $myrow2=mysqli_fetch_array($result3);
        $username3=$myrow2["username"];
        $name3=$myrow2["name"];
?>

<table style='width:100px;border:1px solid;margin-left:auto;margin-right:auto;border-collapse: collapse;'>
<tr><td style='padding: 10px;text-align:center;'>
    <div id='qrcodeCanvas'></div>
        <script>
            // get url to be converted to qr code
            var strText = "<?php echo $username3;?>";
            // display qr code to screen
            jQuery('#qrcodeCanvas').qrcode({
                text : strText
            });
        </script>
        <br/>
        <div id='codeCanvas<?php echo "$username3";?>'></div>
        <script>
            // display barcode to screen
            $("#codeCanvas<?php echo $username3;?>").barcode("<?php echo "$username3";?>", "code128");
        </script>
        <br/>
        <?php
            echo "<b>$name3</b>";
        ?>
</td></tr>
</table>
<hr>

<?php
    }
?>
</body>
