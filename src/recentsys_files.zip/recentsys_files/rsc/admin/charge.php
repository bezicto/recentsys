<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_logged.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Charging</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body onload="document.getElementById('patron_id').focus();">
    
        
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
    
    <?php

        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'Charge') {
            $accessnum = $_POST["accessnum"];
            $patron_id = $_POST["patron_id"];
            $lodged_time = time();
            
            if (existPatron($patron_id) == 1 && existCopies($accessnum) == 1) {
                if (isAvailable($accessnum) == "TRUE") {
                    if (isPatronEligibility($patron_id) == "TRUE") {
                        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan_charge VALUES (NULL, ?, ?, ?, ?, 0, '', '', '', NULL, '', '', '', 0.00, 0.00, 0.00, '')");
                        mysqli_stmt_bind_param($stmt, "ssis", $accessnum, $patron_id, $lodged_time, $_SESSION['username']);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                        
                        $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan_copies SET 39status='CIRCULATED', 39lastchange=? WHERE 39accessnum=?");
                        mysqli_stmt_bind_param($stmt, "is", $lodged_time, $accessnum);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    } else {
                        echo "<script>window.alert(\"The patron has exceeded max number of loan items.\");</script>";
                    }
                } else {
                    echo "<script>window.alert(\"This material is unavailable for borrowing.\");</script>";
                }
            } else {
                echo "<script>window.alert(\"Patron not registered or material does not exist.\");</script>";
            }
        }
        
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Charging :</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:380;text-align:center;'><br/>
        <form action="charge.php" method="post" enctype="multipart/form-data">
            <b>Enter Patron ID: </b><br/>
            <input type="text" id="patron_id" name="patron_id" style="width:300px" maxlength="70" value="<?php echo $_POST["patron_id"] ?? '';?>"/>
            <input type="button" name="clear" value="Clear" style="width:50px" onclick="document.getElementById('patron_id').value='';document.getElementById('patron_id').focus();"><br/><br/>
        
            <b>Accession number: </b><br/>
            <input type="text" id="accessnum" name="accessnum" style="width:350px" maxlength="70"/><br/><br/>
                
            <input type="hidden" name="submitted" value="Charge" />
            <input type="submit" name="Submit1" value="Charge"/>
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#FFFE96;'><td colspan=5 style='text-align:center;'><b>Today's charge session :</b></td></tr>
        <tr style='background-color:#F8EE96;text-align:center;'><td>#</td><td>Accession Number</td><td>Patron</td><td>Due Date</td><td>Charge Info</td></tr>
        <?php
            //keep for references :
            //echo strtotime(date("Y-m-d"));//change today date to unix timestamp
            //echo date('D, Y-m-d h:i:s a',1370966400);//change unix timestamp to proper date and time
            
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT * FROM eg_bahan_charge WHERE 39charged_on >= ? AND 39charged_by = ?");
            $today_timestamp = strtotime(date("Y-m-d"));
            mysqli_stmt_bind_param($stmt, "is", $today_timestamp, $_SESSION['username']);
            mysqli_stmt_execute($stmt);
            $resultT = mysqli_stmt_get_result($stmt);
            $n = 1;
            while ($myrowT=mysqli_fetch_array($resultT)) {
                $accessnum=$myrowT["39accessnum"];
                $patron=$myrowT["39patron"];
                $charged_on=$myrowT["39charged_on"];
                $charged_by=$myrowT["39charged_by"];
                
                $maxSecond = maxday($patron)*86400;//to calculate due date
                $duedate = $charged_on + $maxSecond;
                
                echo "<tr bgcolor='EBF0FE'>";
                    echo "<td style='text-align:center;'>$n</td>";
                    echo "<td>$accessnum</td>";
                    echo "<td>$patron</td>";
                    echo "<td>".date('D, Y-m-d h:i:s a', $duedate)."</td>";
                    echo "<td>".date('D, Y-m-d h:i:s a', $charged_on)." by $charged_by</td>";
                echo "</tr>";
                $n = $n + 1;
            }
        ?>
    </table>
    
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
