<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>


<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Add Record</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script language="javascript" type="text/javascript">
    function popupCopies(url) {
        newwindow=window.open(url,'name','height=500,width=480');
        if (window.focus) {newwindow.focus()}
        return false;
    }
    </script>
</head>

<body>
    

    <?php include_once '../includes/loggedinfo.php';?>
            
    <hr>
    
    <?php
            if (isset($_GET['id']) && is_numeric($_GET['id'])) {
                $get_id = $_GET['id'];
            } else {
                $get_id = 0;
            }

            $query1 = "select * from eg_bahan where id='$get_id'";
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
            $myrow1=mysqli_fetch_array($result1);
                $id5=$myrow1["id"];
                $tajuk5=$myrow1["38title"];
                $isbn5 = $myrow1["38isbn"];

            echo "<table width=100% bgcolor=#FFFE96>";
            echo "<tr style='background-color:#F8EE96;text-align:center;'><td colspan=2>$tajuk5</td></tr>";
            echo "</table>";
            echo "<table width=100% bgcolor=white>";
            echo "<tr style='background-color:#FFFE96;'>";
            echo "<td colspan=2 style='text-align:center;'><b>Copies</b> : ";
            echo "<input type=button value='Add new copies' onclick=\"return popupCopies('copies_add.php?bahan_id=$get_id')\"> ";
            echo "<input type=button onClick=\"document.location.reload(true)\" value=Refresh> ";
            echo "</td></tr>";
            $queryC = "select * from eg_bahan_copies where eg_bahan_id='$get_id'";
            $resultC = mysqli_query($GLOBALS["conn"], $queryC);
            while ($myrowC=mysqli_fetch_array($resultC)) {
                echo "<tr>";
                    $copies_id=$myrowC["id"];
                    $copies_accession_number=$myrowC["39accessnum"];
                    $copies_status=$myrowC["39status"];
                    $copies_addedon=$myrowC["39addedon"];
                    $copies_lastchange=$myrowC["39lastchange"];
                    $copies_invoice_a=$myrowC["39invoice_a"];
                    $copies_invoice_b=$myrowC["39invoice_b"];
                    $copies_invoice_c=$myrowC["39invoice_c"];

                    echo "<td valign=top align=right>";
                    echo "$copies_accession_number";
                            $queryTa = "select 39status from eg_bahan_copies where 39accessnum='$copies_accession_number'";
                            $resultTa = mysqli_query($GLOBALS["conn"], $queryTa);
                            $myrowTa=mysqli_fetch_array($resultTa);
                            if ($myrowTa["39status"] != 'CIRCULATED') {
                                echo "<br/><input type=button value='Delete' onclick=\"return popupCopies('copies_delete.php?id=$copies_id')\">";
                            }
                    echo "</td>";
                    echo "<td>";
                        echo "$copies_status ";
                        echo " <input type='button' value='Change' onclick=\"window.open('change_status.php?cid=$copies_id','windowName', 'width=480,height=320,scrollbars=no')\"><br/>";
                        echo "Price: $currency_SHORT".$copies_invoice_a." | Supplier: ".$copies_invoice_b." | Invoice Number: ".$copies_invoice_c."<br/>";
                            echo "Added : ".date('D, Y-m-d h:i:s a', $copies_addedon)."<br/>Changed : ".date('D, Y-m-d h:i:s a', $copies_lastchange);
                    echo "</td>";
                echo "</tr>";
            }
            echo "</table>";
    ?>
    
    <br/><br/>
    <div style='text-align:center;width:100%;'>[ <a href="reg.php">Back to Insert New Record</a> ]</div>
    
    <br/><hr>

    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
