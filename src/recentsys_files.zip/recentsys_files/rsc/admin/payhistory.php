<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Payment History</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    
    <script type="text/javascript">
        function checkTotal()
        {
            document.listForm.f_amount.value = '';
            var sum = 0.00;
            
            if (document.listForm.chargeid_list.length == null)
            {
                var chargelistlen = 1;
                if (document.listForm.chargeid_list.checked) {
                    sum = parseFloat(document.listForm.chargeid_list.value.split(' ')[1]);
                } else {
                    sum = 0.00;
                }
            } else {
                var chargelistlen = document.listForm.chargeid_list.length;
                for (i=0;i<chargelistlen;i++) {
                  if (document.listForm.chargeid_list[i].checked) {
                        sum = sum + parseFloat(document.listForm.chargeid_list[i].value.split(' ')[1]);
                    }
                }
            }
            document.listForm.f_amount.value = sum.toFixed(2);
        }
        function changeFinalAmount()
        {
            document.listForm.f_finalamount.value = (document.listForm.f_amount.value - document.listForm.f_discount.value).toFixed(2);
        }
        function changeBalance()
        {
            document.listForm.f_balance.value = (document.listForm.f_givenamount.value - document.listForm.f_finalamount.value).toFixed(2);
        }
    </script>
    
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
        
    <?php
        if (isset($_REQUEST["f_button"]) && $_REQUEST["f_button"] == "Pay") {
            $pid = $_REQUEST["pid"];
            $f_finalamount = $_REQUEST["f_finalamount"];
            $f_discount = $_REQUEST["f_discount"];
            $f_givenamount = $_REQUEST["f_givenamount"];
            
            if (!empty($_POST['chargeid_list'])) {
                foreach ($_POST['chargeid_list'] as $check) {
                    $checkA = explode(' ', $check);
                    $check = $checkA[0];
                    $current_time = time();
                    $receipt_id = $pid . $current_time;
                    $stmt = mysqli_prepare(
                        $GLOBALS["conn"],
                        "UPDATE eg_bahan_charge
                        SET 41f_pay='YES',
                        41f_paidon=?,
                        41f_received=?,
                        41f_received_amount=?,
                        41f_discount_amount=?,
                        41f_given_amount=?,
                        41f_receipt_id=?
                        WHERE id=?"
                    );
                    mysqli_stmt_bind_param($stmt, "sssssss", $current_time, $_SESSION['username'], $f_finalamount, $f_discount, $f_givenamount, $receipt_id, $check);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                }
            }
            
            echo "<script>window.alert(\"Thank you for the payment of : $currency_SHORT $f_finalamount\");</script>";
        }
    ?>
        
    <form action="payhistory.php" name="listForm" method="post" enctype="multipart/form-data">
    
        <table style='width:80%;margin-left:auto;margin-right:auto;background-color:white;'>
            
            <tr style='background-color:#F8EE96;'>
                <td colspan=5 style='text-align:center;'><b><?php echo namePatron($_REQUEST["pid"]);?></b></td>
            </tr>
        
            <tr style='background-color:white;'>
                <td style='width:5%;text-align:center;'>#</td>
                <td style='text-align:center;'>Material accession num:</td>
                <td style='text-align:center;'>Late statement</td>
                <td style='text-align:center;'>Fines</td>
                <td style='text-align:center;'>Pay ?</td>
            </tr>
        
            <?php

                $queryT = "select * from eg_bahan_charge where 39patron='".patronIdToUsername($_REQUEST["pid"])."' and 41f_pay!='YES' and 40dc='DC'";
                $resultT = mysqli_query($GLOBALS["conn"], $queryT);
                $n = 1;
                $amountdue = 0;
                while ($myrow=mysqli_fetch_array($resultT)) {
                    $id=$myrow["id"];
                    $patron=$myrow["39patron"];
                    $accessnum=$myrow["39accessnum"];
                    $charged_on=$myrow["39charged_on"];
                    $dc_on=$myrow["40dc_on"];
                    $dc=$myrow["40dc"];
                    $dc_enforcedfine=$myrow["40dc_enforcedfine"];
                    $duedate_mp=$myrow["39duedate"];
                    
                    $maxSecond = (maxday($patron)*($duedate_mp+1))*86400;//for calculating due date
                    $beginOfDay_for_charged_on = strtotime("midnight", $charged_on);//early morning for the day charged
                    $duedate = $beginOfDay_for_charged_on + $maxSecond + 86399;// + 86399 to reach midnight
                    $duedate = shiftDueDate($duedate); //shifting duedate if holiday
                    
                    if ($dc_on <> null && $dc_on != 0) {
                        $minusdays = (($dc_on - $duedate)/86400) + 1;
                    } else {
                        $minusdays = 0;
                    }
                    
                    $fines2pay = calculatedFines(floor($minusdays), $accessnum, $dc_enforcedfine);
                    
                    $amountdue = 0;
                    if ($minusdays >= 0) {
                        echo "<tr bgcolor='EBF0FE'><td>$n</td>";
                        echo "<td>".getTitle($accessnum)."<br/>$accessnum</td>";
                        echo "<td>Charged on: ".date('D, Y-m-d h:i:s a', $charged_on)."<br/>Due Date: ".date('D, Y-m-d', $duedate)."<br/>Returned: ".date('D, Y-m-d h:i:s a', $dc_on)."<br/><br/><u>".floor($minusdays)." days</u></td>";
                        echo "<td style='text-align:center;'>";
                        if ($minusdays >= 0) {
                            echo "$currency_SHORT $fines2pay";
                        } else {
                            echo "-";
                        }
                        echo "</td>";
                        echo "<td style='text-align:center;'><input type='checkbox' onchange='checkTotal()' id='chargeid_list' name='chargeid_list[]' value='$id $fines2pay'></td>";
                        echo "</tr>";
                        $amountdue = $amountdue + $fines2pay;
                        $n = $n + 1;
                    }
                }
            ?>
        </table>
        
        <br/>
        
        <table style='width:80%;margin-left:auto;margin-right:auto;background-color:white;'>
            <tr style='background-color:#F8EE96;'>
                <td style='text-align:center;'>
                    <b>Total Amount Due : </b><?php echo "$currency_SHORT $amountdue";?>
                    <input type="hidden" name="pid" value="<?php echo $_REQUEST["pid"];?>"><br/>
                    
                    <br/>Pay: (Please tick on the checkbox above)<br/><input readonly type="text" name="f_amount" size="15" maxlength="7" value="0.00"/>
                    
                    <br/><br/>Waiver/Discount: <br/><input type="text" name="f_discount" size="15" maxlength="7" value="0.00" onchange='changeFinalAmount()'/>
                    <input type="button" name="Calc" value="Calculate Final Amount" onclick='changeFinalAmount()'>
                    
                    <br/><br/>Final Amount: <br/><input type="text" readonly name="f_finalamount" size="15" maxlength="7" value="0.00"/>

                    <hr>

                    <br/>Tendered Amount: <br/><input type="text" name="f_givenamount" size="15" maxlength="7" value="0.00" onchange='changeBalance()'/>
                    <input type="button" name="Calc" value="Calculate Balance" onclick='changeBalance()'>
                    <br/><br/>Balance to return: <br/><input type="text" name="f_balance" readonly size="15" maxlength="7" value="0.00"/>
                    
                    <br/><br/><input type="submit" name="f_button" value="Pay" onclick="return confirm('Are you sure to charge the patron for : <?php echo $currency_SHORT;?> '+document.listForm.f_finalamount.value+' (Discount: <?php echo $currency_SHORT;?> '+document.listForm.f_discount.value+')?')">
                </td>
            </tr>
        </table>
                    
    </form>
        
    <br/><br/>
        
    <div style='text-align:center;width:100%;'>
        <?php
            if (isset($_SESSION['paysearch'])) {
                echo "[ <a href=\"paysearch.php\">Search for other patron fines</a> ]";
            } else {
                echo "[ <a href=\"userhistory.php?pid=".$_REQUEST["pid"]."\">Back to user history page</a> ]";
            }
        ?>
    </div>
    
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
