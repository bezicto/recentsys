<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Duplicate Finder</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>

    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>
            
    <div style='width:100%;text-align:center;'>
        <?php
                
            $query1 = "select count(*) as num, 38title, 39type from eg_bahan ";
            $query1 .= "group by 38title having count(*) > 1 order by 39type,38title";
            
            $result1 = mysqli_query($GLOBALS["conn"], $query1);

            echo "<table align=center border=0 width=100% bgcolor=#FFFE96>";
            echo "<tr bgcolor=#FFFE96 align=center><td><b>Detected Duplicates</b>:";
            echo "</td></tr></table>";

            echo "<table border='0' width='100%' bgcolor='white'>";
            echo "<tr style='background-color:white;text-align:center;' class='yellowHover'>";
            echo "<td align=center>#</td>";
            echo "<td style='text-align:center;'>Title</td>";
            echo "<td align=center width=150px>(Approx.) # of duplicate</td>";
            echo "</tr>";
                                                                            
            $n = 1;
                                    
            while ($myrow=mysqli_fetch_array($result1)) {
                echo "<tr bgcolor='EBF0FE' class='yellowHover'>";
                $num2=$myrow["num"];
                $tajuk2=$myrow["38title"];
                $type2=$myrow["39type"];
                
                echo "<td style='text-align:center;'>$n</td>";
                $tajuk2converted = stripslashes(str_replace('"', '&#34;', $tajuk2));//replace " with &#34
                $tajuk2converted = str_replace('\'s', '', $tajuk2converted);//remove 's
                $tajuk2converted = str_replace('\'', '', $tajuk2converted);//remove '
                $searchurl = '../index2.php?scstr='.$tajuk2converted.'&scflag=Search&sctype=All+Type';
                echo "<td style='text-align:left;'><a href=\"$searchurl\">$tajuk2</a>";
                echo "<td style='text-align:center;'>$num2</td>";
                echo "</tr>";
                $n = $n +1 ;
            }
            echo "</table>";
        ?>
        
        <br/>[ <a href="../index2.php">Back to start page</a> ]
    
    </div>

    <hr>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
