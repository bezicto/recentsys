<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Update Type</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
                    
    <hr>

    <?php
         
        if (isset($_GET["edt"]) && $_GET["edt"] <> null && is_numeric($_GET["edt"])) {
            $get_id_upd = $_GET["edt"];

            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT 38type, 38defaultlocation FROM eg_jenisbahan WHERE 38typeid = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_upd);
            mysqli_stmt_execute($stmt);
            $result3 = mysqli_stmt_get_result($stmt);
            $myrow3=mysqli_fetch_array($result3);
            mysqli_stmt_close($stmt);
            $type3=$myrow3["38type"];
            $defaultlocation3=$myrow3["38defaultlocation"];
            
    ?>
            <table style='width:80%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Please update the type below :</b></td></tr>
            <tr style='background-color:lightgrey;'><td style='text-align:center;'><br/>
            <form action="updatetype.php" method="post">
                <b>Type: </b><br/>
                <input type="text" name="type3" style="width:50%" maxlength="50" value="<?php if ($type3 <> null) {echo $type3;} ?>"/><br/><br/>
                
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="hidden" name="id3" value="<?php echo $_GET['edt'];?>" />
                <input type="submit" name="Submit1" value="Update"/>
            </form>
            </td></tr>
            </table>
        
    <?php
        }//if edt <> null

        if (isset($_POST["submitted"])) {
            $type4 = $_POST["type3"];
            $id4 = $_POST["id3"];

            echo "<table border=0 width=50% align=center><tr><td style='text-align:center;'>";
            if (!empty($type4)) {
                echo "<img src='../images/tick.gif'><br/><br/>The record has been updated. Click <em>Back</em> to see the updated type listing.";
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_jenisbahan SET 38type=? WHERE 38typeid=?");
                mysqli_stmt_bind_param($stmt, "si", $type4, $id4);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                echo "<img src='../images/caution.jpg'><br/><br/>Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.";
            }
            echo "</td></tr></table>";
        }//if submitted
    ?>
    
    <?php
        echo "<div style='width:100%;text-align:center;margin-top:20px;'>[ <a href=\"addtype.php\">Back</a> ]</div><hr>";
    ?>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
