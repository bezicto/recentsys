<!DOCTYPE HTML>

<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Change Eligibility</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
    
    <?php
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce' && is_numeric($_POST["max_day"]) && is_numeric($_POST["max_loanitem"]) && $_POST["usertype"] != '') {
            $usertype = $_POST["usertype"];
            $usertypedesc = $_POST["usertypedesc"];
            $max_day = $_POST["max_day"];
            $max_loanitem = $_POST["max_loanitem"];
            
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT id FROM eg_auth_allowedloan WHERE usertype = ?");
            mysqli_stmt_bind_param($stmt, "s", $usertype);
            mysqli_stmt_execute($stmt);
            $resultid = mysqli_stmt_get_result($stmt);
            $num_results_affected = mysqli_num_rows($resultid);
            mysqli_stmt_close($stmt);
            
            if ($num_results_affected == 0) {
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_auth_allowedloan VALUES (NULL, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "ssii", $usertype, $usertypedesc, $max_day, $max_loanitem);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                echo "<script>window.alert(\"Record has been inputted into the database.\");</script>";
            } elseif ($num_results_affected == 1) {
                echo "<script>window.alert(\"Duplicate user type detected.\");</script>";
            }
        } elseif (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce' && (!is_numeric($_POST["max_day"]) || !is_numeric($_POST["max_loanitem"]) || $_POST["usertype"] == '')) {
            echo "<script>window.alert(\"Check your input.\");</script>";
        }
        
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Update') {
            $usertype = $_POST["usertype"];
            $usertypedesc = $_POST["usertypedesc"];
            $max_day = $_POST["max_day"];
            $max_loanitem = $_POST["max_loanitem"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth_allowedloan SET usertype=?, usertypedesc=?, max_day=?, max_loanitem=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ssiii", $usertype, $usertypedesc, $max_day, $max_loanitem, $_POST['aid']);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            echo "<script>window.alert(\"Record has been updated into the database.\");</script>";
        }
        
        $max_dayA = ""; $max_loanitemA = "";
        //aid
        if (isset($_GET['aid']) && is_numeric($_GET['aid'])) {
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT * FROM eg_auth_allowedloan WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $_GET['aid']);
            mysqli_stmt_execute($stmt);
            $resultA = mysqli_stmt_get_result($stmt);
            while ($myrowA=mysqli_fetch_array($resultA)) {
                $usertypeA=$myrowA["usertype"];
                $usertypedescA=$myrowA["usertypedesc"];
                $max_dayA=$myrowA["max_day"];
                $max_loanitemA=$myrowA["max_loanitem"];
            }
        
        ?>
    
    <table style='width:70%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Eligibility status </b></td></tr>
        
        <tr style='background-color:lightgrey;'><td style='width:370;text-align:center;'><br/>
        <form action="chan_loandays.php" method="post" enctype="multipart/form-data">
                
                <b>User Type: </b><br/>
                <input type="text" readonly name="usertype" size="35" maxlength="70" value="<?php echo $usertypeA ?? '';?>"/><br/><br/>
                
                <b>User Type Description:</b><br/>
                <input type="text" readonly name="usertypedesc" size="35" maxlength="70" value="<?php echo $usertypedescA ?? '';?>"/><br/><br/>
                
                <b>Total days allowed an item to be loaned: </b><br/>
                <select name="max_day">
                    <?php
                        $n = 0;
                        while ($n <= 20) {
                            echo "<option value='$n' "; if ($max_dayA == $n) {echo "selected";} echo ">$n</option>";
                            $n++;
                        }
                    ?>
                </select><br/><br/>

                <b>Total number of allowed borrowed items: </b><br/>
                <select name="max_loanitem">
                    <?php
                        $n = 0;
                        while ($n <= 20) {
                            echo "<option value='$n' ";
                            if ($max_loanitemA == $n) {echo "selected";}
                            echo ">$n</option>";
                            $n++;
                        }
                    ?>
                </select><br/><br/>
            
                <?php
                if (!isset($_GET['aid'])) {
                    echo "<input type=\"submit\" name=\"submitted\" value=\"Enforce\" />";
                } else {
                        echo "<input type=\"hidden\" name=\"aid\" value='".$_GET['aid']."' />";
                        echo "<input type=\"submit\" name=\"submitted\" value=\"Update\" />";
                }
                ?>
                <input type="button" name="reset" value="Cancel" onclick="window.location='chan_loandays.php';"/>

        </form>
    </td></tr>
    
    </table>
        
    <br/><br/>
    <?php
        //aid
        } else {
    ?>

    <table style='width:70%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#FFFE96;'><td colspan=6 style='text-align:center;'><b>Type Listing and Controls :</b></td></tr>
        <tr style='background-color:white;text-align:center;'>
            <td style='width:25;text-align:center;'>#</td>
            <td style='width:35%;text-align:center;'>User Type</td>
            <td style='width:20%;text-align:center;'>User Type Description</td>
            <td style='text-align:center;'>Max Day</td>
            <td style='text-align:center;'>Max Loan Item</td>
            <td style='text-align:center;'>Options</td>
        </tr>

        <?php
            $queryT = "select * from eg_auth_allowedloan";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $n = 1;
            while ($myrow=mysqli_fetch_array($resultT)) {
                    $id=$myrow["id"];
                    $usertypeT=$myrow["usertype"];
                    $usertypedescT=$myrow["usertypedesc"];
                    $max_dayT=$myrow["max_day"];
                    $max_loanitemT=$myrow["max_loanitem"];
                    echo "<tr bgcolor='EBF0FE'>";
                        echo "<td style='text-align:center;'>$n</td>";
                        echo "<td>$usertypeT</td><td>$usertypedescT</td>";
                        echo "<td>$max_dayT</td>";
                        echo "<td>$max_loanitemT</td>";
                        echo "<td style='text-align:center;'>[<a href='chan_loandays.php?aid=$id'>Edit</a>]</td>";
                    echo "</tr>";
                    $n = $n + 1;
                }
        ?>
    </table>
    <?php
        }
    ?>
    <br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../admin/chanuser.php">Back to users account page</a> ]</div>
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
</body>

</html>
