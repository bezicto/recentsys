<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Update Type</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>
    
    <?php
        if (isset($_GET["edt"]) && $_GET["edt"] <> null && is_numeric($_GET["edt"])) {
            $get_id_upd = $_GET["edt"];

            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT 43subject, 43acronym FROM eg_subjectheading WHERE 43subjectid = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_upd);
            mysqli_stmt_execute($stmt);
            $result3 = mysqli_stmt_get_result($stmt);
            $myrow3=mysqli_fetch_array($result3);
            mysqli_stmt_close($stmt);
            $subject3=$myrow3["43subject"];
            $acronym3=$myrow3["43acronym"];
    ?>
                    
            <table style='width:90%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Please update the subject heading below :</b></td></tr>
            <tr style='background-color:lightgrey;'><td style='text-align:center;'><br/>
            <form action="updatesubject.php" method="post">
                <b>Subject: </b><br/>
                <input type="text" name="subject3" style="width:50%" maxlength="70" value="<?php if ($subject3 <> null) {echo $subject3;} ?>"/><br/><br/>

                <b>Subject Code: </b><br/>
                <input type="text" name="acronym3" style="width:50%" maxlength="50" value="<?php if ($acronym3 <> null) {echo $acronym3;} ?>"/><br/><br/>
           
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="hidden" name="id3" value="<?php echo $_GET['edt'];?>" />
                <input type="submit" name="Submit1" value="Update"/>
            </form>
            </td></tr>
            </table>
        
    <?php
        }//if edt <> null

        if (isset($_POST["submitted"])) {
            $subject4 = $_POST["subject3"];
            $acronym4 = $_POST["acronym3"];
            $id4 = $_POST["id3"];
                        
            echo "<table border=0 width=90% align=center><tr><td style='text-align:center;'>";
                if (!empty($subject4) && !empty($acronym4)) {
                    echo "<img src='../images/tick.gif'><br/><br/>The record has been updated. Click <em>Back</em> to see the updated subject headings listing.";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_subjectheading SET 43subject=?, 43acronym=? WHERE 43subjectid=?");
                    mysqli_stmt_bind_param($stmt, "ssi", $subject4, $acronym4, $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='../images/caution.jpg'><br/><br/>Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.";
                }
            echo "</td></tr></table>";
        }//if submitted
                    
        echo "<div style='width:100%;text-align:center;margin-top:20px;'>[ <a href=\"addsubject.php\">Back</a> ]</div><hr>";
    ?>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
