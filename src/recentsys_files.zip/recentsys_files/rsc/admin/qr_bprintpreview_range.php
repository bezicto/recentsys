<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<head>
    <title>Book Barcode Generator</title>
    <script src="../jscripts/jquery_1_11_1.min.js" type="text/javascript"></script>
    <script src="../jscripts/jquery-barcode.min.js" type="text/javascript"></script>
</head>

<?php
    if ($_GET["start"] <> null && $_GET["end"] <> null && is_numeric($_GET["start"]) && is_numeric($_GET["end"])) {
        $query3 = "select 39accessnum, eg_bahan_id from eg_bahan_copies where 39accessnum between ".$_GET['start']." and ".$_GET['end'];
        $result3 = mysqli_query($GLOBALS["conn"], $query3);
        $count3 = mysqli_num_rows($result3);
        $n=0;
        
        while ($myrow2=mysqli_fetch_array($result3)) {
            $accessnum3=$myrow2["39accessnum"];
            $bahan_id3=$myrow2["eg_bahan_id"];
            
            $queryTitle = "select 38title,38localcallnum from eg_bahan where id='$bahan_id3'";
            $resultTitle = mysqli_query($GLOBALS["conn"], $queryTitle);
            $myrowTitle=mysqli_fetch_array($resultTitle);
            $tajuk3=$myrowTitle["38title"];
            $localcallnum3=$myrowTitle["38localcallnum"];
            
            if ($n == 0 || $n % 3 == 0) {
                echo "<table align=center width='100%' border=0>";
                echo "<tr>";
            }
?>

            <td style='text-align:center;'>
                <table style='border:1px solid;width:250px;margin-left:auto;margin-right:auto;border-collapse: collapse;'>
                    <tr>
                    <td style='border:1px solid;padding: 10px;width:100px;'>
                        <div style='text-align:center;'><b><?php echo $localcallnum3;?></b></div>
                    </td>
                    <td style='border:1px solid;padding: 10px;'></td>
                    <td style='border:1px solid;text-align:center;padding: 10px;width:150px;'>
                        <?php echo "$tajuk3";?><br/><br/>
                        <div id='codeCanvas<?php echo "$accessnum3";?>'></div>
                        <script>
                            $("#codeCanvas<?php echo $accessnum3;?>").barcode("<?php echo "$accessnum3";?>", "code128");//displaying barcode to screen
                        </script>
                    </td>
                </tr>
                </table>
            </td>

<?php
        if (($n+1) % 3 == 0 || $n == $count3) {
            echo "</tr><tr><td colspan=3><br/><br/></td></tr>";
            echo "</table>";
        }
        
        $n=$n+1;
        }
    }
    
?>
