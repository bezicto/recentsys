<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Change User Account Type</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <style>
        td span{float:right;}
        td span:first-child{float:left;}
    </style>
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>
    
    <?php
        
            if (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null) {
                $get_id_del = $_GET["del"];
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET allowed='FALSE', devmode='NO' WHERE id=?");
                mysqli_stmt_bind_param($stmt, "i", $get_id_del);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
                
            if (isset($_GET["res"]) && is_numeric($_GET["res"]) && $_GET["res"] <> null) {
                $get_id_res = $_GET["res"];
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET passphrase=AES_ENCRYPT('1','$ppaeskeysys') WHERE id=?");
                mysqli_stmt_bind_param($stmt, "i", $get_id_res);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
            
            if (isset($_GET["offuser"]) && is_numeric($_GET["offuser"]) && $_GET["offuser"] <> null) {
                $get_id_offuser = $_GET["offuser"];
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET online='OFF' WHERE id=?");
                mysqli_stmt_bind_param($stmt, "i", $get_id_offuser);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            }
            
    ?>

    <div style='width:100%;text-align:center;'>
    
    <?php
        
        $query1 = "select id, username, allowed, name, division, online, devmode, lastlogin  from eg_auth order by id";
        $result1 = mysqli_query($GLOBALS["conn"], $query1);
        $num_results_affected = mysqli_num_rows($result1);
        
        echo "<table style='width:90%;margin-left:auto;margin-right:auto;background-color:#FFFE96;'><tr bgcolor=#FFFE96 align=center><td>";
            echo "<b>Total user in the system</b>: $num_results_affected <em>record(s) found.</em> ";
            echo "To search use CTRL+F (Windows) or CMD+F (macOS).</td><td style='text-align:right;'>";
            echo "<a class='toggleopacity' href='../admin/qr_printrange.php'><img src='../images/hewb_bar.png' height=36 border=0 title='Print barcode range for membership'></a> ";
            echo "<a class='toggleopacity' href='../admin/chan_loandays.php'><img src='../images/hewb_eli.png' height=36 border=0 title='Add/Edit Types and Eligibility'></a> ";
            echo "<a class='toggleopacity' href='../admin/adduser.php'><img src='../images/hewb_adduser.png' height=36 border=0 title='Add new system user'></a> ";
        echo "</td></tr></table>";
                                                        
        echo "<table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>";
        echo "<tr style='background-color:lightgrey;text-align:center;'>";
            echo "<td>#</td>";
            echo "<td><span>IC/ID</span> <span>(dbID)</span></td>";
            echo "<td>Full Name</td>";
            echo "<td>Account Type</td>";
            echo "<td>Option</td>";
            echo "<td>Status</td>";
        echo "</tr>";
                                                
        $n = 1;
        
        while ($myrow=mysqli_fetch_array($result1)) {
            echo "<tr class=yellowHover>";
                $username2=$myrow["username"];
                $allowed2=$myrow["allowed"];
                $name2=$myrow["name"];
                $division2=$myrow["division"];
                $online2=$myrow["online"];
                $id2=$myrow["id"];
                $devmode2=$myrow["devmode"];
                $lastlogin2=$myrow["lastlogin"];
                
                echo "<td>$n</td>";
                echo "<td><span><a href='updateuser.php?edt=$id2'>$username2</a></span> <span>($id2)</span></td>";
                echo "<td>$name2</td>";
                echo "<td align='center'>$allowed2</td>";
                echo "<td style='text-align:center;'>";
                    if ($username2 != 'admin') {
                        echo "[<a href='chanuser.php?del=$id2' onclick=\"return confirm('Are you sure to set this user to inactive ? This application will be permanant.');\">Deactivate</a>]";
                    }
                    echo " [<a href='chanuser.php?res=$id2' onclick=\"return confirm('Are you sure to reset the user $username2\'s password to 1 ?');\">Reset&nbspPassword</a>]";
                    echo " [<a href='userhistory.php?pid=$id2'>History</a>]";
                    echo " [<a target='_blank' href='qr_membership.php?pid=$id2'>QR</a>]";
                echo "</td>";
                
                echo "<td style='text-align:center;'>";
                if ($online2 == 'ON') {
                    echo "[<a href='chanuser.php?offuser=$id2' onclick=\"return confirm('Are you sure to set offline to user $username2 ?');\">Set Offline</a>]<br/>";
                    echo countOnlineDuration(date("D d/m/Y h:i a"), $lastlogin2);
                } else {
                    echo "Offline";
                }
                echo "</td>";
            echo "</tr>";
            $n = $n +1 ;
        }
        
        echo "</table>";
    ?>

    <br/><br/>
    
    [ <a href="../index2.php">Back to start page</a> ]
    
    </div>
    
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
