<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Subject Heading Listing</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    
    <?php
        if (!isset($_REQUEST['fr']) || $_REQUEST['fr'] != '1') {
            include_once '../includes/loggedinfo.php';
        }
    ?>
    
    <hr>
        
    <?php
            
        if (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null) {
            $get_id_del = $_GET["del"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_subjectheading WHERE 43subjectid = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_del);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
                
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'TRUE') {
            $subject1 = $_POST["subject1"];
            $acronym1 = $_POST["acronym1"];
                        
            echo "<table border=0 width=90% align=center><tr><td bgcolor=white style='text-align:center;'>";
            if (!empty($acronym1) && (!empty($subject1))) {
                echo "<img src='../images/tick.gif'><br/>The subject <b>$subject1 ($acronym1)</b> has been inputed into the database.";
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_subjectheading VALUES (NULL, 0, ?, ?)");
                mysqli_stmt_bind_param($stmt, "ss", $acronym1, $subject1);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
                echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled.Check if any field(s) left emptied before posting.";
            }
            echo "</td></tr></table>";
        }
    
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr><td style='text-align:center;background-color:#F8EE96;'><b>Subject Heading Addition</b></td></tr>
        <tr><td style='text-align:center;background-color:lightgrey;'><br/>
            <form action="addsubject.php" method="post" enctype="multipart/form-data">
               <b>New Subject: </b><br/>
               <input type="text" name="subject1" style="width:50%" maxlength="70"/><br/><br/>

               <b>Subject Code: </b><br/>
               <input type="text" name="acronym1" style="width:50%" maxlength="50"/><br/><br/>

                <input type="hidden" name="fr" value="<?php echo $_REQUEST['fr'] ?? '';?>" />
                <input type="hidden" name="submitted" value="TRUE" />
                <input type="submit" name="Submit1" value="Insert" />
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#F8EE96;'>
            <td colspan=4><b>Subject Heading Controls :</b></td>
        </tr>
        
        <tr style='background-color:white;'>
            <td style='width:5%;text-align:center;'>#</td>
            <td style='text-align:center;'>Subject</td>
            <td style='width:150;text-align:center;'>Subject Code</td>
            <td style='width:150;text-align:center;'>Options</td>
        </tr>
        
        <?php
            $queryT = "select 43subjectid, 43acronym, 43subject from eg_subjectheading order by 43acronym";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $n = 1;
            while ($myrow=mysqli_fetch_array($resultT)) {
                    $subjectidT=$myrow["43subjectid"];
                    $acronymT=$myrow["43acronym"];
                    $subjectT=$myrow["43subject"];
                    
                    echo "<tr bgcolor='EBF0FE'>";
                        echo "<td>$n</td>";
                        echo "<td>$subjectT</td>";
                        echo "<td>$acronymT</td>";
                        echo "<td style='text-align:center;'>";
                            if (!isset($_GET['fr']) || $_GET['fr'] != '1') {
                                echo "<a title='Delete this record' href='addsubject.php?del=$subjectidT' onclick=\"return confirm('Are you sure ? You are advisable to change all items based on this subject heading to the another before proceeding.');\"><img src='../images/delete.gif'></a>";
                                echo " <a title='Update this record' href='updatesubject.php?edt=$subjectidT'><img src='../images/pencil.gif'></a>";
                            }
                        echo "</td>";
                    echo "</tr>";
                    
                    $n = $n + 1;
                }
        ?>
    </table>
        
    <br/><br/>
    
    <?php
    if (!isset($_GET['fr']) || $_GET['fr'] != '1') {?>
        <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
        <br/><hr><?php include_once '../includes/footerbar.php';?>
    <?php
    } else {
        echo "<div style='text-align:center;width:100%;'><FORM><INPUT type=\"button\" value=\"Close\" onClick=\"window.close()\"> </FORM></div>";
    }
    ?>
    
</body>

</html>
