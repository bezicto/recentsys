<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    if (isset($_SESSION["username"])) {
        include_once '../includes/access_isset.php';
    } elseif (isset($_SESSION["username_myacc"])) {
        include_once '../includes/access_isset_myacc.php';
    } else {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Direct access prohibited</h2><em>System Response Code</em></div>";
        exit;
    }
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Password Control</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
      
    <?php
    if (isset($_SESSION["username"])) {
        include_once '../includes/loggedinfo.php';
    } elseif (isset($_SESSION["username_myacc"])) {
        ?>
        <table style='width:70%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:white;'>
                <td>Change password for user: <span style='color:blue;'><?php echo $_SESSION["username_myacc"];?></span></td>
            </tr>
        </table>
        <?php
    }
    ?>
    
    <hr>
                
    <?php
        
        $username3 = $_SESSION['username'] ?? $_SESSION["username_myacc"];
                
        if (isset($_GET["upd"]) && $_GET["upd"] <> null) {
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT AES_DECRYPT(passphrase,'$ppaeskeysys') as password FROM eg_auth WHERE username = ?");
            mysqli_stmt_bind_param($stmt, "s", $username3);
            mysqli_stmt_execute($stmt);
            $result3 = mysqli_stmt_get_result($stmt);
            $myrow3=mysqli_fetch_array($result3);
            mysqli_stmt_close($stmt);
            $password3=$myrow3["password"];
    ?>
    
            <table style='width:70%;margin-left:auto;margin-right:auto;background-color:#F8EE96;'>
                <tr style='background-color:#F8EE96;'><td>
                    <div style='text-align:center;width:100%;'><b>Please input your new password alongside with it confirmation :</b></div>
                </td></tr>
            </table>
                        
            <form action="passchange.php" method="post">
                <table style='width:70%;margin-left:auto;margin-right:auto;background-color:lightgrey;'>
                <tr>
                    <td style='text-align:right;width:20%;vertical-align:top;'><b>Password:</b></td>
                    <td><input type="password" name="password3" size="25" maxlength="40" value="<?php if ($password3 <> null) {echo $password3;} ?>"/> (overwrite the old password with the new one)</td>
                </tr>
                <tr>
                    <td style='text-align:right;vertical-align:top;'><b>Password:</b></td>
                    <td><input type="password" name="password3a" size="25" maxlength="40"/> (confirmation, please rewrite as above password)</td>
                </tr>
                <input type="hidden" name="submitted" value="TRUE" />
                <tr><td colspan=2 style='text-align:right;'><div style='text-align:center;width:100%;'><input type="submit" name="Submit1" value="Update"/></div></td></tr>
                </table>
            </form>
                                    
    <?php
        }//if upd <> null
                
        if (isset($_POST["submitted"])) {
            $password4 = $_POST["password3"];
            $password4a = $_POST["password3a"];
            
            echo "<table border=1 width=70% align=center><tr><td bgcolor=white><div style='text-align:center;width:100%;'>";

            if (!empty($password4)) {
                if ($password4 == $password4a) {
                    echo "<img src='../images/tick.gif'><br/>Your password has been updated. Click <a href='../index.php'>here</a> to log in with the new password.";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET passphrase=AES_ENCRYPT(?,'$ppaeskeysys') WHERE username=?");
                    mysqli_stmt_bind_param($stmt, "ss", $password4, $username3);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='../images/caution.jpg'><br/>Confirmation failed. Click <a href='javascript:javascript:history.go(-1)'>here</a> to reinput the password.";
                }
            } else {
                echo "<img src='../images/caution.jpg'><br/>Please insert any empty field ! Click <a href='javascript:javascript:history.go(-1)'>here</a> to retry.";
            }
            
            echo "</div></td></tr></table>";
        } else {
            echo "<br/><div style='width:100%;text-align:center;'>[ <a href='javascript:javascript:history.go(-1)'>Back to main page</a> ]</div><br/>";
        }
    ?>

    <hr>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
