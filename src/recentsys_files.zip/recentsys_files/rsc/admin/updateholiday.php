<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Update Holiday</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>
    
    <?php
        if (isset($_GET["edt"]) && $_GET["edt"] <> null && is_numeric($_GET["edt"])) {
            $get_id_upd = $_GET["edt"];

            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT 38hol_title, 38hol_date FROM eg_holiday WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_upd);
            mysqli_stmt_execute($stmt);
            $result3 = mysqli_stmt_get_result($stmt);
            $myrow3=mysqli_fetch_array($result3);
            mysqli_stmt_close($stmt);
            $title3=$myrow3["38hol_title"];
            $date3=$myrow3["38hol_date"];
    ?>
                    
            <table style='width:90%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Please update the holiday below :</b></td></tr>
            <tr style='background-color:lightgrey;'><td style='text-align:center;'>
                <form action="updateholiday.php" method="post">
                    <b>Description: </b><br/>
                    <input type="text" name="title3" style="width:50%" maxlength="70" value="<?php if ($title3 <> null) {echo $title3;} ?>"/><br/><br/>
                    
                    <b>Date: </b><em>Format: dd/mm/yyyy eg. 31/12/2019</em><br/>
                    <input type="text" name="date3" style="width:50%" maxlength="50" value="<?php if ($date3 <> null) {echo $date3;} ?>"/><br/><br/>
                    
                    <input type="hidden" name="submitted" value="TRUE" />
                    <input type="hidden" name="id3" value="<?php echo $_GET['edt'];?>" />
                    <input type="submit" name="Submit1" value="Update"/>
                </form>
            </td></tr>
            </table>
        
    <?php
        }//if edt <> null

        if (isset($_POST["submitted"])) {
            $title4 = $_POST["title3"];
            $date4 = $_POST["date3"];
            $id4 = $_POST["id3"];

            echo "<table border=0 width=90% align=center><tr><td style='text-align:center;'>";
                if (!empty($title4) && !empty($date4)) {
                    echo "<img src='../images/tick.gif'><br/><br/>The record has been updated. Click <em>Back</em> to see the updated holidays listing.";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_holiday SET 38hol_title=?, 38hol_date=? WHERE id=?");
                    mysqli_stmt_bind_param($stmt, "ssi", $title4, $date4, $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='../images/caution.jpg'><br/><br/>Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.";
                }
        
            echo "</td></tr></table>";
        }//if submitted
                    
        echo "<div style='width:100%;text-align:center;margin-top:20px;'>[ <a href=\"addholiday.php\">Back</a> ]</div><hr>";
    ?>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
