<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Patron Charge/Discharge History</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>

    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
    
    <table style='width:100%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#F8EE96;'>
            <td colspan=8 style='text-align:center;'><b><?php echo namePatron($_REQUEST["pid"]);?></b></td>
        </tr>
        
        <tr style='background-color:white;'>
            <td style='width:5%;text-align:center;'>#</td>
            <td style='text-align:center;'>Title</td>
            <td style='text-align:center;'>Charged on</td>
            <td style='text-align:center;'>Due Date</td>
            <td style='text-align:center;'>Renew<br/>count</td>
            <td style='text-align:center;'>Discharged on</td>
            <td style='text-align:center;'>Late ?</td>
            <td style='text-align:center;'>Fines</td>
        </tr>
        
        <?php
            
            $queryT = "select * from eg_bahan_charge where 39patron='".patronIdToUsername($_REQUEST["pid"])."'";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $n = 1;
            $beforepaymenton = "0000";
            $beforepaymentrcv = "0000";
            while ($myrow=mysqli_fetch_array($resultT)) {
                    $patron=$myrow["39patron"];
                    $accessnum=$myrow["39accessnum"];
                    $charged_on=$myrow["39charged_on"];
                    $dc_on=$myrow["40dc_on"];
                    $dc=$myrow["40dc"];
                    $dc_enforcedfine=$myrow["40dc_enforcedfine"];
                    $duedate_mp=$myrow["39duedate"];
                    $received_amount=$myrow["41f_received_amount"];
                    $discount_given=$myrow["41f_discount_amount"];
                    $paidon=$myrow["41f_paidon"];
                    $paidrb=$myrow["41f_received"];
                    $paid_rid=$myrow["41f_receipt_id"];
                    
                    if ($myrow["41f_pay"] == 'YES') {
                        $f_pay="PAID";
                    } else {
                        $f_pay="<a href='payhistory.php?pid=".$_REQUEST["pid"]."'>Pay</a>";
                    }
                    
                    $maxSecond = (maxday($patron)*($duedate_mp+1))*86400;//for calculating due date
                    $beginOfDay_for_charged_on = strtotime("midnight", $charged_on);// start of day for the charged day
                    $duedate = $beginOfDay_for_charged_on + $maxSecond + 86399;// + 86399 to reach midnight
                    $duedate = shiftDueDate($duedate);//shifting duedate if holiday

                    if ($dc_on <> null && $dc_on != 0) {
                        $minusdays = (($dc_on - $duedate)/86400) + 1;
                    } else {
                        $minusdays = ((time() - $duedate)/86400) + 1;
                    }
                    
                    echo "<tr bgcolor='EBF0FE'><td>$n</td>";
                    echo "<td>".getTitle($accessnum)."<br/><em>$accessnum</em></td>";
                    echo "<td>".date('D, Y-m-d h:i:s a', $charged_on)."</td>";
                    echo "<td>".date('D, Y-m-d h:i:s a', $duedate)."</td>";
                    echo "<td style='text-align:center;'>$duedate_mp</td>";
                    if ($dc_on != '') {
                        echo "<td>".date('D, Y-m-d h:i:s a', $dc_on)."</td>";
                    } else {
                        echo "<td style='text-align:center;'>-</td>";
                    }

                    echo "<td style='text-align:center;'>";
                    if ($dc_on != '' || $dc_on != null) {
                        if ($dc_on <= $duedate) {
                            echo "No";
                        } else {
                            echo floor($minusdays)."<br/>days";
                        }
                    } else {
                        if (time() > $duedate) {
                            echo floor($minusdays)." days";
                        } else {
                            echo "N/A";
                        }
                    }
                    echo "</td>";
                    
                    echo "<td width=10% align=center>";
                        if ($myrow["41f_pay"] == 'YES') {
                            if ($beforepaymenton == $paidon && $beforepaymentrcv == $paidrb) {
                                echo "<em>Paid as above<br/>Receipt: $paid_rid</em>";
                            } else {
                                echo "$currency_SHORT $received_amount"." $f_pay";
                                if ($discount_given > 0.00) {
                                    echo "<br/>Discount:&nbsp$currency_SHORT&nbsp$discount_given<br/>Receipt:&nbsp$paid_rid";
                                }
                            }
                        } else {
                            if ($minusdays >= 0 && $dc_on != null) {
                                echo "$currency_SHORT ".calculatedFines(floor($minusdays), $accessnum, $dc_enforcedfine)." [$f_pay]";
                            } else {
                                echo "-";
                            }
                        }
                    echo "</td>";
                    echo "</tr>";
                    $beforepaymenton = $paidon;
                    $beforepaymentrcv = $paidrb;
                    $n = $n + 1;
                }
        ?>
    </table>
        
    <br/><br/>
        
    <div style='text-align:center;width:100%;'>[ <a href="chanuser.php">Back to user account page</a> ]</div>
    
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
