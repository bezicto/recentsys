<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Fines Management (Alpha)</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
    
    <?php
    
    if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce New' && $_POST['fines_init'] <> 0 && is_numeric($_POST['fines_initamount']) && is_numeric($_POST['fines_subsequenceamount'])) {
        $typeid = $_POST['typeid'];
        $fines_init = $_POST['fines_init'];
        $fines_initamount = $_POST['fines_initamount'];
        $fines_subsequenceamount = $_POST['fines_subsequenceamount'];
                    
        if ($fines_init != '' && $fines_initamount != '' && $fines_subsequenceamount != '') {
            $current_time = time();
            $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_jenisbahan_fines VALUES (NULL, ?, ?, ?, ?, ?)");
            mysqli_stmt_bind_param($stmt, "iisss", $typeid, $fines_init, $fines_initamount, $fines_subsequenceamount, $current_time);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        echo "<script>window.alert(\"Record has been inputted into the database.\");</script>";
    } elseif (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'Enforce New' && ($_POST['fines_init'] == 0 || !is_numeric($_POST['fines_initamount']) || !is_numeric($_POST['fines_subsequenceamount']))) {
        echo "<script>window.alert(\"Check your input.\");</script>";
    }
    ?>
    
    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#F8EE96;'><td style='text-align:center;'><b>Fines management </b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:370;'><br/>
        <form action="fines_days.php" method="post" enctype="multipart/form-data">
            <table style='margin-left:auto;margin-right:auto;'>
            
                <td><b>Category</b></td>
                <td>: <?php echo idToType($_REQUEST["typeid"]);?><input type='hidden' name='typeid' value='<?php echo $_REQUEST["typeid"];?>'></td>
                </tr>
            
                <tr>
                <td><b>Number of days for initial fines </b></td>
                <td>: <select name="fines_init">
                    <option value="0">0</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7 (1 week)</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                    <option value="13">13</option>
                    <option value="14">14 (2 weeks)</option>
                    <option value="15">15</option>
                    <option value="16">16</option>
                    <option value="17">17</option>
                    <option value="18">18</option>
                    <option value="19">19</option>
                    <option value="20">20</option>
                    <option value="21">21 (3 weeks)</option>
                    <option value="22">22</option>
                    <option value="23">23</option>
                    <option value="24">24</option>
                    <option value="25">25</option>
                    <option value="26">26</option>
                    <option value="27">27</option>
                    <option value="28">28 (4 weeks)</option>
                    <option value="29">29</option>
                    <option value="30">30 (1 month)</option>
                    <option value="60">60 (2 month)</option>
                </select>
                </td>
                </tr>
            
                <td><b>Fines amount (initial) </b></td>
                <td>: <?php echo $currency_SHORT;?> <input type="text" name="fines_initamount" size="10" maxlength="70"/> /day</td>
                </tr>
            
                <td><b>Subsequence fines amount </b></td>
                <td>: <?php echo $currency_SHORT;?> <input type="text" name="fines_subsequenceamount" size="10" maxlength="70"/> /day</td>
                </tr>

                <input type="hidden" name="submitted" value="Force" />
                <tr><td colspan=2 style='text-align:center;'><br/><input type="submit" name="submitted" value="Enforce New" /></td></tr>
            </table>
        </form>
    </td></tr>
    </table>
        
    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#FFFE96;'><td colspan=7 style='text-align:center;'><b>Fines Listing and Controls :</b></td></tr>
        <tr style='background-color:white;text-align:center;'>
            <td style='width:25;text-align:center;'>#</td>
            <td style='text-align:center;'>Type</td>
            <td style='text-align:center;'>Initial Fines (Days)</td>
            <td style='text-align:center;'>Initial Fines (Amount -<?php echo $currency_SHORT;?>)</td>
            <td style='text-align:center;'>Subsequence Fines (Amount -<?php echo $currency_SHORT;?>)</td>
            <td style='text-align:center;'>Status</td>
            <td style='text-align:center;'>Enforced start date</td>
        </tr>

        <?php
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT * FROM eg_jenisbahan_fines WHERE 38typeid = ? ORDER BY id DESC");
            mysqli_stmt_bind_param($stmt, "i", $_REQUEST["typeid"]);
            mysqli_stmt_execute($stmt);
            $resultT = mysqli_stmt_get_result($stmt);
            $numResulT = mysqli_num_rows($resultT);
            $n = 1;
            while ($myrow=mysqli_fetch_array($resultT)) {
                    $typeid=$myrow["38typeid"];
                    $fines_initdays=$myrow["39fines_initdays"];
                    $fines_initamount=$myrow["39fines_initamount"];
                    $fines_subsequenceamount=$myrow["39fines_subsequenceamount"];
                    $enforced_on=$myrow["40enforcedon"];
                    
                    $td_font_color = "";
                    if ($n == 1) {
                        $td_font_color = "style='color:blue;'";
                    }

                    echo "<tr bgcolor='EBF0FE'><td $td_font_color>$n</td><td $td_font_color>$typeid</td><td $td_font_color>$fines_initdays</td>";
                    echo "<td $td_font_color>$fines_initamount</td>";
                    echo "<td $td_font_color>$fines_subsequenceamount</td>";
                    echo "<td $td_font_color>";
                        if ($n == 1) {
                            echo "Enforced";
                        } else {
                            echo "Archived";
                        }
                    echo "</td>";
                    echo "<td $td_font_color>".date('D, Y-m-d h:i:s a', $enforced_on)."</td></tr>";
                    $n = $n + 1;
                }
        ?>
    </table>
    
    <br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../admin/addtype.php">Back</a> ]</div>
    
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
