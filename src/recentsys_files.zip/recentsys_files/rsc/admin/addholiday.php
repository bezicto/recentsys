<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Holiday Listing</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <?php
        if (!isset($_REQUEST['fr']) || $_REQUEST['fr'] != '1') {
            include_once '../includes/loggedinfo.php';
        }
    ?>
    
    <hr>
        
    <?php
            
        if (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null) {
            $get_id_del = $_GET["del"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_holiday WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_del);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
                
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'TRUE') {
            $title1 = $_POST["title1"];
            $date1 = $_POST["date1"];
            
            echo "<table border=0 width=90% align=center><tr><td bgcolor=white style='text-align:center;'>";
                if (!empty($title1) && (!empty($date1))) {
                    echo "<img src='../images/tick.gif'><br/>The holiday <b>$title1 on $date1</b> has been added into the database.";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_holiday VALUES (NULL, ?, ?)");
                    mysqli_stmt_bind_param($stmt, "ss", $title1, $date1);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled.Check if any field(s) left emptied before posting.";
                }
            
            echo "</td></tr></table>";
        }

        if (isset($_REQUEST["submitting"]) && $_REQUEST["submitting"] == 'TRUE') {
            $mon1 = $_POST["monday"] ?? '0';if ($mon1 =='') {$mon1 = '0';}
            $tue1 = $_POST["tuesday"] ?? '0';if ($tue1 =='') {$tue1 = '0';}
            $wed1 = $_POST["wednesday"] ?? '0';if ($wed1 =='') {$wed1 = '0';}
            $thu1 = $_POST["thursday"] ?? '0';if ($thu1 =='') {$thu1 = '0';}
            $fri1 = $_POST["friday"] ?? '0';if ($fri1 =='') {$fri1 = '0';}
            $sat1 = $_POST["saturday"] ?? '0';if ($sat1 =='') {$sat1 = '0';}
            $sun1 = $_POST["sunday"] ?? '0';if ($sun1 =='') {$sun1 = '0';}

            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_working_days SET mon=?, tue=?, wed=?, thu=?, fri=?, sat=?, sun=? WHERE id=1");
            mysqli_stmt_bind_param($stmt, "sssssss", $mon1, $tue1, $wed1, $thu1, $fri1, $sat1, $sun1);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            echo "<script>alert('Library working days has been saved.');</script>";
        }
    
        $queryW = "select * from eg_working_days";
        $resultW = mysqli_query($GLOBALS["conn"], $queryW);
        $myrowW = mysqli_fetch_array($resultW);
        $mon=$myrowW["mon"];
        $tue=$myrowW["tue"];
        $wed=$myrowW["wed"];
        $thu=$myrowW["thu"];
        $fri=$myrowW["fri"];
        $sat=$myrowW["sat"];
        $sun=$myrowW["sun"];
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr><td style='text-align:center;background-color:#F8EE96;'><b>Working Days</b></td></tr>
        <tr><td style='text-align:center;background-color:lightgrey;'><br/>
            <form action="addholiday.php" method="post" enctype="multipart/form-data">
                <input type="checkbox" name="monday" value="1" <?php if ($mon == '1') {echo "checked";}?>>Monday
                <input type="checkbox" name="tuesday" value="1" <?php if ($tue == '1') {echo "checked";}?>>Tuesday
                <input type="checkbox" name="wednesday" value="1" <?php if ($wed == '1') {echo "checked";}?>>Wednesday
                <input type="checkbox" name="thursday" value="1" <?php if ($thu == '1') {echo "checked";}?>>Thursday
                <input type="checkbox" name="friday" value="1" <?php if ($fri == '1') {echo "checked";}?>>Friday
                <input type="checkbox" name="saturday" value="1" <?php if ($sat == '1') {echo "checked";}?>>Saturday
                <input type="checkbox" name="sunday" value="1" <?php if ($sun == '1') {echo "checked";}?>>Sunday<br/><br/>

                <input type="hidden" name="submitting" value="TRUE" />
                <input type="submit" name="Submit1" value="Save" />
            </form>
        </td>
        </tr>
    </table>

    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr><td style='text-align:center;background-color:#F8EE96;'><b>Holiday Addition</b></td></tr>
        <tr><td style='text-align:center;background-color:lightgrey;'>
            <form action="addholiday.php" method="post" enctype="multipart/form-data">
                        <b>Holiday Description: </b><br/>
                        <input type="text" name="title1" style="width:50%" maxlength="70"/><br/><br/>
                        
                        <b>Date: </b> <em style='font-size:8pt;'>Format: dd/mm/yyyy eg. 31/12/2019</em><br/>
                        <input type="text" name="date1" style="width:50%" maxlength="50"/><br/><br/>

                        <input type="hidden" name="submitted" value="TRUE" />
                        <input type="submit" name="Submit1" value="Insert" />
            </form>
        </td>
        </tr>
    </table>
    
    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#F8EE96;'>
            <td colspan=4><b>Holiday Controls :</b></td>
        </tr>
        
        <tr style='background-color:white;'>
            <td style='width:5%;text-align:center;'>#</td>
            <td style='text-align:center;'>Description</td>
            <td style='width:100px;text-align:center;'>Date</td>
            <td style='width:100px;text-align:center;'>Options</td>
        </tr>
        
        <?php
            $queryT = "select id, 38hol_date, str_to_date(38hol_date, '%d/%m/%Y') as 38hol_date2, 38hol_title from eg_holiday order by 38hol_date2";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $n = 1;
            while ($myrow=mysqli_fetch_array($resultT)) {
                $idT=$myrow["id"];
                $titleT=$myrow["38hol_title"];
                $dateT=$myrow["38hol_date"];
                
                echo "<tr bgcolor='EBF0FE'>";
                    echo "<td>$n</td>";
                    echo "<td>$titleT</td>";
                    echo "<td>$dateT</td>";
                    echo "<td style='text-align:center;'>";
                        echo "<a title='Delete this record' href='addholiday.php?del=$idT' onclick=\"return confirm('Are you sure to delete this holiday?');\"><img src='../images/delete.gif'></a>";
                        echo " <a title='Update this record' href='updateholiday.php?edt=$idT'><img src='../images/pencil.gif'></a>";
                    echo "</td>";
                echo "</tr>";
                
                $n = $n + 1;
            }
        ?>
    </table>
        
    <br/><br/>
        
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    <br/><hr><?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
