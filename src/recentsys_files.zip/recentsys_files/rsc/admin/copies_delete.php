<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Delete Copy</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script>
        window.onunload = refreshParent;
        function refreshParent() {
            window.opener.location.reload();
        }
    </script>
</head>

<body>
    <hr><br/>
    
    <?php
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'Delete' && (isset($_REQUEST["id"]) && is_numeric($_REQUEST["id"]))) {
            $id = $_REQUEST["id"];
            
            echo "<table border=1 width=90% align=center><tr><td bgcolor=white><div style='text-align:center;width:100%;'>";
                if (!empty($id)) {
                    echo "<img src='../images/tick.gif'><br/><div style='text-align:center;width:100%;'>The copy has been deleted from the database !</div>";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan_copies WHERE id=?");
                    mysqli_stmt_bind_param($stmt, "i", $id);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='images/caution.jpg'><br/><div style='text-align:center;width:100%;'>Your input has been cancelled.Check if any field(s) left emptied before posting.</div>";
                }
            echo "</div></td></tr></table>";
            echo "<script>window.close();</script>";
        }
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Copies Addition :</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:380;text-align:center;'><br/>
        <form action="copies_delete.php" method="post" enctype="multipart/form-data">
                Are you sure to delete this copy ?<br/><br/>
                <input type="hidden" name="id" value="<?php echo $_REQUEST["id"];?>" />
                <input type="submit" name="submitted" value="Delete" />
        </form>
        </td></tr>
    </table>
    
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="#" onclick="window.close();">Cancel and Close</a> ]</div>
    
    <br/><hr>

</body>

</html>
