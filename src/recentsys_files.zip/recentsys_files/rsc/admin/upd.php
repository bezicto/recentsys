<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Update</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function showList()
            {
                sList = window.open("shselector.php?clr=upd", "list", "scrollbars=yes,resizable=no,width=350,height=450");
            }
        function openSHAdd()
            {
                sList = window.open("addsubject.php?fr=1", "list", "scrollbars=yes,resizable=no,width=350,height=450");
            }
        function remLink()
            {
                if (window.sList && window.sList.open && !window.sList.closed)
                window.sList.opener = null;
            }
    </script>
</head>

<body>
                 
    <hr>
    <?php
        if (isset($_GET["upd"]) && $_GET["upd"] <> null && is_numeric($_GET["upd"])) {
            $get_id_upd = $_GET["upd"];

            $query3 = "select * from eg_bahan where id = $get_id_upd";
            $result3 = mysqli_query($GLOBALS["conn"], $query3);
            $myrow2=mysqli_fetch_array($result3);
                $id3=$myrow2["id"] ?? '';
                $tajuk3=$myrow2["38title"] ?? '';
                $lokasi3=$myrow2["38location"] ?? '';
                $link3=$myrow2["38link"] ?? '';
                $pengarang3=$myrow2["38author"] ?? '';
                $sumber3=$myrow2["38source"] ?? '';
                $callnum3=$myrow2["38localcallnum"] ?? '';
                $isbn3 = $myrow2["38isbn"] ?? '';
                $issn3 = $myrow2["38issn"] ?? '';
                $edition3 = $myrow2["38edition"] ?? '';
                $publication3 = $myrow2["38publication"] ?? '';
                $physicaldesc3 = $myrow2["38physicaldesc"] ?? '';
                $series3 = $myrow2["38series"] ?? '';
                $notes3 = $myrow2["38notes"] ?? '';
                $fcnotes3 = $myrow2["38fcnotes"] ?? '';
                $jenis3=$myrow2["39type"] ?? '';
                $pdfattach3=$myrow2["39pdfattach"] ?? '';
                $subjectheading3=$myrow2["39subjectheading"] ?? '';
                $imageatt3=$myrow2["39imageatt"] ?? '';
                $language3=$myrow2["39language"] ?? '';
                $inputdate3=$myrow2["40inputdate"] ?? '';
                $lastupdateby3=$myrow2["40lastupdateby"] ?? '';
                $timestamp3=$myrow2["40instimestamp"] ?? '';
            
            
            $query31 = "select * from eg_bahan2 where eg_bahan_id = $get_id_upd";
            $result31 = mysqli_query($GLOBALS["conn"], $query31);
            $myrow21=mysqli_fetch_array($result31);
                $callnum3_b=$myrow21["38localcallnum_b"] ?? '';
                $pengarang3_d=$myrow21["38author_d"] ?? '';
                $tajuk3_b=$myrow21["38title_b"] ?? '';
                $tajuk3_c=$myrow21["38title_c"] ?? '';
                $publication3_b=$myrow21["38publication_b"] ?? '';
                $publication3_c=$myrow21["38publication_c"] ?? '';
                $physicaldesc3_b=$myrow21["38physicaldesc_b"] ?? '';
                $physicaldesc3_c=$myrow21["38physicaldesc_c"] ?? '';
                $physicaldesc3_e=$myrow21["38physicaldesc_e"] ?? '';
                $series3_v=$myrow21["38series_v"] ?? '';
                $sumber3_b=$myrow21["38source_b"] ?? '';
                $sumber3_e=$myrow21["38source_e"] ?? '';
                $lokasi3_b=$myrow21["38location_b"] ?? '';
                $lokasi3_c=$myrow21["38location_c"] ?? '';

            $query32 = "select * from eg_bahan2_indicator where eg_bahan_id = $get_id_upd";
            $result32 = mysqli_query($GLOBALS["conn"], $query32);
            $myrow22=mysqli_fetch_array($result32);
                $tajuk3_in=$myrow22["38title_i"] ?? '';
                $pengarang3_in=$myrow22["38author_i"] ?? '';
                $fcnotes3_in=$myrow22["38fcnotes_i"] ?? '';
                $sumber3_in=$myrow22["38source_i"] ?? '';
            
            $query33 = "select * from eg_bahan_isbn where eg_bahan_id = $get_id_upd";
            $result33 = mysqli_query($GLOBALS["conn"], $query33);
            $myrow33=mysqli_fetch_array($result33);
                $isbn3_1=$myrow33["isbn1"] ?? '';
                $isbn3_2=$myrow33["isbn2"] ?? '';
                $isbn3_3=$myrow33["isbn3"] ?? '';
                $isbn3_4=$myrow33["isbn4"] ?? '';
                $isbn3_5=$myrow33["isbn5"] ?? '';
                $isbn3_6=$myrow33["isbn6"] ?? '';
                $isbn3_7=$myrow33["isbn7"] ?? '';
                $isbn3_8=$myrow33["isbn8"] ?? '';
                $isbn3_9=$myrow33["isbn9"] ?? '';
                $isbn3_10=$myrow33["isbn10"] ?? '';
                $isbn3_11=$myrow33["isbn11"] ?? '';
                $isbn3_12=$myrow33["isbn12"] ?? '';
                $isbn3_13=$myrow33["isbn13"] ?? '';
                $isbn3_14=$myrow33["isbn14"] ?? '';
                $isbn3_15=$myrow33["isbn15"] ?? '';
                $isbn3_16=$myrow33["isbn16"] ?? '';
                $isbn3_17=$myrow33["isbn17"] ?? '';
                $isbn3_18=$myrow33["isbn18"] ?? '';
                $isbn3_19=$myrow33["isbn19"] ?? '';
                $isbn3_20=$myrow33["isbn20"] ?? '';
    ?>
                    
            <table style='width:100%;margin-left:auto;margin-right:auto;'>
            <tr style='background-color:#F8EE96;'>
            <td>
                <div style='text-align:center;width:100%;'><b>Please update the record below :</b> *<em>Mandatory</em></div>
            </td>
            </tr>
            </table>
                
            <form name="someform" action="upd.php" method="post" enctype="multipart/form-data">
                <table style='width:100%;margin-left:auto;margin-right:auto;background-color:lightgrey;'>
                            <tr style='background-color:white;'><td style='text-align:right;'>Tags</td><td style='width:60;text-align:center;'>Indi.</td><td colspan=2>Value</td></tr>

                            <tr>
                                <td style='text-align:right;'><b>Type </b>*</td><td></td>
                                <td>:
                                 |a<select name="jenis3">
                                    <?php
                                        $queryU = "select 38typeid, 38type from eg_jenisbahan";
                                        $resultU = mysqli_query($GLOBALS["conn"], $queryU);
                
                                        while ($row=mysqli_fetch_array($resultU)) {
                                            echo '<option value="'.$row['38typeid'].'"';
                                                if ($row['38typeid']==$jenis3) {
                                                    echo ' selected';
                                                }
                                            echo '>'. $row['38type'] . '</option>'."\n";
                                            }
                                    ?>
                                </select>
                                </td>
                            </tr>
                            
                            <tr>
                                <td style='text-align:right;'><b>Subj. Heading </b></td><td></td>
                                <td>:  |a<input type="text" name="subjectheading3" style="width:50%" readonly="readonly" maxlength="150" value="<?php if ($subjectheading3 <> null) {echo $subjectheading3;} ?>"/>
                                <input type="button" name="subjectheadingButton" value="..." onClick="showList()" />
                                <input type="button" name="gotoSHButton" value="+New" onClick="openSHAdd()" />
                                <input type="button" name="clearSH" value="Clear" onClick="subjectheading3.value='';">
                                </td>
                            </tr>
    
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_020;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="isbn3" style="width:90%" maxlength="60" value="<?php if ($isbn3 <> null) {echo $isbn3;} ?>" placeholder="<?php echo $tag_020ph;?>"/> <a id="al0" style="font-size:8pt;display:<?php if ($isbn3_1 <> null) {echo 'none';} else {echo 'show';}?>" onclick="document.getElementById('a1').style.display='';document.getElementById('al0').style.display='none';">[+]</a></td>
                            </tr>
                            <?php
                                for ($x=1; $x<=20; $x++) {
                                    $y = $x+1;
                                    echo "<tr id='a$x' style='display:";
                                    if (${"isbn3_$x"} <> null) {echo "show";} else {echo "none";}
                                    echo "'><td style='text-align:right;vertical-align:top;'><b>";
                                    echo "$tag_020</b></td><td style='text-align:center;'>**</td>";
                                    echo "<td style='vertical-align:top;'>:  |a<input type='text' name='isbn3_$x' style='width:80%' maxlength='60' value='";
                                    if (${"isbn3_$x"} <> null) {echo ${"isbn3_$x"};}
                                    echo "' placeholder='$tag_020ph'/> ";
                                    if ($y <> 20) {
                                        echo "<a id='al$x' style='font-size:8pt;display:";
                                        if (${"isbn3_$y"} <> null) {echo 'none';} else {echo 'show';}
                                        echo "' onclick=\"document.getElementById('a$y').style.display='';document.getElementById('al$x').style.display='none';\">[+]</a>";
                                    }
                                    echo "</td></tr>";
                                }
                            ?>
                            
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_022;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="issn3" style="width:90%" maxlength="60" value="<?php if ($issn3 <> null) {echo $issn3;} ?>" placeholder="<?php echo $tag_022ph;?>"/></td>
                            </tr>

                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_041;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a
                                <?php
                                if ($tag_041_inputtype == "select") {
                                    $selectable_041 = explode("|", $tag_041_selectable);
                                    $selectable_041_def = explode("|", $tag_041_selectable_def);
                                    echo "<select name='language3'>";
                                    for ($x = 0; $x < sizeof($selectable_041); $x++) {
                                        echo "<option value='".$selectable_041[$x]."' ";
                                        if ($selectable_041[$x] == $language3) {echo "selected";}
                                        echo ">".$selectable_041_def[$x]."</option>";
                                    }
                                    echo "</select>";
                                } else {
                                    echo "<input type=\"text\" name=\"language3\" style=\"width:80%;\" maxlength=\"3\" placeholder=\"$tag_041ph\" ";
                                    if ($language3 <> null) {echo $language3;}
                                    echo ">";
                                }
                                ?>
                            </tr>
    
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_090;?></b></td><td style='text-align:center;'>00</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="callnum3" style="width:90%" maxlength="70" value="<?php if ($callnum3 <> null) {echo $callnum3;} ?>" placeholder="<?php echo $tag_090aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="callnum3_b" style="width:90%" maxlength="70" value="<?php if ($callnum3_b <> null) {echo $callnum3_b;} ?>" placeholder="<?php echo $tag_090bph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_100;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="pengarang3_in" value="<?php if ($pengarang3_in <> null) {echo $pengarang3_in;} ?>"></td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="pengarang3" style="width:90%" maxlength="150" value="<?php if ($pengarang3 <> null) {echo $pengarang3;} ?>" placeholder="<?php echo $tag_100aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |d<input type="text" name="pengarang3_d" style="width:90%" maxlength="150" value="<?php if ($pengarang3_d <> null) {echo $pengarang3_d;} ?>" placeholder="<?php echo $tag_100dph;?>"/></td>
                                </tr>
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_245;?></b>*</td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="tajuk3_in" value="<?php if ($tajuk3_in <> null) {echo $tajuk3_in;} ?>"></td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="tajuk3" style="width:90%" maxlength="255" value="<?php if ($tajuk3 <> null) {echo stripslashes(str_replace('"', '&#34;', $tajuk3));} ?>" placeholder="<?php echo $tag_245aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="tajuk3_b" style="width:90%" maxlength="255" value="<?php if ($tajuk3_b <> null) {echo stripslashes(str_replace('"', '&#34;', $tajuk3_b));} ?>" placeholder="<?php echo $tag_245bph;?>"/></td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |c<input type="text" name="tajuk3_c" style="width:90%" maxlength="255" value="<?php if ($tajuk3_c <> null) {echo stripslashes(str_replace('"', '&#34;', $tajuk3_c));} ?>" placeholder="<?php echo $tag_245cph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_250;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="edition3" style="width:90%" maxlength="255" value="<?php if ($edition3 <> null) {echo $edition3;} ?>" placeholder="<?php echo $tag_250aph;?>"/></td>
                            </tr>
    
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_264;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="publication3" style="width:90%" maxlength="255" value="<?php if ($publication3 <> null) {echo $publication3;} ?>" placeholder="<?php echo $tag_264aph;?>"/></td>
                            </tr>
                                 
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="publication3_b" style="width:90%" maxlength="255" value="<?php if ($publication3_b <> null) {echo $publication3_b;} ?>" placeholder="<?php echo $tag_264bph;?>"/></td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |c<input type="text" name="publication3_c" style="width:90%" maxlength="255" value="<?php if ($publication3_c <> null) {echo $publication3_c;} ?>" placeholder="<?php echo $tag_264cph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_300;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="physicaldesc3" style="width:90%" maxlength="255" value="<?php if ($physicaldesc3 <> null) {echo $physicaldesc3;} ?>" placeholder="<?php echo $tag_300aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="physicaldesc3_b" style="width:90%" maxlength="255" value="<?php if ($physicaldesc3_b <> null) {echo $physicaldesc3_b;} ?>" placeholder="<?php echo $tag_300bph;?>"/></td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |c<input type="text" name="physicaldesc3_c" style="width:90%" maxlength="255" value="<?php if ($physicaldesc3_c <> null) {echo $physicaldesc3_c;} ?>" placeholder="<?php echo $tag_300cph;?>"/></td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |e<input type="text" name="physicaldesc3_e" style="width:90%" maxlength="255" value="<?php if ($physicaldesc3_e <> null) {echo $physicaldesc3_e;} ?>" placeholder="<?php echo $tag_300eph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_490;?></b></td><td style='text-align:center;'>0*</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="series3" style="width:90%" maxlength="150" value="<?php if ($series3 <> null) {echo $series3;} ?>" placeholder="<?php echo $tag_490aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |v<input type="text" name="series3_v" style="width:90%" maxlength="150" value="<?php if ($series3_v <> null) {echo $series3_v;} ?>" placeholder="<?php echo $tag_490vph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_500;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="notes3" style="width:90%" maxlength="255" value="<?php if ($notes3 <> null) {echo $notes3;} ?>" placeholder="<?php echo $tag_500aph;?>"/></td>
                            </tr>

                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_505;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="fcnotes3_in" value="<?php if ($fcnotes3_in <> null) {echo $fcnotes3_in;} ?>"></td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="fcnotes3" style="width:90%" maxlength="255" value="<?php if ($fcnotes3 <> null) {echo $fcnotes3;} ?>" placeholder="<?php echo $tag_505aph;?>"/></td>
                            </tr>
    
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_710;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="sumber3_in" value="<?php if ($sumber3_in <> null) {echo $sumber3_in;} ?>"></td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="sumber3" style="width:90%" maxlength="255" value="<?php if ($sumber3 <> null) {echo $sumber3;} ?>" placeholder="<?php echo $tag_710aph;?>"/>
                                </td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="sumber3_b" style="width:90%" maxlength="255" value="<?php if ($sumber3_b <> null) {echo $sumber3_b;} ?>" placeholder="<?php echo $tag_710bph;?>"/>
                                    </td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |e<input type="text" name="sumber3_e" style="width:90%" maxlength="255" value="<?php if ($sumber3_e <> null) {echo $sumber3_e;} ?>" placeholder="<?php echo $tag_710eph;?>"/>
                                    </td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_852;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |a<input type="text" name="lokasi3" style="width:90%" maxlength="50" value="<?php if ($lokasi3 <> null) {echo $lokasi3;} ?>" placeholder="<?php echo $tag_852aph;?>"/></td>
                            </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |b<input type="text" name="lokasi3_b" style="width:90%" maxlength="50" value="<?php if ($lokasi3_b <> null) {echo $lokasi3_b;} ?>" placeholder="<?php echo $tag_852bph;?>"/></td>
                                </tr>
                                <tr>
                                    <td style='text-align:right;vertical-align:top;'></td><td></td>
                                    <td style='vertical-align:top;'>:  |c<input type="text" name="lokasi3_c" style="width:90%" maxlength="50" value="<?php if ($lokasi3_c <> null) {echo $lokasi3_c;} ?>" placeholder="<?php echo $tag_852cph;?>"/></td>
                                </tr>
                                
                            <tr>
                                <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_856;?></b></td><td style='text-align:center;'>**</td>
                                <td style='vertical-align:top;'>:  |u<input type="text" name="link3" style="width:90%" maxlength="255" value="<?php if ($link3 <> null) {echo urldecode($link3);} ?>" placeholder="<?php echo $tag_856uph;?>"/></td>
                            </tr>
                            
                            <tr id="tbl1">
                                <td style='text-align:right;vertical-align:top;'><b>PDF (Max <?php $ini_max = return_bytes(ini_get('upload_max_filesize')); echo (int)$pdf_upload_maxsize < (int)$ini_max ? $pdf_upload_maxsize/1000000 : $ini_max/1000000; ?> MB)</b></td>
                                <td style='vertical-align:top;' colspan=2>:
                                <?php
                                    if ($pdfattach3 == 'TRUE') {
                                        echo "$id3"."_"."$timestamp3".".pdf";
                                        echo " <Input type = 'Checkbox' Name ='unlink3' value ='unlink'> <em>Unlink file on update</em>";
                                    } else {
                                        echo "<input type='file' name='file1' size='38'>";
                                    }
                                ?>
                                </td>
                            </tr>

                            <tr id="tbl4">
                                <td style='text-align:right;vertical-align:top;'><b>Book Cover JPG (Max <?php $ini_max = return_bytes(ini_get('upload_max_filesize')); echo (int)$cover_upload_maxsize < (int)$ini_max ? $cover_upload_maxsize/1000000 : $ini_max/1000000; ?> MB)</b></td>
                                <td style='vertical-align:top;' colspan=2>:
                                <?php
                                    if ($imageatt3 == 'TRUE') {
                                        echo "$id3"."_"."$timestamp3".".jpg";
                                        echo " <Input type = 'Checkbox' Name ='unlinkimage3' value ='unlink'> <em>Unlink image on update</em>";
                                    } else {
                                        echo "<input type='file' name='imageatt1' size='38'>";
                                    }
                                ?>
                                </td>
                            </tr>
                </table>
                
                <table style='width:100%;margin-left:auto;margin-right:auto;background-color:lightgrey;'>
                    <input type="hidden" name="submitted" value="TRUE" />
                    <input type="hidden" name="id3" value="<?php echo $_GET['upd'];?>" />
                    <input type="hidden" name="timestamp3" value="<?php echo $timestamp3;?>" />
                    <input type="hidden" name="inputdate3" value="<?php echo $inputdate3;?>" />
                    <tr><td colspan=2 style='text-align:center;'><br/><input type="submit" name="Submit1" value="Update"/><br/><br/></td></tr>
                </table>
            </form>
    
    <?php
        }
                
        if (isset($_POST["submitted"])) {
            $tajuk4 = addslashes($_POST["tajuk3"]);
            $jenis4 = $_POST["jenis3"];
            $lokasi4 = $_POST["lokasi3"];
            $link4 = $_POST["link3"];
            $id4 = $_POST["id3"];
            $timestamp4 = $_POST["timestamp3"];
            $inputdate4 = $_POST["inputdate3"];
            $pengarang4 = addslashes($_POST["pengarang3"]);
            $sumber4 =  addslashes($_POST["sumber3"]);
            $callnum4 = $_POST["callnum3"];
            $subjectheading4 = $_POST["subjectheading3"];
            $lastupdateby4 = $_SESSION["username"];
            $link4 = urlencode($link4);
            $unlink4 = $_POST["unlink3"] ?? '';
            $unlinkimage4 = $_POST["unlinkimage3"] ?? '';
            $isbn4 = $_POST["isbn3"];
            $issn4 = $_POST["issn3"];
            $edition4 = $_POST["edition3"];
            $publication4 =  addslashes($_POST["publication3"]);
            $physicaldesc4 = $_POST["physicaldesc3"];
            $series4 = $_POST["series3"];
            $notes4 = $_POST["notes3"];
            $language4 = $_POST["language3"];

            $search_cloud = $tajuk4." ".$_POST["tajuk3_b"]." ".$_POST["tajuk3_c"]." \ ".$pengarang4." ".$_POST["pengarang3_d"]." \ $isbn4 $issn4 \ $callnum4"." ".$_POST["callnum3_b"];
                                                                
            echo "<table border=1 width=50% align=center><tr><td bgcolor=white align=center>";
                if (!empty($tajuk4) && !empty($jenis4)) {
    
                    $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 38title=?, 38location=?, 38link=?, 38author=?, 38source=?, 38isbn=?, 38issn=?, 38edition=?, 38publication=?, 38physicaldesc=?, 38series=?, 38notes=?, 38localcallnum=?, 39subjectheading=?, 39type=?, 39language=?, 40lastupdateby=?, 50search_cloud=? WHERE id=?");
                    mysqli_stmt_bind_param($stmt, "ssssssssssssssssssi", $tajuk4, $lokasi4, $link4, $pengarang4, $sumber4, $isbn4, $issn4, $edition4, $publication4, $physicaldesc4, $series4, $notes4, $callnum4, $subjectheading4, $jenis4, $language4, $lastupdateby4, $search_cloud, $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan2 SET 38localcallnum_b=?, 38author_d=?, 38title_b=?, 38title_c=?, 38publication_b=?, 38publication_c=?, 38physicaldesc_b=?, 38physicaldesc_c=?, 38physicaldesc_e=?, 38series_v=?, 38source_b=?, 38source_e=?, 38location_b=?, 38location_c=? WHERE eg_bahan_id=?");
                    $as_tajuk3_b = addslashes($_POST["tajuk3_b"]);
                    $as_tajuk3_c =addslashes($_POST["tajuk3_c"]);
                    $as_publication3_b =addslashes($_POST["publication3_b"]);
                    $as_publication3_c =addslashes($_POST["publication3_c"]);
                    $as_sumber3_b =addslashes($_POST["sumber3_b"]);
                    $as_sumber3_e =addslashes($_POST["sumber3_e"]);
                    mysqli_stmt_bind_param($stmt, "ssssssssssssssi", $_POST["callnum3_b"], $_POST["pengarang3_d"], $as_tajuk3_b, $as_tajuk3_c, $as_publication3_b, $as_publication3_c, $_POST["physicaldesc3_b"], $_POST["physicaldesc3_c"], $_POST["physicaldesc3_e"], $_POST["series3_v"], $as_sumber3_b, $as_sumber3_e, $_POST["lokasi3_b"], $_POST["lokasi3_c"], $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);

                    //insert into eg_bahan2_indicator
                    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan2_indicator WHERE eg_bahan_id=?");
                    mysqli_stmt_bind_param($stmt, "i", $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan2_indicator VALUES(null, ?, ?, ?, ?, ?)");
                        mysqli_stmt_bind_param($stmt, "issss", $id4, $_POST["pengarang3_in"], $_POST["tajuk3_in"], $_POST["fcnotes3_in"], $_POST["sumber3_in"]);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);

                    //insert into eg_bahan_isbn
                    $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_bahan_isbn WHERE eg_bahan_id=?");
                    mysqli_stmt_bind_param($stmt, "i", $id4);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan_isbn VALUES(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        mysqli_stmt_bind_param($stmt, "issssssssssssssssssss", $id4, $_POST["isbn3_1"], $_POST["isbn3_2"], $_POST["isbn3_3"], $_POST["isbn3_4"], $_POST["isbn3_5"], $_POST["isbn3_6"], $_POST["isbn3_7"], $_POST["isbn3_8"], $_POST["isbn3_9"], $_POST["isbn3_10"], $_POST["isbn3_11"], $_POST["isbn3_12"], $_POST["isbn3_13"], $_POST["isbn3_14"], $_POST["isbn3_15"], $_POST["isbn3_16"], $_POST["isbn3_17"], $_POST["isbn3_18"], $_POST["isbn3_19"], $_POST["isbn3_20"]);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    
                    $dir_yearTemp = substr("$inputdate4", -4);
                                
                    if ($unlink4 == 'unlink') {
                        if (is_file("../$pdf_upload_directory/$dir_yearTemp/"."$id4"."_"."$timestamp4".".pdf")) {
                            unlink("../$pdf_upload_directory/$dir_yearTemp/"."$id4"."_"."$timestamp4".".pdf");
                        }
                    
                        $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39pdfattach='FALSE' WHERE id=?");
                        mysqli_stmt_bind_param($stmt, "i", $id4);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                                
                    if ($unlinkimage4 == 'unlink') {
                        if (is_file("../$cover_upload_directory/$dir_yearTemp/"."$id4"."_"."$timestamp4".".jpg")) {
                            unlink("../$cover_upload_directory/$dir_yearTemp/"."$id4"."_"."$timestamp4".".jpg");
                        }
                    
                        $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39imageatt='FALSE' WHERE id=?");
                        mysqli_stmt_bind_param($stmt, "i", $id4);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                    }
                
                    echo "<br/><img src='../images/tick.gif'><br/>The record has been updated.";
                    
                    //reassign and pass it to uploadnow.php
                    $idUpload = $id4;
                    $timestampUpload = $timestamp4;
                    $inputdateUpload = $inputdate4;
                                    
                    $max_size = $pdf_upload_maxsize;
                    if (isset($_FILES['file1']['name']) && $_FILES['file1']['name'] != null) {
                            echo "<br/><br/>File upload status :";
                            $allowed_uploaddir = "../".$pdf_upload_directory;
                            $allowed_ext = "pdf";
                            $allowed_fieldname = "file1";
                            include '../includes/uploadcheck.php';
                            if ($successupload == 'TRUE') {
                                include '../includes/uploadnow.php';
                                echo "File attachment uploaded successfully !";
                                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39pdfattach='TRUE' WHERE id=?");
                                mysqli_stmt_bind_param($stmt, "i", $id4);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_close($stmt);
                            } elseif ($successupload == 'FALSE SIZE') {
                                echo "Upload aborted ! Attachment file size > $pdf_upload_maxsize bytes. Please reupdate.";
                            } else {
                                echo "Upload aborted ! Incorrect file type. Please reupdate.";
                            }
                        }
                           
                    $max_size = $cover_upload_maxsize;
                    if (isset($_FILES['imageatt1']['name']) && $_FILES['imageatt1']['name'] != null) {
                            echo "<br/><br/>File upload status :";
                            $allowed_uploaddir = "../".$cover_upload_directory;
                            $allowed_ext = "jpg";
                            $allowed_fieldname = "imageatt1";
                            include '../includes/uploadcheck.php';
                            if ($successupload == 'TRUE') {
                                include '../includes/uploadnow.php';
                                echo "Image attachment uploaded successfully !";
                                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39imageatt='TRUE' WHERE id=?");
                                mysqli_stmt_bind_param($stmt, "i", $id4);
                                mysqli_stmt_execute($stmt);
                                mysqli_stmt_close($stmt);
                            } elseif ($successupload == 'FALSE SIZE') {
                                echo "Upload aborted ! Attachment image size > $cover_upload_maxsize bytes. Please reupdate.";
                            } else {
                                echo "Upload aborted ! Incorrect image type. Please reupdate.";
                            }
                        }
                } else {
                    echo "<img src='../images/caution.jpg'><br/>Error. Please make sure there were no empty field(s).<br/>The record has been restored to it original state.";
                }
        }//if submitted
    ?>
    
    <?php
        
        if (isset($_POST['submitted']) && $_POST['submitted'] == 'TRUE') {
            echo "<br/><div align=center>[ <a href='javascript:window.opener.location.reload(true);window.close();'>Close</a> ]</div>";
            echo "<br/><br/></td></tr></table><hr>";
        } else {
            echo "<br/><div align=center>[ <a href='javascript:window.close();'>Close</a> ]</div><br/><br/>";
        }
            
    ?>

</body>

</html>
