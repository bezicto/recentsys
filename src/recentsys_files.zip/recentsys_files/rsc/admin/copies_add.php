<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Add Copies</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script>
        window.onunload = refreshParent;
        function refreshParent() {
            window.opener.location.reload();
        }
    </script>
</head>

<body>
            
    <hr><br/>
    
    <?php
        //below function will use microtime as accession number
        function millitime($usemethod)
        {
          if ($usemethod == 'microtime') {
            //use microtime
            $microtime = microtime();
            $comps = explode(' ', $microtime);
            return sprintf('%d%03d', $comps[1], $comps[0] * 1000);
          } elseif ($usemethod == 'seconds') {
            //use seconds
            return time();
          }
        }
            
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'Insert') {
            $bahan_id = $_REQUEST["bahan_id"];
            $status = $_POST["status"];
            $addedon = $_POST["addedon"];
            $copies = $_POST["copies"];
            $lastchange = $_POST["lastchange"];
            $invoice_a = $_POST["invoice_a"];
            $invoice_b = $_POST["invoice_b"];
            $invoice_c = $_POST["invoice_c"];
            
            $initialmilitime = millitime("seconds");
            
            echo "<table border=1 width=90% align=center><tr><td bgcolor=white><div style='text-align:center;width:100%;'>";
                if (!empty($bahan_id)) {
                    echo "<img src='../images/tick.gif'><br/><div style='text-align:center;width:100%;'>The copies has been inputed into the database !</div>";
                    for ($x = 1; $x <= $copies; $x++) {
                        $accession_num = $bahan_id . $initialmilitime;
                        $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan_copies VALUES (NULL, ?, ?, ?, ?, ?, ?, ?, ?)");
                        mysqli_stmt_bind_param($stmt, "isssssii", $bahan_id, $accession_num, $status, $invoice_a, $invoice_b, $invoice_c, $addedon, $lastchange);
                        mysqli_stmt_execute($stmt);
                        mysqli_stmt_close($stmt);
                        $initialmilitime = $initialmilitime+1;
                    }
                } else {
                    echo "<img src='../images/caution.jpg'><br/><div style='text-align:center;width:100%;'>Your input has been cancelled.Check if any field(s) left emptied before posting.</div>";
                }
            echo "</div></td></tr></table>";
        }

        if (!isset($_REQUEST["submitted"]) || $_REQUEST["submitted"] != 'Insert') {
    ?>
            <table style='width:95%;margin-left:auto;margin-right:auto;'>
                <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Copies Addition :</b></td></tr>
                <tr style='background-color:lightgrey;'><td colspan=2 style='text-align:center;'><br/>
                <form action="copies_add.php" method="post" enctype="multipart/form-data">
                    
                        <b>Number of Copies</b>:<br/>
                        <select name="copies">
                            <?php
                            for ($x = 1; $x <= 20; $x++) {
                                echo "<option value='$x'>$x</option>";
                            }
                            ?>
                        </select><br/><br/>
                    
                        <b>Default Status</b>:<br/>
                        <select name="status">
                            <option value="AVAILABLE">Available</option>
                            <option value="CIRCULATED">Circulated (On Loan)</option>
                            <option value="RESERVED">Reserved</option>
                            <option value="ONORDER">On Order</option>
                            <option value="FINALPROCESSING">Final Processing</option>
                            <option value="WEEDED">Weeded</option>
                            <option value="ONHOLD">On Hold</option>
                            <option value="LOST">Lost</option>
                        </select><br/><br/>

                        <b>Price per unit</b>:<br/>
                        <input type="text" name="invoice_a" style='width:300px;' maxlength="70" value=""/><br/><br/>

                        <b>Supplier</b>:<br/>
                        <input type="text" name="invoice_b" style='width:300px;' maxlength="70" value=""/><br/><br/>

                        <b>Invoice Number</b>:<br/>
                        <input type="text" name="invoice_c" style='width:300px;' maxlength="70" value=""/><br/><br/>
                
                        <input type="hidden" name="bahan_id" value="<?php echo $_REQUEST["bahan_id"];?>" />
                        <input type="hidden" name="addedon" value="<?php echo time();?>" />
                        <input type="hidden" name="lastchange" value="<?php echo time();?>" />
                
                        <input type="submit" name="submitted" value="Insert" />
                </form>
                </td></tr>
            </table>
    <?php
        }
    ?>
    
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="#" onclick="window.close();">Close</a> ]</div>
    
    <br/><hr>
    
</body>

</html>
