<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Add Type</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr>
    
    <?php
        
        if (isset($_GET["del"]) && is_numeric($_GET["del"]) && $_GET["del"] <> null) {
            $get_id_del = $_GET["del"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "DELETE FROM eg_jenisbahan WHERE 38typeid = ?");
            mysqli_stmt_bind_param($stmt, "i", $get_id_del);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
        
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'TRUE') {
            $type1 = $_POST["type1"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT 38type FROM eg_jenisbahan WHERE 38type = ?");
            mysqli_stmt_bind_param($stmt, "s", $type1);
            mysqli_stmt_execute($stmt);
            $result_type = mysqli_stmt_get_result($stmt);
            $num_results_affected_type = mysqli_num_rows($result_type);
            mysqli_stmt_close($stmt);
            
            echo "<table border=0 width=70% align=center><tr><td bgcolor=white style='text-align:center;'>";
            if ($num_results_affected_type == 0) {
                if (!empty($type1)) {
                    echo "<img src='../images/tick.gif'><br/>The type <b>$type1</b> has been inputed into the database.";
                    $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_jenisbahan VALUES (NULL, ?, NULL, NULL)");
                    mysqli_stmt_bind_param($stmt, "s", $type1);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_close($stmt);
                } else {
                    echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled.Check if any field(s) left emptied before posting.";
                }
            } elseif ($num_results_affected_type >= 1) {
                echo "<img src='../images/caution.jpg'><br/>Your input has been cancelled. Duplicate TYPE detected.";
            }
            echo "</td></tr></table>";
        }
        
    ?>

    <table style='width:70%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td style='text-align:center;'><b>Type Addition :</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='text-align:center;'><br/>
        <form action="addtype.php" method="post" enctype="multipart/form-data">
                <b>New type: </b><br/><input type="text" name="type1" style="width:50%" maxlength="70"/><br/><br/>

                <input type="hidden" name="submitted" value="TRUE" />
                <input type="submit" name="Submit1" value="Insert" />
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table style='width:70%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#FFFE96;'><td colspan=4 style='text-align:center;'><b>Type Listing and Controls :</b></td></tr>
        <tr style='background-color:white;text-align:center;'>
            <td style='width:25;text-align:center;'>ID</td>
            <td style='width:35%;text-align:center;'>Description</td>
            <td style='text-align:center;'>Current Enforced Fines<br/>(Initial/Subsequence)</td>
            <td style='text-align:center;'>Options</td>
        </tr>
        <?php
            $queryT = "select 38typeid, 38type  from eg_jenisbahan";
            $resultT = mysqli_query($GLOBALS["conn"], $queryT);
            $n = 1;
            while ($myrow=mysqli_fetch_array($resultT)) {
                $typeT=$myrow["38type"];
                $typeidT=$myrow["38typeid"];
                
                echo "<tr bgcolor='EBF0FE'><td style='text-align:center;'>$n</td><td>$typeT</td>";
                echo "<td style='text-align:center;'><a href='fines_days.php?typeid=$typeidT'>".displayFines($typeidT)."</a></td>";
                echo "<td style='text-align:center;'><a title='Delete this record' href='addtype.php?del=$typeidT' onclick=\"return confirm('Are you sure ? You are advisable to change all items based on this type to the other type before proceeding.');\"><img src='../images/delete.gif'></a>";
                echo " <a title='Update this record' href='updatetype.php?edt=$typeidT'><img src='../images/pencil.gif'></a></td></tr>";
                $n = $n + 1;
            }
        ?>
    </table>
        
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>

    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
</body>

</html>
