<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
    $get_jenis1 = $_GET["jenis1"] ?? 0;
    $jenisbahan = 'document.someform.jenis1.options[document.someform.jenis1.selectedIndex].value';
?>


<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Add Record</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script type="text/javascript">
        function showList()
            {
                sList = window.open("shselector.php?clr=reg", "list", "scrollbars=yes,resizable=no,width=350,height=450");
            }
        function openSHAdd()
            {
                sList = window.open("addsubject.php?fr=1", "list", "scrollbars=yes,resizable=no,width=350,height=450");
            }
        function remLink()
            {
                if (window.sList && window.sList.open && !window.sList.closed)
                window.sList.opener = null;
            }
    </script>
</head>

<body>

    <?php include_once '../includes/loggedinfo.php';?>
            
    <hr>
    
    <?php

        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE') {
            $tajuk1 = addslashes($_POST["tajuk1"]);
            $jenis1 = $_POST["jenis1"];
            $lokasi1 = $_POST["lokasi1"];
            $link1 = $_POST["link1"];
            $tarikh_masuk1 = date("d/m/Y");
            $input_oleh1 = $_POST["input_oleh1"];
            $callnum1 = $_POST["callnum1"];
            $pengarang1 = addslashes($_POST["pengarang1"]);
            $sumber1 =  addslashes($_POST["sumber0"]);
            $instimestamp1 = $_POST["instimestamp1"];
            $subjectheading1 = $_POST["subjectheading1"];
            $isbn1 = $_POST["isbn1"];
            $issn1 = $_POST["issn1"];
            $edition1 = $_POST["edition1"];
            $publication1 =  addslashes($_POST["publication1"]);
            $physicaldesc1 = $_POST["physicaldesc1"];
            $series1 = $_POST["series1"];
            $notes1 = $_POST["notes1"];
            $fcnotes1 = $_POST["fcnotes1"];
            $language1 = $_POST["language1"];

            $search_cloud = $tajuk1." ".$_POST["tajuk1_b"]." ".$_POST["tajuk1_c"]." \ ".$pengarang1." ".$_POST["pengarang1_d"]." \ $isbn1 $issn1 \ $callnum1"." ".$_POST["callnum1_b"];
        
            echo "<table border=1 width=100% align=left>";
            echo "<tr><td bgcolor='white' align=center>";
        
            if (!empty($tajuk1) && !empty($jenis1)) {
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan VALUES(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'FALSE', '', ?, ?, ?, 'FALSE', null, ?, 0, ?)");
                mysqli_stmt_bind_param($stmt, "sssssssssssssssssssis",
                    $isbn1,
                    $issn1,
                    $callnum1,
                    $pengarang1,
                    $tajuk1,
                    $edition1,
                    $publication1,
                    $physicaldesc1,
                    $series1,
                    $notes1,
                    $fcnotes1,
                    $sumber1,
                    $lokasi1,
                    $link1,
                    $jenis1,
                    $subjectheading1,
                    $language1,
                    $input_oleh1,
                    $tarikh_masuk1,
                    $instimestamp1,
                    $search_cloud
                );
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                                                    
                // all the code below is added to get the id number for the material that has been entered above
                $queryN = "select id from eg_bahan where 40instimestamp='$instimestamp1' and 40inputby='$input_oleh1'";
                $resultN = mysqli_query($GLOBALS["conn"], $queryN);
                $myrowN=mysqli_fetch_array($resultN);
                $id1=$myrowN["id"];
                    
                //insert into eg_bahan2, for other subfields
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan2 VALUES(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "issssssssssssss",
                    $id1,
                    $_POST["callnum1_b"],
                    $_POST["pengarang1_d"],
                    $_POST["tajuk1_b"],
                    $_POST["tajuk1_c"],
                    $_POST["publication1_b"],
                    $_POST["publication1_c"],
                    $_POST["physicaldesc1_b"],
                    $_POST["physicaldesc1_c"],
                    $_POST["physicaldesc1_e"],
                    $_POST["series1_v"],
                    $_POST["sumber0_b"],
                    $_POST["sumber0_e"],
                    $_POST["lokasi1_b"],
                    $_POST["lokasi1_c"]
                );
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                //insert into eg_bahan2_indicator
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan2_indicator VALUES(null, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "issss",
                    $id1,
                    $_POST["pengarang1_in"],
                    $_POST["tajuk1_in"],
                    $_POST["fcnotes1_in"],
                    $_POST["sumber0_in"]
                );
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);

                //insert into eg_bahan_isbn
                $stmt = mysqli_prepare($GLOBALS["conn"], "INSERT INTO eg_bahan_isbn VALUES(null, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt, "issssssssssssssssssss",
                    $id1,
                    $_POST["isbn1_1"],
                    $_POST["isbn1_2"],
                    $_POST["isbn1_3"],
                    $_POST["isbn1_4"],
                    $_POST["isbn1_5"],
                    $_POST["isbn1_6"],
                    $_POST["isbn1_7"],
                    $_POST["isbn1_8"],
                    $_POST["isbn1_9"],
                    $_POST["isbn1_10"],
                    $_POST["isbn1_11"],
                    $_POST["isbn1_12"],
                    $_POST["isbn1_13"],
                    $_POST["isbn1_14"],
                    $_POST["isbn1_15"],
                    $_POST["isbn1_16"],
                    $_POST["isbn1_17"],
                    $_POST["isbn1_18"],
                    $_POST["isbn1_19"],
                    $_POST["isbn1_20"]
                );
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                
                echo "<br/><img src='../images/tick.gif'><br/>All provided data has been inputted into the database. The item ID will be displayed onto your screen, then press OK to continue.";
                
                //reassign and pass it to uploadnow.php
                $idUpload = $id1;
                $timestampUpload = $instimestamp1;
                $inputdateUpload = null;
                                
                //for uploading files related to the document to the server - start
                $max_size = $pdf_upload_maxsize;
                if ($_FILES['file1']['name'] != null) {
                        echo "<br/><br/>File upload status :";
                        $allowed_uploaddir = "../".$pdf_upload_directory;
                        $allowed_ext = "pdf";
                        $allowed_fieldname = "file1";
                        include '../includes/uploadcheck.php';
                        if ($successupload == 'TRUE') {
                            include '../includes/uploadnow.php';
                            echo "File attachment uploaded successfully !";
                            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39pdfattach='TRUE' WHERE id=?");
                            mysqli_stmt_bind_param($stmt, "i", $idUpload);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_close($stmt);
                        } elseif ($successupload == 'FALSE SIZE') {
                            echo "Upload aborted ! Attachment file size > $pdf_upload_maxsize bytes. Please update this record if you need to reupload the file using the record ID.";
                        } else {
                            echo "Upload aborted ! Incorrect file type. Please update this record if you need to reupload the file using the record ID.";
                        }
                }
                
                //for uploading images related to the document to the server - start
                $max_size = $cover_upload_maxsize;
                if ($_FILES['imageatt1']['name'] != null) {
                        echo "<br/><br/>Image upload status :";
                        $allowed_uploaddir = "../".$cover_upload_directory;
                        $allowed_ext = "jpg";
                        $allowed_fieldname = "imageatt1";
                        include '../includes/uploadcheck.php';
                        if ($successupload == 'TRUE') {
                            include '../includes/uploadnow.php';
                            echo "Image attachment uploaded successfully !";
                            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan SET 39imageatt='TRUE' WHERE id=?");
                            mysqli_stmt_bind_param($stmt, "i", $idUpload);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_close($stmt);
                        } elseif ($successupload == 'FALSE SIZE') {
                            echo "Upload aborted ! Attachment image size > $cover_upload_maxsize bytes. Please update this record if you need to reupload the image using the record ID.";
                        } else {
                            echo "Upload aborted ! Incorrect image type. Please update this record if you need to reupload the image using the record ID.";
                        }
                }
                
                echo "<br/><br/>Click <a href='reg_copies.php?id=$id1'>here to begin adding copies</a> or click <a href='reg.php'>here to add a new record</a>.<br/><br/>";
            } else {
                echo "<img src='../images/caution.jpg'><br/>Your previous input has been cancelled.Check if any field(s) left emptied before posting.";
            }

            
            echo "</td></tr>";
            echo "</table>";
            echo "<div>&nbsp;</div>";
        }
    ?>
            
    <?php
    if (!isset($_REQUEST['submitted']) || $_REQUEST['submitted'] != 'TRUE') {
    ?>
            <table style='width:100%;margin-left:auto;margin-right:auto;'>
                <tr style='background-color:#F8EE96;'>
                <td>
                    <div style='text-align:center;width:100%;'><b>Fill in the fields for inserting a new record :</b> *<em>Mandatory</em></div>
                </td>
                </tr>
            </table>
            
            <form name="someform" action="reg.php" method="post" enctype="multipart/form-data" onSubmit="return ValidateForm()">
                <table style='width:100%;margin-left:auto;margin-right:auto;background-color:lightgrey;'>
                        <?php $username_input=$_SESSION['username'];?>

                        <tr style='background-color:white;'><td style='text-align:right;'>Tags</td><td style='width:10px;text-align:center;'>Indi.</td><td colspan=2>Value</td></tr>
                    
                        <tr>
                        <td style='text-align:right;'><b>Type </b>*</td><td></td>
                        <td>:
                         |a<select name="jenis1">
                        <?php
                            $queryB = "select 38typeid, 38type from eg_jenisbahan";
                            $resultB = mysqli_query($GLOBALS["conn"], $queryB);
                                                
                            while ($myrow=mysqli_fetch_array($resultB)) {
                                $typeB=$myrow["38type"];
                                $typeBid=$myrow["38typeid"];
                            
                                if ($get_jenis1 == "$typeBid") {
                                    echo "<option value='$typeBid' selected>$typeB</option>";
                                } else {
                                    echo "<option value='$typeBid'>$typeB</option>";
                                }
                            }
                        ?>
                        </select></td>
                        </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b>Initial status </b>*</td><td></td>
                        <td>:
                         |a<select name="status">
                                <option value="AVAILABLE">Available</option>
                                <option value="CIRCULATED">Circulated (On Loan)</option>
                                <option value="RESERVED">Reserved</option>
                                <option value="ONORDER">On Order</option>
                                <option value="FINALPROCESSING">Final Processing</option>
                                <option value="WEEDED">Weeded</option>
                                <option value="ONHOLD">On Hold</option>
                                <option value="LOST">Lost</option>
                            </select>
                        </td>
                        </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b>Subj. Heading </b></td><td></td>
                        <td>:  |a<input type="text" name="subjectheading1" style="width:60%" readonly="readonly" maxlength="150" placeholder="Select using the [...] button"/>
                        <input type="button" name="subjectheadingButton" value="..." onClick="showList()" />
                        <input type="button" name="gotoSHButton" value="+New" onClick="openSHAdd()" />
                        <input type="button" name="clearSH" value="Clear" onClick="subjectheading1.value='';">
                        </td>
                        </tr>
                    
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_020;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="isbn1" style="width:80%" maxlength="60" placeholder="<?php echo $tag_020ph;?>"/> <a id="al0" style="font-size:8pt;" onclick="document.getElementById('a1').style.display='';document.getElementById('al0').style.display='none';">[+]</a></td>
                        </tr>
                            <?php
                                for ($x=1; $x<=20; $x++) {
                                    $y = $x+1;
                                    echo "<tr id='a$x' style='display:none'>
                                        <td style='text-align:right;vertical-align:top;'><b>$tag_020</b></td><td style='text-align:center;'>**</td>
                                        <td style='vertical-align:top;'>:  |a<input type='text' name='isbn1_$x' style='width:80%' maxlength='60' placeholder='$tag_020ph'/> ";
                                    if ($y <> 20) {
                                        echo "<a id='al$x' style='font-size:8pt;' onclick=\"document.getElementById('a$y').style.display='';document.getElementById('al$x').style.display='none';\">[+]</a>";
                                    }
                                    echo "</td></tr>";
                                }
                            ?>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_022;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="issn1" style="width:80%" maxlength="60" placeholder="<?php echo $tag_022ph;?>"/></td>
                        </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_041;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a
                        <?php
                        if ($tag_041_inputtype == "select") {
                            $selectable_041 = explode("|", $tag_041_selectable);
                            $selectable_041_def = explode("|", $tag_041_selectable_def);
                            echo "<select name='language1'>";
                            for ($x = 0; $x < sizeof($selectable_041); $x++) {
                                echo "<option value='".$selectable_041[$x]."' ";
                                if ($selectable_041[$x] == $tag_041_selectable_default) {
                                    echo "selected";
                                }
                                echo ">".$selectable_041_def[$x]."</option>";
                            }
                            echo "</select>";
                        } else {
                            echo "<input type=\"text\" name=\"language1\" style=\"width:80%;\" maxlength=\"3\" placeholder=\"$tag_041ph\">";
                        }
                        ?>
                        </td>
                        </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_090;?></b></td><td style='text-align:center;'>00</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="callnum1" style="width:80%" maxlength="70" placeholder="<?php echo $tag_090aph;?>"/></td>
                        </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type="text" name="callnum1_b" style="width:80%" maxlength="70" placeholder="<?php echo $tag_090bph;?>"/></td>
                            </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_100;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="pengarang1_in"></td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="pengarang1" style="width:80%" maxlength="150" placeholder="<?php echo $tag_100aph;?>"/></td>
                        </tr>
                            <tr>
                            <td style='vertical-align:top;'></b></td><td></td>
                            <td style='vertical-align:top;'>:  |d<input type="text" name="pengarang1_d" style="width:80%" maxlength="150" placeholder="<?php echo $tag_100dph;?>"/></td>
                            </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_245;?></b>*</td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="tajuk1_in"></td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="tajuk1" style="width:80%" maxlength="255" placeholder="<?php echo $tag_245aph;?>"/>
                        </td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type="text" name="tajuk1_b" style="width:80%" maxlength="255" placeholder="<?php echo $tag_245bph;?>"/>
                            </td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |c<input type="text" name="tajuk1_c" style="width:80%" maxlength="255" placeholder="<?php echo $tag_245cph;?>"/>
                            </td>
                            </tr>
                                    
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_250;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="edition1" style="width:80%" maxlength="255" placeholder="<?php echo $tag_250aph;?>"/></td>
                        </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_264;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="publication1" style="width:80%" maxlength="255" placeholder="<?php echo $tag_264aph;?>"/></td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type="text" name="publication1_b" style="width:80%" maxlength="255" placeholder="<?php echo $tag_264bph;?>"/></td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |c<input type="text" name="publication1_c" style="width:80%" maxlength="255" placeholder="<?php echo $tag_264cph;?>"/></td>
                            </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_300;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="physicaldesc1" style="width:80%" maxlength="255" placeholder="<?php echo $tag_300aph;?>"/></td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type="text" name="physicaldesc1_b" style="width:80%" maxlength="255" placeholder="<?php echo $tag_300bph;?>"/></td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |c<input type="text" name="physicaldesc1_c" style="width:80%" maxlength="255" placeholder="<?php echo $tag_300cph;?>"/></td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |e<input type="text" name="physicaldesc1_e" style="width:80%" maxlength="255" placeholder="<?php echo $tag_300eph;?>"/></td>
                            </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_490;?></b></td><td style='text-align:center;'>0*</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="series1" style="width:80%" maxlength="150" placeholder="<?php echo $tag_490aph;?>"/></td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |v<input type="text" name="series1_v" style="width:80%" maxlength="150" placeholder="<?php echo $tag_490vph;?>"/></td>
                            </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_500;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="notes1"style="width:80%" maxlength="255" placeholder="<?php echo $tag_500aph;?>"/></td>
                        </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_505;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="fcnotes1_in"></td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="fcnotes1"style="width:80%" maxlength="255" placeholder="<?php echo $tag_505aph;?>"/></td>
                        </tr>

                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_710;?></b></td><td style='text-align:center;'><input type="text" size=2 maxlength=2 name="sumber0_in"></td>
                        <td style='vertical-align:top;'>:  |a<input type='text' name='sumber0' style="width:80%" maxlength='255' placeholder="<?php echo $tag_710aph;?>"/></td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type='text' name='sumber0_b' style="width:80%" maxlength='255' placeholder="<?php echo $tag_710bph;?>"/></td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></td><td></td>
                            <td style='vertical-align:top;'>:  |e<input type='text' name='sumber0_e' style="width:80%" maxlength='255' placeholder="<?php echo $tag_710eph;?>"/></td>
                            </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_852;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:  |a<input type="text" name="lokasi1" style="width:80%" maxlength="50" placeholder="<?php echo $tag_852aph;?>"/></td>
                        </tr>
                             
                            <tr>
                            <td style='vertical-align:top;'></b></td><td></td>
                            <td style='vertical-align:top;'>:  |b<input type="text" name="lokasi1_b" style="width:80%" maxlength="50" placeholder="<?php echo $tag_852bph;?>"/></td>
                            </tr>
                            <tr>
                            <td style='vertical-align:top;'></b></td><td></td>
                            <td style='vertical-align:top;'>:  |c<input type="text" name="lokasi1_c" style="width:80%" maxlength="50" placeholder="<?php echo $tag_852cph;?>"/></td>
                            </tr>
                        
                        <tr>
                        <td style='text-align:right;vertical-align:top;'><b><?php echo $tag_856;?></b></td><td style='text-align:center;'>**</td>
                        <td style='vertical-align:top;'>:
                         |u<input type="text" name="link1" style="width:80%" maxlength="255" placeholder="<?php echo $tag_856uph;?>"/>
                        </td>
                        </tr>
                        
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><b>PDF (Max <?php $ini_max = return_bytes(ini_get('upload_max_filesize')); echo (int)$pdf_upload_maxsize < (int)$ini_max ? $pdf_upload_maxsize/1000000 : $ini_max/1000000; ?> MB)</b></td>
                            <td colspan=2>:
                            <input type="file" name="file1" size="38"></td>
                        </tr>
                        
                        <tr>
                            <td style='text-align:right;vertical-align:top;'><b>Book Cover JPG (Max <?php $ini_max = return_bytes(ini_get('upload_max_filesize')); echo (int)$cover_upload_maxsize < (int)$ini_max ? $cover_upload_maxsize/1000000 : $ini_max/1000000; ?> MB)</b></td>
                            <td colspan=2>:
                            <input type="file" name="imageatt1" size="38">
                        </tr>
                                        
                        <tr><td style='vertical-align:top;text-align:center;' colspan='4'>
                            <input type="hidden" name="input_oleh1" value="<?php echo $username_input;?>" />
                            <input type="hidden" name="instimestamp1" value="<?php echo time();?>" />
                            <input type="hidden" name="submitted" value="TRUE" />
                            <br/><br/><input type="submit" name="Submit1" value="Insert" />
                            <br/><br/>
                        </td></tr>
                </table>
            </form>
    <?php
    }//if submitted
    ?>
    
    <br/><div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    
    <br/><hr>

    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
