<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_super.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Change Status</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script>
        window.onunload = refreshParent;
        function refreshParent() {
            window.opener.location.reload();
        }
    </script>
</head>

<body>
    
    <hr><br/>
    
    <?php
        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'Change') {
            $cid = $_REQUEST["cid"];
            $status = $_POST["status"];
            $lastchange = $_POST["lastchange"];
            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan_copies SET 39status=?, 39lastchange=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, "ssi", $status, $lastchange, $cid);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            echo "<script>window.alert(\"Status changed !\");</script>";
        }
        
        if (isset($_REQUEST["cid"]) && is_numeric($_REQUEST["cid"])) {
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT 39status FROM eg_bahan_copies WHERE id=?");
            mysqli_stmt_bind_param($stmt, "i", $_REQUEST["cid"]);
            mysqli_stmt_execute($stmt);
            $resultS = mysqli_stmt_get_result($stmt);
            $myrowS=mysqli_fetch_array($resultS);
            mysqli_stmt_close($stmt);
            $statusS=$myrowS["39status"];
        }
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Set status</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:380;text-align:center;'><br/>
        <form action="change_status.php" method="post" enctype="multipart/form-data">
            <select name="status">
                <option value="AVAILABLE" <?php if ($statusS == 'AVAILABLE') {echo "selected";}?>>Available</option>
                <option value="CIRCULATED" <?php if ($statusS == 'CIRCULATED') {echo "selected";}?>>Circulated (On Loan)</option>
                <option value="RESERVED" <?php if ($statusS == 'RESERVED') {echo "selected";}?>>Reserved</option>
                <option value="ONORDER" <?php if ($statusS == 'ONORDER') {echo "selected";}?>>On Order</option>
                <option value="FINALPROCESSING" <?php if ($statusS == 'FINALPROCESSING') {echo "selected";}?>>Final Processing</option>
                <option value="WEEDED" <?php if ($statusS == 'WEEDED') {echo "selected";}?>>Weeded</option>
                <option value="ONHOLD" <?php if ($statusS == 'ONHOLD') {echo "selected";}?>>On Hold</option>
                <option value="LOST" <?php if ($statusS == 'LOST') {echo "selected";}?>>Lost</option>
            </select><br/>
            <input type="hidden" name="cid" value="<?php echo $_REQUEST["cid"];?>" />
            <input type="hidden" name="lastchange" value="<?php echo time();?>" />
            <br/><input type="submit" name="submitted" value="Change" />
        </form>
        </td></tr>
    </table>
    
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="#" onclick="window.close();">Close</a> ]</div>
    
    <br/><hr>
    
</body>

</html>
