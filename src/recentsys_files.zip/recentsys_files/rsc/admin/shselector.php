<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    if ($_GET['clr'] == 'upd') {
        $formField = "3";
    } elseif ($_GET['clr'] == 'reg') {
        $formField = "1";
    }
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Subject Heading Selector</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    <script language="JavaScript">
        function pick(symbol) {
          if (window.opener && !window.opener.closed)
            {
                if (window.opener.document.someform.subjectheading<?php echo $formField;?>.value == '')
                    window.opener.document.someform.subjectheading<?php echo $formField;?>.value = symbol + '|';
                else
                    window.opener.document.someform.subjectheading<?php echo $formField;?>.value = window.opener.document.someform.subjectheading<?php echo $formField;?>.value + symbol + '|';
            }
            window.close();
        }
    </script>
    
    Select a subject heading related to the item :
            
    <hr>
    <u>ID</u> <u>Subject Heading</u><br/>
    <?php
        $queryC = "select 43subjectid, 43subject, 43acronym from eg_subjectheading order by 43acronym";
        $resultC = mysqli_query($GLOBALS["conn"], $queryC);
        
        while ($myrow=mysqli_fetch_array($resultC)) {
            $subjectidC=$myrow["43subjectid"];
            $subjectC=$myrow["43subject"];
            $subjectAcr=$myrow["43acronym"];
            echo "$subjectAcr <a href=\"javascript:pick('$subjectAcr')\">$subjectC</a><br/>";
        }
    ?>
    
    <br/>
    
    <div style='text-align:center;width:100%;'><FORM><INPUT type="button" value="Cancel" onClick="window.close()"> </FORM></div>
    
</body>

</html>
