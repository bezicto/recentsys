<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_logged.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Discharging</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body onload="document.getElementById('accessnum').focus();">
    
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <hr><br/>
    
    <?php

        if (isset($_REQUEST["submitted"]) && $_REQUEST["submitted"] == 'Discharge') {
            $accessnum = $_POST["accessnum"];
            $lodged_time = time();
            if (existCharge($accessnum) == 1) {
                $enforced_fine = getIDCurrentEnforcedFine(getTypeID($accessnum));
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan_charge SET 40dc='DC', 40dc_on=?, 40dc_by=?, 40dc_enforcedfine=? WHERE 39accessnum=? AND 40dc != 'DC'");
                mysqli_stmt_bind_param($stmt, "isis", $lodged_time, $_SESSION["username"], $enforced_fine, $accessnum);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
                
                $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_bahan_copies SET 39status='AVAILABLE', 39lastchange=? WHERE 39accessnum=?");
                mysqli_stmt_bind_param($stmt, "is", $lodged_time, $accessnum);
                mysqli_stmt_execute($stmt);
                mysqli_stmt_close($stmt);
            } else {
            echo "<script>window.alert(\"Error.\");</script>";
            }
        }
        
    ?>

    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Discharging :</b></td></tr>
        <tr style='background-color:lightgrey;'><td colspan=2 style='width:100%;text-align:center;'><br/>
        <form action="discharge.php" method="post" enctype="multipart/form-data">
                <b>Accession number : </b><br/>
                <input type="text" id="accessnum" name="accessnum" style='width:350px;' maxlength="70"/><br/><br/>
                    
                <input type="hidden" name="submitted" value="Discharge" />
                <input type="submit" name="Submit1" value="Discharge"/>
        </form>
        </td></tr>
    </table>
    
    <br/><br/>

    <table style='width:90%;margin-left:auto;margin-right:auto;background-color:white;'>
        <tr style='background-color:#FFFE96;'><td colspan=7 style='text-align:center;'><b>Today's discharge session :</b></td></tr>
        <tr style='background-color:#F8EE96;text-align:center;'><td>#</td><td>Accession Number</td><td>Patron</td><td>Due Date</td><td>Discharge Info</td><td>Late ?</td><td>Late Fines (<?php echo $currency_SHORT;?>)</td></tr>
        
        <?php
            $stmt = mysqli_prepare($GLOBALS["conn"], "SELECT * FROM eg_bahan_charge WHERE 40dc='DC' AND 40dc_on >= ? AND 39charged_by = ?");
            $today_timestamp = strtotime(date("Y-m-d"));
            mysqli_stmt_bind_param($stmt, "is", $today_timestamp, $_SESSION['username']);
            mysqli_stmt_execute($stmt);
            $resultT = mysqli_stmt_get_result($stmt);
            $n = 1;
            while ($myrowT=mysqli_fetch_array($resultT)) {
                    $accessnum=$myrowT["39accessnum"];
                    $patron=$myrowT["39patron"];
                    $charged_on=$myrowT["39charged_on"];
                    $dc_on=$myrowT["40dc_on"];
                    $dc_by=$myrowT["40dc_by"];
                    $dc_enforcedfine=$myrowT["40dc_enforcedfine"];
                    $duedate_mp=$myrowT["39duedate"];
                                        
                    $maxSecond = (maxday($patron)*($duedate_mp+1))*86400;//for calculating due date
                    $beginOfDay_for_charged_on = strtotime("midnight", $charged_on);//early morning for the day charged
                    $duedate = $beginOfDay_for_charged_on + $maxSecond + 86399;// + 86399 to reach midnight
                    $duedate = shiftDueDate($duedate); //shifting duedate if holiday
                    
                    echo "<tr bgcolor='EBF0FE'>";
                        echo "<td style='text-align:center;'>$n</td>";
                        echo "<td>$accessnum<br/><em>".getTypeName($accessnum)."</em></td>";
                        echo "<td>$patron</td>";
                        echo "<td>".date('D, Y-m-d', $duedate)."</td>";
                        echo "<td>".date('D, Y-m-d h:i:s a', $dc_on)." by $dc_by</td>";
                        
                        $minusdays = (($dc_on - $duedate)/86400) + 1;

                        echo "<td style='text-align:center;'>";
                            if ($dc_on <= $duedate) {
                                echo "No";
                            } else {
                                echo "Yes";
                                echo "<br/>".floor($minusdays)." day(s)";
                            }
                        echo "</td>";
                        echo "<td style='text-align:center;'>";
                            if ($minusdays >= 0) {
                                echo calculatedFines(floor($minusdays), $accessnum, $dc_enforcedfine);
                            } else {
                                echo "-";
                            }
                        echo "</td>";
                    echo "</tr>";
                    $n = $n + 1;
                }
        ?>
        
    </table>
        
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
