<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_logged.php';
    include_once '../config.php';
    include_once '../includes/functions.php';
    unset($_SESSION['paysearch']);
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Payment Search</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body onload="document.getElementById('accessnum').focus();">
    
    <?php
        if (isset($_POST['pid']) && $_POST['pid'] != '' && patronUsernameToID($_POST['pid']) >= 1) {
            echo "<script type='text/javascript'>location.href='payhistory.php?pid=".patronUsernameToID($_POST['pid'])."';</script>";
            $_SESSION['paysearch'] = "on";
        } elseif (isset($_POST['pid']) && patronUsernameToID($_POST['pid']) == 0) {
            echo "<script>alert('Not a valid ID.');</script>";
        } elseif (isset($_POST['pid']) && $_POST['pid'] == '') {
            echo "<script>alert('Not a valid ID.');</script>";
        }
    
        include_once '../includes/loggedinfo.php';
    ?>
    
    <hr><br/>
    
    <table style='width:70%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#FFFE96;'><td colspan=2 style='text-align:center;'><b>Search patron for fines:</b></td></tr>
        <tr style='background-color:lightgrey;'><td style='width:380;text-align:center;'><br/>
        <form action="paysearch.php" method="post" enctype="multipart/form-data">
            <b>Patron ID:</b><br/>
            <input type="text" name="pid" width="350px" maxlength="70"/><br/><br/>
            <input type="submit" name="search" value="Search"/>
        </form>
        </td></tr>
    </table>
    
    <br/><br/>
    
    <div style='text-align:center;width:100%;'>[ <a href="../index2.php">Back to start page</a> ]</div>
    <br/><hr>
    
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
