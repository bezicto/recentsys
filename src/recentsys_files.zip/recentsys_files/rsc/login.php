<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once 'config.php';
    if (isset($_SESSION['username_myacc'])) {
        $tempusername = $_SESSION['username_myacc'];
        
        $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET online='OFF' WHERE username=?");
        mysqli_stmt_bind_param($stmt, "s", $tempusername);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);

        unset($_SESSION['username_myacc']);
        unset($_SESSION['lastlogin']);
    }
    require_once './includes/mobiledetect.php';
    $detect = new Mobile_Detect;

    $datelog = date("D d/m/Y h:i a");

    //preventing CSRF
    include_once 'includes/token_validate.php';
?>

<html lang='en'>

<head>
    <?php
        if ($detect->isMobile()) {
            echo "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1\">";
        }
    ?>
    <title><?php echo $product_name;?> | Indexing Database</title>
    <link href="<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="./styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    <br/><br/>
    
    <table style='width:90%;margin-left:auto;margin-right:auto;'>
        <tr>
            <td colspan=2 style='text-align:center;'>
            <br/><img src='images/edituser_big.png' alt='Edit'><br/>
            My Account Portal<br/><br/>
            
                <form action="login.php" method="post">
                    <br/><b>IC Number : </b><br/><input type="text" name="username" size="25" maxlength="25"/>
                    <br/><b>Password : </b><br/><input type="password" name="password" size="25" maxlength="25"/>
    
                    <br/><br/>
                    <input type="hidden" name="submitted" value="TRUE" /><br/>
                    <input type="hidden" name="token" value="<?php echo $_SESSION['token'] ?? '' ?>">
                    <input type="submit" class="form-submit-button" name="Submit1" value="Login" />
                    <input type="button" class="form-grey-button" name="Cancel" value="Cancel" onclick="window.location='index.php'";>
                </form>
            </td>
        </tr>
        <tr><td colspan=2><?php include_once './includes/footerbar.php';?></td></tr>
    </table>
    
    <?php
        if (isset($_REQUEST['submitted']) && $_REQUEST['submitted'] == 'TRUE' && $proceedAfterToken) {
            $query_login = "select id, username, aes_decrypt(passphrase,'$ppaeskeysys') as password, allowed, lastlogin, online, devmode  from eg_auth where username='".$_POST['username']."'";
            $result_login = mysqli_query($GLOBALS["conn"], $query_login);
            $num_results_affected_login = mysqli_num_rows($result_login);
            
            echo "<table align='center' width=90%><tr><td style='text-align:center;'>Status : ";
            
            if ($num_results_affected_login <> 0) {
                while ($myrow=mysqli_fetch_array($result_login)) {
                        $id2=$myrow["id"];
                        $username2=$myrow["username"];
                        $password2=$myrow["password"];
                        $date2=$myrow["lastlogin"];
                        $online2=$myrow["online"];
                }
                
                if ($_POST['username'] == $username2 && $_POST['password'] == $password2) {
                    if ($online2 == 'OFF') {
                            echo "Authentication complete. You will be directed in no time.";
                            $_SESSION['username_myacc']=$_POST['username'];
                            $_SESSION['lastlogin']=$date2;
                            $stmt = mysqli_prepare($GLOBALS["conn"], "UPDATE eg_auth SET lastlogin=?, online='ON' WHERE id=?");
                            mysqli_stmt_bind_param($stmt, "si", $datelog, $id2);
                            mysqli_stmt_execute($stmt);
                            mysqli_stmt_close($stmt);
                            echo "<script>document.location.href='logged.php'</script>";
                    } else {
                        echo "Improper log-out session detected. Contact your administrator.";
                    }
                } else {
                    echo "Incorrect authentication information detected !";
                }
            } else {
                echo "Cannot find username !";
            }
        
            echo "</td></tr></table><br/>";
        }
    ?>
    
</body>
    
</html>

<?php exit;?>
