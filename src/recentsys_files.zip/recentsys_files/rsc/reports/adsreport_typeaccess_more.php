<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if (!is_numeric($_GET["type"]) || strlen($_GET["acstat"]) <> 7) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Illegal Access</h2><em>System Response Code</em></div>";
        exit;
    }

    echo "<h2>Type Access for ".$_GET["typetext"]." in the month of ".$_GET["acstat"]."</h2>";
?>
<table style='width:100%;border:1px solid;'>
<tr style='text-align:left;border:1px solid;'><th style='border:1px solid;'></th><th style='border:1px solid;'>Item ID</th><th style='border:1px solid;'>Internet Protocol Address</th><th style='border:1px solid;'>Title</th></tr>
<?php
    $n=1;
    $acstat = $_GET["acstat"];
    $query2 = "select eg_bahan_det.eg_bahan_id as eg_bahan_id, eg_bahan_det.39ipaddr as 39ipaddr from eg_bahan_det,eg_bahan where eg_bahan.39type='".$_GET["type"]."' and eg_bahan.id=eg_bahan_det.eg_bahan_id and eg_bahan_det.39logdate like '%$acstat%'";
    $result2 = mysqli_query($GLOBALS["conn"], $query2);
    while ($myrow2=mysqli_fetch_array($result2)) {
        $id=$myrow2["eg_bahan_id"];
        $ipaddr=$myrow2["39ipaddr"];
        
        $query21 = "select 38title from eg_bahan where id='$id'";
        $result21 = mysqli_query($GLOBALS["conn"], $query21);
        $myrow21=mysqli_fetch_array($result21);
            $title=$myrow21["38title"];
        
        echo "<tr><td style='border:1px solid;'>$n</td><td style='border:1px solid;'>$id</td><td style='border:1px solid;'>$ipaddr</td><td style='border:1px solid;'>$title</td></tr>";
        
        $n=$n+1;
    }
?>
</table>
