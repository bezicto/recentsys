<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if (!is_numeric($_GET["type"])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Illegal Access</h2><em>System Response Code</em></div>";
        exit;
    }
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Type Details</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="../jscripts/popup_report.js"></script>
</head>

<body>
    
    <script type="text/javascript" src="../jscripts/calendarDateInput.js"></script>
        
    <?php include_once '../includes/loggedinfo.php';?>
                    
    <hr>

    <div style='width:100%;text-align:center;'>
    <?php
        $typeid = $_GET["type"];
        $typetext = $_GET["typetext"];
        
        //for listing the years materials were input
        echo "<table align=center border=0 width=300><tr style='background-color:#FFFE96;'><td style='text-align:center;'>";
            $query3 = "select distinct SUBSTRING(40inputdate,7) AS inputyear from eg_bahan order by inputyear";
            $result3 = mysqli_query($GLOBALS["conn"], $query3);
            echo "<b>Select year</b> :";
            echo " <select name=\"inputyear\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
                while ($myrow3=mysqli_fetch_array($result3)) {
                    $inputyear=$myrow3["inputyear"];
                                    
                    echo "<option value=\"adsreport_typedetails.php?inputyear=$inputyear&type=$typeid&typetext=$typetext\"";
                    if (isset($_GET["inputyear"]) && $_GET["inputyear"] == $inputyear) {
                        echo " selected";
                    }
                    if (!isset($_GET["inputyear"]) && $inputyear == date('Y')) {
                        echo " selected";
                    }
                    echo ">$inputyear</option>";
                }
            echo "</select>";
        echo "</td></tr></table>";
    ?>

    <?php
        echo "<table align=center border=0 width=300>";
        echo "<tr bgcolor=#FFFE96 align=center><td><b>$typetext Statistics</b> : ";
        echo "</td></tr></table>";
                                                
        echo "<table style='margin-left:auto;margin-right:auto;' border='0' width='300' bgcolor='lightblue'>";
        echo "<tr style='background-color:white;text-align:center;'><td>Month</td><td width=80>Total Index</td><td width=80>Total Index (Cumulative)</td></tr>";
                                                                                        
        $jumlah = 0;$n = 0;
        for ($counter = 1; $counter <= 12; $counter += 1) {
            if (isset($_GET["inputyear"])) {
                $inputyear = $_GET["inputyear"];
            } else {
                $inputyear = date('Y');
            }
            
            if ($counter <= 9) {
                $query2 = "select count(id) as totalid from eg_bahan where 39type='$typeid' and 40inputdate like '%0$counter/$inputyear%'";
            } else {
                $query2 = "select count(id) as totalid from eg_bahan where 39type='$typeid' and 40inputdate like '%$counter/$inputyear%'";
            }
                
            $result2 = mysqli_query($GLOBALS["conn"], $query2);
            $myrow=mysqli_fetch_array($result2);
            $num_results_affected=$myrow["totalid"];

            echo "<tr bgcolor='EBF0FE' class=yellowHover>";
                echo "<td>$counter/$inputyear</td>";
                $jumlah = $jumlah + $num_results_affected;
                echo "<td>$num_results_affected</td><td>$jumlah</td>";
            echo "</tr>";
        }
            
        echo "<tr rowspan='2'><td colspan=3>*Please take note that, the total cumulative does not represent total index in the system. It only represent total for the current selected year.</td></tr>";
        echo "</table>";
    ?>

    <br/><br/>
    [ <a href="adsreport.php?toggle=2">Back to report page</a> ]
    
    </div>
    
    <hr>
        
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
