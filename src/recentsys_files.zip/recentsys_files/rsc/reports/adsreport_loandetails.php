<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
?>

<?php

    if (strlen($_GET['hitsDate']) == 7) {
        $hitsDate = $_GET['hitsDate'];
    } else {
        $hitsDate = '01/1922';
    }

    $query1 = "select SQL_CALC_FOUND_ROWS *  from eg_bahan_charge where DATE_FORMAT(FROM_UNIXTIME(39charged_on), '%d/%m/%Y') like '%$hitsDate%' order by id";
    $result1 = mysqli_query($GLOBALS["conn"], $query1);
    $row1 = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
    $num_results_affected = $row1[0];

    echo "<table border='1' width='100%'>";
        echo "<tr><td colspan=4 style='text-align:center;'>Total recorded loans : <b>$num_results_affected</b> for <b>$hitsDate</b></td></tr>";
        echo "<tr><td></td><td><b>Item</b></td><td><b>Transaction</b></td><td><b>Charged on</b></td></tr>";
                                                        
        $n = 1;
        while ($myrow=mysqli_fetch_array($result1)) {
            echo "<tr>";
            
            $id2=$myrow["id"];
            $accession2=$myrow["39accessnum"];
                $queryBahanID= "select eg_bahan_id from eg_bahan_copies where 39accessnum like '$accession2'";
                $resultBahanID = mysqli_query($GLOBALS["conn"], $queryBahanID);
                $myrowBahanID= mysqli_fetch_array($resultBahanID);
                    $queryNamaBahan= "select 38title from eg_bahan where id='".$myrowBahanID['eg_bahan_id']."'";
                    $resultNamaBahan = mysqli_query($GLOBALS["conn"], $queryNamaBahan);
                    $myrowNamaBahan= mysqli_fetch_array($resultNamaBahan);
                    $bahanTitle = $myrowNamaBahan['38title'];
            $patron2=$myrow["39patron"];
                $querypatronName= "select username, name from eg_auth where username like '$patron2'";
                $resultpatronName = mysqli_query($GLOBALS["conn"], $querypatronName);
                $myrowpatronName= mysqli_fetch_array($resultpatronName);
                $patron2 = $myrowpatronName["name"];
                $username2 = $myrowpatronName["username"];
            $chargedon2=date('d/m/Y H:i:s', $myrow["39charged_on"]);
                    
            echo "<td>$n</td><td>$bahanTitle</td><td>$patron2 ($username2)</td><td>$chargedon2</td></tr>";
                                                                                                                
            $n = $n +1 ;
        }
    echo "</table>";
