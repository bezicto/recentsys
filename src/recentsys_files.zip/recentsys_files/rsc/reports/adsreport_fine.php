<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if (strlen($_GET['m']) == 7) {
        $m = $_GET['m'] ?? '01/1922';
    } else {
        $m = '01/1922';
    }

    $querySTATlf = "select 39patron, 41f_paidon, 41f_received_amount from eg_bahan_charge where DATE_FORMAT(FROM_UNIXTIME(41f_paidon), '%d/%m/%Y') like '%$m%' group by 41f_receipt_id order by 41f_paidon";
    $resultSTATlf = mysqli_query($GLOBALS["conn"], $querySTATlf);
    $n = 1;
    $total = 0.00;
    echo "<h2>Fine collection for $m</h2>";
    echo "<table width=100% border=1>";
        echo "<tr align=left><th></th><th>Patron</th><th>Payment Date</th><th>Amount</th></tr>";
        while ($myrowSTATlf = mysqli_fetch_array($resultSTATlf)) {
            echo "<tr><td>".$n."</td><td>".$myrowSTATlf["39patron"]."</td><td>".date('D, Y-m-d h:i:s a', $myrowSTATlf["41f_paidon"])."</td><td>".$myrowSTATlf["41f_received_amount"]."</td></tr>";
            $total = $total + $myrowSTATlf["41f_received_amount"];
            $n=$n+1;
        }
        echo "<tr align=right><th colspan=3>Total $currency_SHORT</th><th align=left>$total</th></tr>";
    echo "</table>";
