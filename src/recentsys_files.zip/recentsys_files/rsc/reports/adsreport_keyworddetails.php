<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Keyword Stats</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>

    <div style='width:100%;text-align:center;'>

        <?php
            $show2 = 'latest';
            if (isset($_GET['show'])) {$show2 = $_GET['show'];}
        ?>

        <table style='width:100%;margin-left:auto;margin-right:auto;'>
        <tr style='background-color:#F8EE96;'><td style='text-align:center;'>
            [<a href='adsreport_keyworddetails.php?show=latest'>Sort by latest keyword</a>] | [<a href='adsreport_keyworddetails.php?show=popular'>Sort by keyword popularity</a>]
        </td></tr>
        </table>

        <?php
            include_once '../includes/paging-p1.php';
                                                                                
            if ($show2 == 'popular') {
                $query1 = "select *  from eg_userlog order by 37freq desc LIMIT $offset, $rowsPerPage";
            } else {
                $query1 = "select *  from eg_userlog order by id desc LIMIT $offset, $rowsPerPage";
            }
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                                            
            //paging 2 start
            $query2 = "select count(*) as totalr from eg_userlog order by id desc";
            $result2 = mysqli_query($GLOBALS["conn"], $query2);

            $myrowr=mysqli_fetch_array($result2);
            $num_results_affected=$myrowr["totalr"];
            $maxPage = ceil($num_results_affected/$rowsPerPage);
            $self = $_SERVER['PHP_SELF'];
            //paging 2 end

            echo "<table border='0' width='100%' bgcolor='lightblue'>";
            echo "<tr bgcolor='#FFFE96'><td align=center colspan=4>Total recorded unique search terms : <b>$num_results_affected</b></td></tr>";
            echo "<tr style='background-color:white;text-align:center;'><td>#</td><td>Terms</td><td>Total Hits</td><td>Last used</td></tr>";
                                                            
            $n = $offset + 1;
            
            while ($myrow=mysqli_fetch_array($result1)) {
                echo "<tr bgcolor='EDF0F6'>";
                    $id2=$myrow["id"];
                    $keyword2=$myrow["37keyword"];
                    $freq2=$myrow["37freq"];
                    $lastlog2=$myrow["37lastlog"];
                    echo "<td>$n</td><td>$keyword2</td><td>$freq2</td><td>$lastlog2</td>";
                echo "</tr>";
                $n = $n +1 ;
            }
            echo "</table>";
            
            echo "<table align=center border=0 width=100% bgcolor='lightblue'>";
            echo "<tr bgcolor=lightgreen>";
            //paging 3 start
            if ($maxPage > 1) {
                if ($pageNum > 1) {
                    $page = $pageNum - 1;
                    $prev = " [ <a href=\"$self?page=$page&show=$show2\">Previous</a> ] ";
                    $first = " [ <a href=\"$self?page=1&show=$show2\">First</a> ] ";
                }  else {
                    $prev  = ' [Previous] ';
                    $first = ' [First] ';
                }

                if ($pageNum < $maxPage) {
                    $page = $pageNum + 1;
                    $next = " [ <a href=\"$self?page=$page&show=$show2\">Next</a> ] ";
                    $last = " [ <a href=\"$self?page=$maxPage&show=$show2\">Last</a> ] ";
                }  else {
                    $next = ' [Next] ';
                    $last = ' [Last] ';
                }

                echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
            }
            //paging 3 ended

            echo "</tr>";
            echo "</table>";
        ?>
    
        <br/><br/>
    
        [ <a href="adsreport.php?toggle=3">Back to report page</a> ]

    </div>

    <hr>

    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
