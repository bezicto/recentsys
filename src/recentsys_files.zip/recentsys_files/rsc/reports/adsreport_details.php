<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    include_once '../includes/del_code.php';

    $get_inf = '';$get_infname = '';$getappend = '';
    if ($_SESSION['editmode'] == 'SUPER' && (isset($_GET['inf']) && $_GET['inf'] != '')) {
        $get_inf = $_GET["inf"];
        $get_infname = $_GET["infname"];
        $getappend = "&inf=$get_inf&infname=$get_infname";
    } else {
        $get_inf = $_SESSION["username"];
    }
        
    if (isset($_GET["inputyear"]) && is_numeric($_GET["inputyear"])) {
        $get_inputyear = $_GET["inputyear"];
    } elseif (isset($_GET["inputyear"]) && $_GET["inputyear"] == 'All') {
        $get_inputyear = 'All';
    } elseif (isset($_GET["inputyear"]) && !is_numeric($_GET["inputyear"])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Illegal Access</h2><em>System Response Code</em></div>";
        exit;
    } else {
        $get_inputyear = 'All';
    }
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Admin Report Details</title>
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <script src="../jscripts/popup_report.js" type="text/javascript"></script>
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
                    
    <hr>

    <div style='width:100%;text-align:center;'>
        <?php
                include_once '../includes/paging-p1.php';
                                                        
                //for listing the years materials were input
                echo "<table bgcolor=#FFFE96 align=center border=0 width=100%>";
                echo "<tr style='background-color:#FFFE96;'><td style='text-align:center;'>";
                $query3 = "select distinct SUBSTRING(40inputdate,7) AS inputyear from eg_bahan order by inputyear";
                $result3 = mysqli_query($GLOBALS["conn"], $query3);
                echo "<b>Select year</b> :";
                            
                echo " <select name=\"inputyear\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
                    while ($myrow3=mysqli_fetch_array($result3)) {
                        $inputyear=$myrow3["inputyear"];
                        echo "<option value=\"adsreport_details.php?";
                        echo "inputyear=$inputyear$getappend\"";
                        if ($get_inputyear == $inputyear) {echo " selected";}
                        echo ">$inputyear</option>";
                    }
                    echo "<option value=\"adsreport_details.php?";
                    echo "inputyear=All$getappend\"";
                    if ($get_inputyear== 'All') {echo " selected";}
                    echo " >All</option>";
                echo "</select>";
                echo "</td></tr></table>";
                                        
                $query1 = "select SQL_CALC_FOUND_ROWS * from eg_bahan where 40inputby='$get_inf'";
                if ($get_inputyear <> 'All') {$query1 .= " and 40inputdate like '%$get_inputyear'";}
                $query1 .= " order by id desc LIMIT $offset, $rowsPerPage";
                $result1 = mysqli_query($GLOBALS["conn"], $query1);

                include_once '../includes/paging-p2.php';
                
                echo "<table bgcolor=#FFFE96 align=center border=0 width=100%><tr style='background-color:#FFFE96;'><td><div style='text-align:center;width:100%;'>";
                    echo "<b>User Statistics : </b>";
                    echo "$get_infname $get_inf";
                    echo "<b><br/>";
                    echo "Total input ";
                    if ($get_inputyear <> 'All') {echo "for year $get_inputyear";}
                    echo " :</b> $num_results_affected";
                echo "</div></td></tr></table>";

                //code to calculate month count for input materials
                if ($get_inputyear != 'All') {
                    $month_array = array();
                        for ($counter=1; $counter<=12; $counter+=1) {
                            if ($counter <= 9) {
                                $counter_text = '0'.$counter;
                            } elseif ($counter >= 10) {
                                $counter_text = $counter;
                            }
                            $get_monthcount = $counter_text.'/'.$get_inputyear;
                            $query3 = "select count(*) as total3 from eg_bahan where 40inputby='$get_inf' and 40inputdate like '%$get_monthcount'";
                            $result3 = mysqli_query($GLOBALS["conn"], $query3);
                            $myrow3=mysqli_fetch_array($result3);
                            $month_array[] = $myrow3["total3"];
                        }
                                        
                    if ($_SESSION['editmode'] == 'SUPER') {
                        $userappend = "&user=$get_inf";
                    }
                        
                    echo "<table style='margin-left:auto;margin-right:auto;width:100%;'>";
                    echo "<tr bgcolor=#FFEE96>";
                            echo "<td><b>Jan:</b> <a href='adsreport_details_inc_pop.php?month=01&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[0]</a></td>";
                            echo "<td><b>Feb:</b> <a href='adsreport_details_inc_pop.php?month=02&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[1]</a></td>";
                            echo "<td><b>Mac:</b> <a href='adsreport_details_inc_pop.php?month=03&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[2]</a></td>";
                            echo "<td><b>Apr:</b> <a href='adsreport_details_inc_pop.php?month=04&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[3]</a></td>";
                            echo "<td><b>May:</b> <a href='adsreport_details_inc_pop.php?month=05&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[4]</a></td>";
                            echo "<td><b>Jun:</b> <a href='adsreport_details_inc_pop.php?month=06&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[5]</a></td>";
                            echo "</tr>";
                    
                            echo "<tr bgcolor=#FFEE96>";
                            echo "<td><b>Jul:</b> <a href='adsreport_details_inc_pop.php?month=07&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[6]</a></td>";
                            echo "<td><b>Aug:</b> <a href='adsreport_details_inc_pop.php?month=08&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[7]</a></td>";
                            echo "<td><b>Sep:</b> <a href='adsreport_details_inc_pop.php?month=09&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[8]</a></td>";
                            echo "<td><b>Oct:</b> <a href='adsreport_details_inc_pop.php?month=10&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[9]</a></td>";
                            echo "<td><b>Nov:</b> <a href='adsreport_details_inc_pop.php?month=11&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[10]</a></td>";
                            echo "<td><b>Dec:</b> <a href='adsreport_details_inc_pop.php?month=12&year=".$get_inputyear."$userappend' onclick=\"return openPopup(this.href);\">$month_array[11]</a></td>";
                            echo "</tr>";
                    echo "</table>";
                    
                    unset($month_array);
                }
                
                echo "<table border='0' width='100%' bgcolor='lightblue'>";
                echo "<tr style='background-color:white;'><td width=25 align=center>#</td><td width=60 align=center>Doc ID<td style='text-align:center;'>Title</td><td align=center width=140>Type</td><td align=center width=80>Input date</td></tr>";
                                                        
                $n = $offset + 1;
                                                    
                while ($myrow=mysqli_fetch_array($result1)) {
                    $tajuk_a=$myrow["38title"];
                    $jenis_a=$myrow["39type"];
                    $id_a=$myrow["id"];
                    $dateinput_a=$myrow["40inputdate"];
                    
                    $query_a = "select 38type from eg_jenisbahan where 38typeid = '$jenis_a'";
                    $result_a = mysqli_query($GLOBALS["conn"], $query_a);
                    $myrow_a=mysqli_fetch_array($result_a);
                        $jenis_a_mod=$myrow_a["38type"];
                    
                    echo "<tr bgcolor='EDF0F6'>";
                    
                    echo "<td style='text-align:center;'>$n</td><td style='text-align:center;'><a href='../details.php?det=$id_a";
                    if ($get_inf <> null && $get_infname <> null) {
                        echo "&delr=rep&infname=$get_infname";
                    } else {
                        echo "&delr=urep";
                    }
                    echo "&page=$pageNum'>$id_a</td><td style='text-align:left;'>$tajuk_a</td>";
                    echo "<td>$jenis_a_mod</td><td>$dateinput_a</td></tr>";
                                                                    
                    $n = $n +1 ;
                }
                echo "</table>";
                
                echo "<table align=center border=0 width=100% bgcolor='lightblue'>";
                echo "<tr bgcolor=lightgreen>";
                //paging 3 start
                $pagingappend = '';
                if (isset($get_inputyear) && $get_inputyear != '') {
                    $pagingappend .= "&inputyear=$get_inputyear";
                }
                if ($_SESSION['editmode'] == 'SUPER') {
                    $pagingappend .= "&inf=$get_inf&infname=$get_infname";
                }
                                    
                if ($pageNum > 1) {
                    $page = $pageNum - 1;
                    $prev = " [ <a href=\"$self?page=$page$pagingappend\">Previous</a> ] ";
                    
                    $first = " [ <a href=\"$self?page=1$pagingappend\">First</a> ] ";
                }  else {
                    $prev  = ' [Previous] ';
                    $first = ' [First] ';
                }
        
                if ($pageNum < $maxPage) {
                    $page = $pageNum + 1;
                    $next = " [ <a href=\"$self?page=$page$pagingappend\">Next</a> ] ";
                    
                    $last = " [ <a href=\"$self?page=$maxPage$pagingappend\">Last</a> ] ";
                }  else {
                    $next = ' [Next] ';
                    $last = ' [Last] ';
                }
                
                if ($num_results_affected > $rowsPerPage) {
                    echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
                }
                //paging 3 ended
                
                echo "</tr>";
                echo "</table>";
                
        ?>
        
        <br/><br/>
        [ <a href="../index2.php">Back to start page</a> ]
        
        <?php if ($_SESSION['editmode'] == 'SUPER') { ?>
        [ <a href="adsreport.php">Back to report page</a> ]
        <?php }?>
    </div>
    
    </br></br></hr>
        
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
