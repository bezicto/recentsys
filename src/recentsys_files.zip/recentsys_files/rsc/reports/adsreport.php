<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if (isset($_GET['toggle']) && !is_numeric($_GET['toggle'])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Illegal Access</h2><em>System Response Code</em></div>";
        exit;
    }
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : Admin Report</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="../jscripts/popup_report.js"></script>
</head>

<body>

    <script type="text/javascript" src="../jscripts/calendarDateInput.js"></script>
    <?php include_once '../includes/loggedinfo.php';?>
                    
    <hr>

    <div style='width:100%;text-align:center;'>
        
        <br/>
        
        <a href='adsreport.php?toggle=1'>Data Managers Report</a>
         | <a href='adsreport.php?toggle=2'>Type Statistics</a>
         | <a href='adsreport.php?toggle=3'>Search Statistical Tools</a>
         | <a href='adsreport.php?toggle=4'>Loan Statistical Tools</a>
         | <a href='adsreport.php?toggle=5'>Fine Collection Report</a>
        <br/><br/>

            <?php if ((isset($_GET['toggle']) && $_GET['toggle'] == '1') || (!isset($_GET['toggle']))) {?>
            <?php
                                                                                                                            
                $query1 = "select username,name,lastlogin,online from eg_auth where allowed='SUPER' or allowed='TRUE'";
                $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                            
                    echo "<table align=center border=0 width=95% bgcolor='lightblue'><tr bgcolor=#FFFE96 align=center><td>";
                    echo "<b>Data Managers Report :</b><br/>System administrators and data managers";
                    echo " with their input statistics.";
                    echo "</td></tr></table>";
                                                        
                    echo "<table style='margin-left:auto;margin-right:auto;' border='0' width='95%' bgcolor='lightblue'>";
                    echo "<tr style='background-color:white;text-align:center;'><td>#</td><td>User</td><td>Total records<br/>(Input)</td><td>Total records<br/>(Edits)</td><td>Last logged-in</td></tr>";
                                                                                                
                    $n = 1;
                                                        
                    while ($myrow=mysqli_fetch_array($result1)) {
                            echo "<tr bgcolor='white' class='yellowHover'>";
                        
                            $username2=$myrow["username"];
                            $name2=$myrow["name"];
                            $lastlogin2=$myrow["lastlogin"];
                            $online2=$myrow["online"];
                                                            
                            $query2 = "select count(id) as totalid from eg_bahan where 40inputby='$username2' ";
                            $result2 = mysqli_query($GLOBALS["conn"], $query2);
                            $myrowr = mysqli_fetch_array($result2);
                            $num_results_affected=$myrowr["totalid"];
        
                            $query2a = "select count(id) as totalida from eg_bahan where 40lastupdateby='$username2' ";
                            $result2a = mysqli_query($GLOBALS["conn"], $query2a);
                            $myrowra = mysqli_fetch_array($result2a);
                            $num_results_affecteda=$myrowra["totalida"];
                                                            
                            echo "<td>$n</td><td>$name2 ";
                            if ($_SESSION['editmode'] == 'SUPER') {echo "[$username2]";}
                            echo "</td>";
                            echo "<td style='text-align:center;'><a href='adsreport_details.php?inf=$username2&infname=$name2'>$num_results_affected</a></td><td style='text-align:center;'>$num_results_affecteda</td>";
                            echo "<td style='text-align:center;'>";
                            if ($online2 == 'ON') {
                                echo "$lastlogin2<sup>ONLINE</sup>";
                            } else {
                                echo "$lastlogin2";
                            }
                            echo "</td></tr>";
                                                                                                            
                            $n = $n +1 ;
                        }
                        echo "</table>";
            ?>
            <?php }?>
    
            <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '2') {?>
            <?php
                                                                                                                        
                $query2 = "select distinct 39type from eg_bahan";
                $result2 = mysqli_query($GLOBALS["conn"], $query2);
            
                echo "<table align=center border=0 width=95% bgcolor='lightblue'>";
                echo "<tr bgcolor=#FFFE96 align=center><td><b>Type statistics</b> : ";
                echo "</td></tr></table>";
                                                        
                echo "<table style='margin-left:auto;margin-right:auto;' border='0' width='95%' bgcolor='lightblue'>";
                echo "<tr style='background-color:white;text-align:center;'><td>#</td><td>Type</td><td>Total Index</td><td>Total Accessed (Cumulative)</td><td>Total Accessed (Unique)</td><td>Total Loaned</td></tr>";
                                                                                                
                $m = 1;
                $jumlah = 0;$jumlahhits = 0;$jumlahunique = 0;$jumlahType = 0;
                                                        
                while ($myrow=mysqli_fetch_array($result2)) {
                        echo "<tr align=center bgcolor='white' class='yellowHover'>";
                        
                        $jenisbahan2 = $myrow["39type"];
                                                            
                        $query3 = "select count(id) as totalid, sum(41hits) as totalhits from eg_bahan where 39type='$jenisbahan2' ";
                        $result3 = mysqli_query($GLOBALS["conn"], $query3);
                        $myrowr = mysqli_fetch_array($result3);
                        $num_results_affected=$myrowr["totalid"];
                        $num_hits_affected2=$myrowr["totalhits"];
                        
                        $query4 = "select count(id) as uniquehits from eg_bahan where 39type='$jenisbahan2' and 41hits>0";
                        $result4 = mysqli_query($GLOBALS["conn"], $query4);
                        $myrow4 = mysqli_fetch_array($result4);
                        $num_unique_hits2=$myrow4["uniquehits"];
                                                                                                
                        echo "<td>$m</td><td>";
                            $queryTy = "select 38type from eg_jenisbahan where 38typeid = '$jenisbahan2'";
                            $resultTy = mysqli_query($GLOBALS["conn"], $queryTy);
                            $myrowTy=mysqli_fetch_array($resultTy);
                            $jenisTy=$myrowTy["38type"];
                            echo "$jenisTy";
                        echo "</td>";
                        
                        $querySy = "select count(eg_bahan.39type) as num_type
                        from eg_bahan_charge, eg_bahan_copies, eg_bahan
                        where eg_bahan_charge.39accessnum = eg_bahan_copies.39accessnum and eg_bahan_copies.eg_bahan_id = eg_bahan.id
                        and eg_bahan.39type=$jenisbahan2";
                        $resultSy = mysqli_query($GLOBALS["conn"], $querySy);
                        $myrowSy = mysqli_fetch_array($resultSy);
                        $num_results_type2=$myrowSy["num_type"];
                        
                        echo "<td><a href='adsreport_typedetails.php?type=$jenisbahan2&typetext=$jenisTy'>$num_results_affected</a></td>";
                        echo "<td><a href='adsreport_typeaccess.php?type=$jenisbahan2&typetext=$jenisTy'>$num_hits_affected2</a></td>";
                        echo "<td>$num_unique_hits2</td>";
                        echo "<td>$num_results_type2</td>";
                        echo "</tr>";
                                                            
                        $jumlah = $jumlah + $num_results_affected;
                        $jumlahhits = $jumlahhits + $num_hits_affected2;
                        $jumlahunique = $jumlahunique + $num_unique_hits2;
                        $jumlahType = $jumlahType + $num_results_type2;
                        $m = $m +1 ;
                    }
                echo "<tr bgcolor='EDF0F6'><td colspan=2 style='text-align:right;'><em>Total :</em></td><td style='text-align:center;'><em>$jumlah</em></td><td style='text-align:center;'><em>$jumlahhits</em></td><td style='text-align:center;'><em>$jumlahunique</em></td><td style='text-align:center;'>$jumlahType</td></tr>";
                echo "</table>";
            ?>
            <?php }?>
    
            <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '3') {?>
                <?php
                    $querySUM = "select sum(37freq) as totalhitSUM from eg_userlog";
                    $resultSUM = mysqli_query($GLOBALS["conn"], $querySUM);
                    $myrowSUM = mysqli_fetch_array($resultSUM);
                    $numSUM=$myrowSUM["totalhitSUM"];
                ?>
                <table style='margin-left:auto;margin-right:auto;background-color:lightblue;width:95%;'>
                    <tr style='background-color:#FFFE96;text-align:center;'><td colspan=2><b>Search Statistical Tools</b></td></tr>
                    <tr style='background-color:#EDF0F6'><td style='width:70%;text-align:left;'>Total search hits until today :</td>
                    <td><b><?php echo "$numSUM";?> </b><br/>View details: <a href='adsreport_keyworddetails.php'>Search Terms</a> | <a href='adsreport_ipdetails.php'>IP Addresses</a></td></tr>
                                    
                    <tr style='background-color:#EDF0F6'><td style='text-align:left;'><form name="getMonthStat" action="adsreport.php?toggle=3" method=post>Search hits by month :
                    <select name='monthly'>
                        <option value='01' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '01')) {echo 'selected';}?>>Jan</option>
                        <option value='02' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '02')) {echo 'selected';}?>>Feb</option>
                        <option value='03' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '03')) {echo 'selected';}?>>Mar</option>
                        <option value='04' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '04')) {echo 'selected';}?>>Apr</option>
                        <option value='05' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '05')) {echo 'selected';}?>>May</option>
                        <option value='06' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '06')) {echo 'selected';}?>>June</option>
                        <option value='07' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '07')) {echo 'selected';}?>>Jul</option>
                        <option value='08' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '08')) {echo 'selected';}?>>Aug</option>
                        <option value='09' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '09')) {echo 'selected';}?>>Sep</option>
                        <option value='10' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '10')) {echo 'selected';}?>>Oct</option>
                        <option value='11' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '11')) {echo 'selected';}?>>Nov</option>
                        <option value='12' <?php if ((isset($_POST['monthly'])) && ($_POST['monthly'] == '12')) {echo 'selected';}?>>Dec</option>
                    </select>
                    and year :
                    <input type="text" name="yearly" size="5" <?php if (isset($_POST['yearly'])) {echo 'value="'.$_POST['yearly'].'"';}?> maxlength="4"/>
                    <input type="submit" value="Submit Query"></form></td>
                    <td>
                        <?php
                            if ((isset($_POST['monthly'])) && (isset($_POST['yearly']))) {
                                $hitsSTRING = $_POST['monthly'].'/'.$_POST['yearly'];
                                $querySTAT = "select count(id) as totalhitSTAT from eg_userlog_det where 38logdate like '%$hitsSTRING%'";
                                $resultSTAT = mysqli_query($GLOBALS["conn"], $querySTAT);
                                $myrowSTAT = mysqli_fetch_array($resultSTAT);
                                $numSTAT=$myrowSTAT["totalhitSTAT"];
                                echo '<a target=\'_blank\' href=\'adsreport_hitsdetails.php?hitsDate='.$hitsSTRING.'\'>'.$numSTAT.' hits</a>';
                            } else {
                                echo '0 hit';
                            }
                        ?>
                    </td></tr>

                    <tr style='background-color:#EDF0F6;'><td style='text-align:left;'><a style='text-decoration:none'>Search hits by date :</a>
                        <form name="getTarikh" action="adsreport.php?toggle=3" method="post">
                            <script>DateInput('hitsDate', true, 'DD/MM/YYYY' <?php if (isset($_POST['hitsDate'])) {echo ",'".$_POST['hitsDate']."'";} ?>)</script>
                            <input type="submit" value="Submit Query">
                        </form>
                    </td>
                    <td>
                    <?php
                        if (isset($_POST['hitsDate'])) {
                            $hitsDate = $_POST['hitsDate'];
                            $querySUMselect = "select count(id) as totalhitSUMselect from eg_userlog_det where 38logdate like '%$hitsDate%'";
                            $resultSUMselect = mysqli_query($GLOBALS["conn"], $querySUMselect);
                            $myrowSUMselect = mysqli_fetch_array($resultSUMselect);
                            $numSUMselect=$myrowSUMselect["totalhitSUMselect"];
                        
                            if ($numSUMselect <> 0) {
                                echo '<a target=\'_blank\' href=\'adsreport_hitsdetails.php?hitsDate='.$hitsDate.'\'>'.$numSUMselect.' hits</a><br/><br/>';
                            } else {
                                echo '0 hit<br/><br/>';
                            }
                        }
                    ?>
                    </td></tr>
                </table>
            <?php }?>
    
            <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '4') {?>
                <?php
                    $querySUMl = "select count(id) as totalLoan from eg_bahan_charge";
                    $resultSUMl = mysqli_query($GLOBALS["conn"], $querySUMl);
                    $myrowSUMl = mysqli_fetch_array($resultSUMl);
                    $numSUMl=$myrowSUMl["totalLoan"];
                ?>
                <table style='margin-left:auto;margin-right:auto;width:95%;background-color:lightblue;'>
                    <tr style='background-color:#FFFE96;text-align:center;'><td colspan=2><b>Loans Statistical Tools</b></td></tr>
                    <tr style='background-color:#EDF0F6'>
                        <td style='width:70%;text-align:left;'>Total loans until today : </td>
                        <td><b><?php echo "$numSUMl";?></b></td>
                    </tr>
                                    
                    <tr style='background-color:#EDF0F6'><td style='text-align:left;'><form name="getMonthStat" action="adsreport.php?toggle=4" method=post>Loans by month :
                    <select name='lmonthly'>
                        <option value='01' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '01')) {echo 'selected';}?>>Jan</option>
                        <option value='02' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '02')) {echo 'selected';}?>>Feb</option>
                        <option value='03' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '03')) {echo 'selected';}?>>Mar</option>
                        <option value='04' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '04')) {echo 'selected';}?>>Apr</option>
                        <option value='05' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '05')) {echo 'selected';}?>>May</option>
                        <option value='06' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '06')) {echo 'selected';}?>>June</option>
                        <option value='07' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '07')) {echo 'selected';}?>>Jul</option>
                        <option value='08' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '08')) {echo 'selected';}?>>Aug</option>
                        <option value='09' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '09')) {echo 'selected';}?>>Sep</option>
                        <option value='10' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '10')) {echo 'selected';}?>>Oct</option>
                        <option value='11' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '11')) {echo 'selected';}?>>Nov</option>
                        <option value='12' <?php if ((isset($_POST['lmonthly'])) && ($_POST['lmonthly'] == '12')) {echo 'selected';}?>>Dec</option>
                    </select>
                    and year :
                    <input type="text" name="lyearly" size="5" <?php if (isset($_POST['lyearly'])) {echo 'value="'.$_POST['lyearly'].'"';}?> maxlength="4"/>
                     <input type="submit" value="Submit Query"></form></td>
                    <td>
                        <?php
                            if ((isset($_POST['lmonthly'])) && (isset($_POST['lyearly']))) {
                                $hitsSTRINGl = $_POST['lmonthly'].'/'.$_POST['lyearly'];
                                $querySTATl = "select count(id) as totalhitSTAT from eg_bahan_charge where DATE_FORMAT(FROM_UNIXTIME(39charged_on), '%d/%m/%Y') like '%$hitsSTRINGl%'";
                                $resultSTATl = mysqli_query($GLOBALS["conn"], $querySTATl);
                                $myrowSTATl = mysqli_fetch_array($resultSTATl);
                                $numSTATl=$myrowSTATl["totalhitSTAT"];
                                echo '<a target=\'_blank\' href=\'adsreport_loandetails.php?hitsDate='.$hitsSTRINGl.'\'>'.$numSTATl.' transactions</a><br/><br/>';
                            } else {
                                echo '0 transaction';
                            }
                        ?>
                    </td></tr>

                    <tr style='background-color:#EDF0F6'><td style='text-align:left;'><a style='text-decoration:none'>Loans by date :</a>
                        <form name="getTarikhL" action="adsreport.php?toggle=4" method="post">
                            <script>DateInput('hitsDateL', true, 'DD/MM/YYYY' <?php if (isset($_POST['hitsDateL'])) {echo ",'".$_POST['hitsDateL']."'";} ?>)</script>
                            <input type="submit" value="Submit Query">
                        </form>
                    </td>
                    <td>
                    <?php
                        if (isset($_POST['hitsDateL'])) {
                            $hitsDateL = $_POST['hitsDateL'];
                            $querySUMselectL = "select count(id) as totalhitSUMselect from eg_bahan_charge where DATE_FORMAT(FROM_UNIXTIME(39charged_on), '%d/%m/%Y') like '%$hitsDateL%'";
                            $resultSUMselectL = mysqli_query($GLOBALS["conn"], $querySUMselectL);
                            $myrowSUMselectL = mysqli_fetch_array($resultSUMselectL);
                            $numSUMselectL=$myrowSUMselectL["totalhitSUMselect"];
                        
                            if ($numSUMselectL <> 0) {
                                echo '<a target=\'_blank\' href=\'adsreport_loandetails.php?hitsDate='.$hitsDateL.'\'>'.$numSUMselectL.' transactions</a><br/><br/>';
                            } else {
                                echo '0 transaction<br/><br/>';
                            }
                        }
                    ?>
                    </td></tr>
                </table>
            <?php }?>

            <?php if (isset($_GET['toggle']) && $_GET['toggle'] == '5') {?>
                <?php
                    $querySUMlf = "select sum(41f_received_amount) as totalFineCollection from eg_bahan_charge";
                    $resultSUMlf = mysqli_query($GLOBALS["conn"], $querySUMlf);
                    $myrowSUMlf = mysqli_fetch_array($resultSUMlf);
                    $numSUMlf=$myrowSUMlf["totalFineCollection"];
                ?>
                <table style='margin-left:auto;margin-right:auto;width:95%;background-color:lightblue;'>
                    <tr style='background-color:#FFFE96;text-align:center;'><td colspan=2><b>Fine Collection Report</b></td></tr>
                    <tr style='background-color:#EDF0F6'>
                        <td style='text-align:left;width:70%;'>Total fine collection until today : </td>
                        <td><b><?php echo "$currency_SHORT $numSUMlf";?></b></td>
                    </tr>
                                    
                    <tr style='background-color:#EDF0F6'><td style='text-align:left;'><form name="getMonthFine" action="adsreport.php?toggle=5" method=post>Loans by month :
                    <select name='fmonthly'>
                        <option value='01' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '01')) {echo 'selected';}?>>Jan</option>
                        <option value='02' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '02')) {echo 'selected';}?>>Feb</option>
                        <option value='03' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '03')) {echo 'selected';}?>>Mar</option>
                        <option value='04' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '04')) {echo 'selected';}?>>Apr</option>
                        <option value='05' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '05')) {echo 'selected';}?>>May</option>
                        <option value='06' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '06')) {echo 'selected';}?>>June</option>
                        <option value='07' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '07')) {echo 'selected';}?>>Jul</option>
                        <option value='08' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '08')) {echo 'selected';}?>>Aug</option>
                        <option value='09' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '09')) {echo 'selected';}?>>Sep</option>
                        <option value='10' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '10')) {echo 'selected';}?>>Oct</option>
                        <option value='11' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '11')) {echo 'selected';}?>>Nov</option>
                        <option value='12' <?php if ((isset($_POST['fmonthly'])) && ($_POST['fmonthly'] == '12')) {echo 'selected';}?>>Dec</option>
                    </select>
                    and year :
                    <input type="text" name="fyearly" size="5" <?php if (isset($_POST['fyearly'])) {echo 'value="'.$_POST['fyearly'].'"';}?> maxlength="4"/>
                     <input type="submit" value="Submit Query"></form></td>
                    <td>
                        <?php
                            if ((isset($_POST['fmonthly'])) && (isset($_POST['fyearly']))) {
                                $hitsSTRINGlf = $_POST['fmonthly'].'/'.$_POST['fyearly'];
                                $querySTATlf = "select sum(41f_received_amount) as totalFine from (select 41f_receipt_id, 41f_received_amount from eg_bahan_charge where DATE_FORMAT(FROM_UNIXTIME(41f_paidon), '%d/%m/%Y') like '%$hitsSTRINGlf%' group by 41f_receipt_id) as A";
                                $resultSTATlf = mysqli_query($GLOBALS["conn"], $querySTATlf);
                                $myrowSTATlf = mysqli_fetch_array($resultSTATlf);
                                $numSTATlf=$myrowSTATlf["totalFine"];
                                echo "<a href='adsreport_fine.php?m=$hitsSTRINGlf' target='_blank'>$currency_SHORT $numSTATlf</a>";
                            } else {
                                echo "$currency_SHORT 0.00";
                            }
                        ?>
                    </td></tr>
                </table>
            <?php }?>
                        
        <br/>
        [ <a href="../index2.php">Back to start page</a> ]
        
    </div>
                    
    <hr>
    
    <?php include_once '../includes/footerbar.php';?>

</body>

</html>
