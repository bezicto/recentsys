<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
    
    if (strlen($_GET['hitsDate']) == 7) {
        $hitsDate = $_GET['hitsDate'];
    } else {
        $hitsDate = '01/1922';
    }
    
    //---- ip filter for hits details
    $queryIP = "select count(distinct id, substring_index(38ipaddr,'.',3)) as total1c, substring_index(38ipaddr,'.',3) as 38ipaddr from eg_userlog_det where 38logdate like '%$hitsDate%' group by substring_index(38ipaddr,'.',3) order by total1c desc";
    $resultIP = mysqli_query($GLOBALS["conn"], $queryIP);
    $tdIP = 1;
    echo "<table width=100% border=1>";
    echo "<tr><td colspan=6 style='text-align:center;'>Search hits statistics per IP for <b>$hitsDate</b></td></tr>";
    echo "<tr>";
    while ($myrowIP=mysqli_fetch_array($resultIP)) {
        $ipaddrIP=$myrowIP["38ipaddr"];
        $total1cIP=$myrowIP["total1c"];
        
        echo "<td>$ipaddrIP.* : $total1cIP hits</td>";
        
        if ($tdIP % 6 == 0) {echo "</tr><tr bgcolor='#d6fdfe'>";}
        $tdIP++;
    }
    echo "</tr></table><br/>";
    
    //---- details
    $query1 = "select SQL_CALC_FOUND_ROWS *  from eg_userlog_det where 38logdate like '%$hitsDate%' order by id";
    $result1 = mysqli_query($GLOBALS["conn"], $query1);
    $row1 = mysqli_fetch_row(mysqli_query($GLOBALS["conn"], "SELECT FOUND_ROWS()"));
    $num_results_affected = $row1[0];
                                                                                                      
    echo "<table border='1' width='100%'>";
    echo "<tr><td colspan=4 style='text-align:center;'>Total recorded search hits : <b>$num_results_affected</b> for <b>$hitsDate</b></td></tr>";
    echo "<tr><td></td><td><b>Terms</b></td><td><b>Lodged detail</b></td><td><b>IP Address</b></td></tr>";
    $n = 1;
    while ($myrow=mysqli_fetch_array($result1)) {
        $id2=$myrow["id"];
        $keyword2=$myrow["38keyword"];
        $datelog2=$myrow["38logdate"];
        $ipaddr2=$myrow["38ipaddr"];
        echo "<tr><td>$n</td><td>$keyword2</td><td>$datelog2</td><td>$ipaddr2</td></tr>";
        $n = $n +1 ;
    }
    echo "</table>";
