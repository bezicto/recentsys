<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if ($_SESSION['editmode'] == 'SUPER') {
        $get_user = $_GET["user"];
    } else {
        $get_user = $_SESSION["username"];
    }

    if (!is_numeric($_GET["month"]) || !is_numeric($_GET["year"])) {
        echo "<div style='text-align:center;margin-top:100px;'><span style='font-size:40px;color:blue;'><strong>WARNING</strong></span><h2>Forbidden: Illegal Access</h2><em>System Response Code</em></div>";
        exit;
    }
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Admin Report Details Popup</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>

    <hr>
    <div style='width:100%;text-align:center;'>
        <?php
            echo "Input summary for $get_user of ".$_GET["month"]."/".$_GET["year"]."<br/><br/>";

            $queryU = "select 38typeid, 38type from eg_jenisbahan";
            $resultU = mysqli_query($GLOBALS["conn"], $queryU);

            while ($row=mysqli_fetch_array($resultU)) {
                $queryUf = "select count(*) as totalUf from eg_bahan where 40inputby='$get_user' and 40inputdate like '%".$_GET["month"]."/".$_GET["year"]."' and 39type='".$row['38typeid']."'";
                $resultUf = mysqli_query($GLOBALS["conn"], $queryUf);
                $myrowUf=mysqli_fetch_array($resultUf);
                $num_results_affectedUf=$myrowUf["totalUf"];
                echo $row['38type']." - $num_results_affectedUf<br/>";
            }
        ?>
        <br/><br/>
        [ <a href="javascript:window.close();">Close</a> ]
    </div>

    <hr>

</body>

</html>
