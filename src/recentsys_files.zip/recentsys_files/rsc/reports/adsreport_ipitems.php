<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';

    if (is_numeric($_GET['det'])) {
        $id = $_GET['det'];
    } else {
        $id = 0;
    }
?>

<html lang='en'>

<head>
    <title><?php echo $product_name;?> : Item per IP Access Log</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <table style='width:100%;margin-left:auto;margin-right:auto;background-color:#80aaef;'>
        <div style='width:100%;text-align:center;'>
            <?php
                    
                    include_once '../includes/paging-p1.php';
                                    
                    $query1 = "select SQL_CALC_FOUND_ROWS 39ipaddr, 39logdate from eg_bahan_det where eg_bahan_id=$id order by id desc LIMIT $offset, $rowsPerPage";
                    $result1 = mysqli_query($GLOBALS["conn"], $query1);
                    
                    include_once '../includes/paging-p2.php';
            
                    echo "<table align=center border='0' width='550' bgcolor='EDF0F6'>";
                        echo "<tr bgcolor='#FFFE96'><td colspan=4 style='text-align:center;'>";
                            echo "<b>Item per IP Access Log </b>";
                            echo " for item ID: $id";
                            echo "<br/>Recorded accessed: $num_results_affected";
                        echo "</td></tr>";
                        echo "<tr bgcolor='lightgrey'><td align=center width=30><b>#</b></td><td width=150 align=center><b>IP Address</b></td><td style='text-align:center;'><b>Accessed on</b></td></tr>";
                                                                        
                        $n = $offset + 1;
                        
                        while ($myrow=mysqli_fetch_array($result1)) {
                            $ipaddr2=$myrow["39ipaddr"];
                            $logdate2=$myrow["39logdate"];
                            
                            echo "<tr bgcolor='EDF0F6' onMouseOver=\"this.style.backgroundColor='#FFF493'\";onMouseOut=\"this.style.backgroundColor='#EDF0F6'\">";
                                echo "<td style='text-align:center;'><b>$n</b></td><td>$ipaddr2</td><td>$logdate2</td>";
                            echo "</tr>";
                                                                                                                                
                            $n = $n +1 ;
                        }
                    echo "</table>";
                                            
                    echo "<table align=center border=0 width=550>";
                    echo "<tr bgcolor=lightgreen>";
                    //paging 3 start
                    if ($maxPage > 1) {
                        if ($pageNum > 1) {
                            $page = $pageNum - 1;
                            $prev = " [ <a href=\"$self?det=".$_GET["det"]."&page=$page\">Previous</a> ] ";
                            
                            $first = " [ <a href=\"$self?det=".$_GET["det"]."&page=1\">First</a> ] ";
                        }  else {
                            $prev  = ' [Previous] ';
                            $first = ' [First] ';
                        }
                        if ($pageNum < $maxPage) {
                            $page = $pageNum + 1;
                            $next = " [ <a href=\"$self?det=".$_GET["det"]."&page=$page\">Next</a> ] ";
                            
                            $last = " [ <a href=\"$self?det=".$_GET["det"]."&page=$maxPage\">Last</a> ] ";
                        }  else {
                            $next = ' [Next] ';
                            $last = ' [Last] ';
                        }
                        echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
                        //paging 3 ended
                    }
                    echo "</tr>";
                    echo "</table>";
            ?>
        </div>
        
        <hr>
        
        <?php
            include_once '../includes/footerbar.php';
        ?>
        
</body>

</html>
