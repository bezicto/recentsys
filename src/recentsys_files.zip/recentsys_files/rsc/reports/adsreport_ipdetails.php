<!DOCTYPE HTML>
<?php
    session_start();define('includeExist', true);
    include_once '../includes/access_isset.php';
    include_once '../config.php';
?>

<html lang='en'>
<head>
    <title><?php echo $product_name;?> : IP search log report</title>
    <link href="../<?php echo $mini_icon_path;?>" rel="icon" type="image/png" />
    <link href="../styles/style.css" rel="stylesheet" type="text/css">
</head>

<body>
    
    <?php include_once '../includes/loggedinfo.php';?>
    
    <div style='width:100%;text-align:center;'>
    <?php
        include_once '../includes/paging-p1.php';
            
        echo "<table style='margin-left:auto;margin-right:auto;' border='0' width='70%' bgcolor='lightblue'>";
            echo "<tr bgcolor='#FFFE96'><td colspan=4 style='text-align:center;'><b>IP search log sort by : </b>";
        
            echo " <select name=\"sortby\" ONCHANGE=\"location = this.options[this.selectedIndex].value;\">";
                echo "<option value=\"adsreport_ipdetails.php?page=1&sortby=ip\"";
                if (isset($_GET["sortby"]) && $_GET["sortby"] == 'ip') {
                    echo " selected";
                    $sortby = '38ipaddr';
                    $sortbyf = 'ip';
                }
                echo ">IP</option>";
                echo "<option value=\"adsreport_ipdetails.php?page=1&sortby=hits\"";
                if (!isset($_GET["sortby"]) || $_GET["sortby"] == 'hits') {
                        echo " selected";
                        $sortby = 'total1c';
                        $sortbyf = 'hits';
                    }
                echo " >Hits</option>";
            echo "</select>";
        
            echo "</td></tr>";

            $query1 = "select count(distinct id, substring_index(38ipaddr,'.',3)) as total1c, substring_index(38ipaddr,'.',3) as 38ipaddr from eg_userlog_det group by substring_index(38ipaddr,'.',3) order by $sortby desc LIMIT $offset, $rowsPerPage";
            $result1 = mysqli_query($GLOBALS["conn"], $query1);
                                                        
            //paging 2 start
            $query2 = "select count(distinct substring_index(38ipaddr,'.',3)) as totalr from eg_userlog_det";
            $result2 = mysqli_query($GLOBALS["conn"], $query2);

            $myrowr=mysqli_fetch_array($result2);
            $num_results_affected=$myrowr["totalr"];
            $maxPage = ceil($num_results_affected/$rowsPerPage);
            $self = $_SERVER['PHP_SELF'];
            //paging 2 end


            echo "<tr bgcolor='lightgrey'><td align=center width=30><b>#</b></td><td width=150 align=center><b>IP Address</b></td><td width=80 align=center><b>Frequency</b></td><td style='text-align:center;'><b>Last logged</b></td></tr>";
                                                        
            $n = $offset + 1;
        
            while ($myrow=mysqli_fetch_array($result1)) {
                $ipaddr2=$myrow["38ipaddr"];
                $total1c = $myrow["total1c"];
                        
                $query1d = "select 38logdate as last1d from eg_userlog_det where substring_index(38ipaddr,'.',3)='$ipaddr2' ORDER BY id DESC LIMIT 1 ";
                $result1d = mysqli_query($GLOBALS["conn"], $query1d);
                $myrow1d=mysqli_fetch_array($result1d);
                $last1d = $myrow1d["last1d"];
            
                echo "<tr bgcolor='EDF0F6' onMouseOver=\"this.style.backgroundColor='#FFF493'\";onMouseOut=\"this.style.backgroundColor='#EDF0F6'\">";
                echo "<td style='text-align:center;'><b>$n</b></td><td>$ipaddr2.*</td><td>$total1c</td><td>$last1d</td></tr>";
                                                                                                                
                $n = $n +1 ;
            }
        echo "</table>";

        echo "<table align=center border=0 width=70%>";
        echo "<tr bgcolor=lightgreen>";
        //paging 3 start
        if ($maxPage > 1) {
            if ($pageNum > 1) {
                $page = $pageNum - 1;
                $prev = " [ <a href=\"$self?page=$page&sortby=$sortbyf\">Previous</a> ] ";
                
                $first = " [ <a href=\"$self?page=1&sortby=$sortbyf\">First</a> ] ";
            }  else {
                $prev  = ' [Previous] ';
                $first = ' [First] ';
            }
    
            if ($pageNum < $maxPage) {
                $page = $pageNum + 1;
                $next = " [ <a href=\"$self?page=$page&sortby=$sortbyf\">Next</a> ] ";
                
                $last = " [ <a href=\"$self?page=$maxPage&sortby=$sortbyf\">Last</a> ] ";
            }  else {
                $next = ' [Next] ';
                $last = ' [Last] ';
            }
    
            echo "<td align=right bgcolor=#80aaef>" . $first . $prev . "</td><td align=center bgcolor=#9db3fb> Showing page <strong>$pageNum</strong> of <strong>$maxPage</strong> </td><td align=left bgcolor=#80aaef>" . $next . $last . "</td>";
        }
        //paging 3 ended
        
        echo "</tr>";
        echo "</table>";
    ?>
        <br/>
        <br/>[ <a href="adsreport.php?toggle=3">Back to report page</a> ]
    </div>
    
    <hr>
            
    <?php include_once '../includes/footerbar.php';?>
    
</body>

</html>
