-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 10, 2026 at 01:50 AM
-- Server version: 12.1.2-MariaDB
-- PHP Version: 8.5.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rc5db_install`
--

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth`
--

CREATE TABLE `eg_auth` (
  `id` int(5) NOT NULL,
  `username` varchar(15) NOT NULL,
  `passphrase` mediumtext CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `allowed` varchar(255) NOT NULL DEFAULT 'FALSE',
  `name` varchar(255) NOT NULL,
  `division` varchar(255) NOT NULL,
  `lastlogin` varchar(25) DEFAULT NULL,
  `online` varchar(3) NOT NULL DEFAULT 'OFF',
  `devmode` varchar(3) NOT NULL DEFAULT 'NO'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_auth`
--

INSERT INTO `eg_auth` (`id`, `username`, `passphrase`, `allowed`, `name`, `division`, `lastlogin`, `online`, `devmode`) VALUES
(1, 'admin', 'ê¬¸*’‰…’Å|ýú\\Ü', 'SUPER', 'Administrator', 'System Admin', 'Sun 08/02/2026 10:22 pm', 'OFF', 'NO');

-- --------------------------------------------------------

--
-- Table structure for table `eg_auth_allowedloan`
--

CREATE TABLE `eg_auth_allowedloan` (
  `id` int(11) NOT NULL,
  `usertype` varchar(255) NOT NULL,
  `usertypedesc` varchar(255) NOT NULL,
  `max_day` int(11) NOT NULL,
  `max_loanitem` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_auth_allowedloan`
--

INSERT INTO `eg_auth_allowedloan` (`id`, `usertype`, `usertypedesc`, `max_day`, `max_loanitem`) VALUES
(1, 'SUPER', 'Administration', 20, 20),
(2, 'TRUE', 'Basic Administrative Account', 20, 20),
(3, 'PATRON', 'Patron - Library User', 14, 2),
(4, 'FALSE', 'Deactivated Account', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan`
--

CREATE TABLE `eg_bahan` (
  `id` int(11) NOT NULL,
  `38isbn` varchar(60) NOT NULL,
  `38issn` varchar(60) NOT NULL,
  `38localcallnum` varchar(70) NOT NULL,
  `38author` varchar(150) NOT NULL,
  `38title` varchar(255) NOT NULL,
  `38edition` varchar(255) NOT NULL,
  `38publication` varchar(255) NOT NULL,
  `38physicaldesc` varchar(255) NOT NULL,
  `38series` varchar(150) NOT NULL,
  `38notes` varchar(255) NOT NULL,
  `38fcnotes` varchar(255) DEFAULT NULL,
  `38source` varchar(255) NOT NULL,
  `38location` varchar(50) NOT NULL,
  `38link` varchar(255) DEFAULT 'NULL',
  `39type` varchar(1) NOT NULL,
  `39subjectheading` varchar(150) DEFAULT 'NULL',
  `39pdfattach` varchar(255) DEFAULT '''FALSE''',
  `39imageatt` varchar(255) DEFAULT 'NULL',
  `39language` varchar(3) NOT NULL DEFAULT 'zsm',
  `40inputby` varchar(50) NOT NULL,
  `40inputdate` varchar(25) NOT NULL,
  `40proposedelete` varchar(5) NOT NULL DEFAULT 'FALSE',
  `40lastupdateby` varchar(50) DEFAULT NULL,
  `40instimestamp` varchar(12) DEFAULT NULL,
  `41hits` int(11) DEFAULT 0,
  `50search_cloud` mediumtext NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan2`
--

CREATE TABLE `eg_bahan2` (
  `id` int(11) NOT NULL,
  `eg_bahan_id` int(11) NOT NULL,
  `38localcallnum_b` varchar(255) NOT NULL,
  `38author_d` varchar(255) NOT NULL,
  `38title_b` varchar(255) NOT NULL,
  `38title_c` varchar(255) NOT NULL,
  `38publication_b` varchar(255) NOT NULL,
  `38publication_c` varchar(255) NOT NULL,
  `38physicaldesc_b` varchar(255) NOT NULL,
  `38physicaldesc_c` varchar(255) NOT NULL,
  `38physicaldesc_e` varchar(255) NOT NULL,
  `38series_v` varchar(255) NOT NULL,
  `38source_b` varchar(255) NOT NULL,
  `38source_e` varchar(255) NOT NULL,
  `38location_b` varchar(255) NOT NULL,
  `38location_c` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan2_indicator`
--

CREATE TABLE `eg_bahan2_indicator` (
  `id` int(11) NOT NULL,
  `eg_bahan_id` int(11) NOT NULL,
  `38author_i` varchar(2) DEFAULT NULL,
  `38title_i` varchar(2) DEFAULT NULL,
  `38fcnotes_i` varchar(2) DEFAULT NULL,
  `38source_i` varchar(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan_charge`
--

CREATE TABLE `eg_bahan_charge` (
  `id` int(11) NOT NULL,
  `39accessnum` varchar(150) NOT NULL,
  `39patron` varchar(150) NOT NULL,
  `39charged_on` varchar(150) NOT NULL,
  `39charged_by` varchar(150) NOT NULL,
  `39duedate` int(11) DEFAULT 0,
  `40dc` varchar(2) NOT NULL,
  `40dc_on` varchar(150) NOT NULL,
  `40dc_by` varchar(150) NOT NULL,
  `40dc_enforcedfine` int(11) DEFAULT NULL,
  `41f_pay` varchar(255) NOT NULL DEFAULT 'NO',
  `41f_paidon` varchar(255) DEFAULT NULL,
  `41f_received` varchar(255) DEFAULT NULL,
  `41f_received_amount` decimal(10,2) NOT NULL,
  `41f_discount_amount` decimal(10,2) NOT NULL,
  `41f_given_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `41f_receipt_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan_copies`
--

CREATE TABLE `eg_bahan_copies` (
  `id` int(11) NOT NULL,
  `eg_bahan_id` int(11) NOT NULL,
  `39accessnum` varchar(150) NOT NULL,
  `39status` varchar(255) NOT NULL,
  `39invoice_a` varchar(255) NOT NULL DEFAULT '0.00',
  `39invoice_b` varchar(255) NOT NULL,
  `39invoice_c` varchar(255) NOT NULL,
  `39addedon` varchar(255) DEFAULT NULL,
  `39lastchange` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan_det`
--

CREATE TABLE `eg_bahan_det` (
  `id` int(11) NOT NULL,
  `eg_bahan_id` int(11) NOT NULL,
  `39logdate` varchar(25) NOT NULL,
  `39ipaddr` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_bahan_isbn`
--

CREATE TABLE `eg_bahan_isbn` (
  `id` int(11) NOT NULL,
  `eg_bahan_id` int(11) NOT NULL,
  `isbn1` varchar(255) NOT NULL,
  `isbn2` varchar(255) NOT NULL,
  `isbn3` varchar(255) NOT NULL,
  `isbn4` varchar(255) NOT NULL,
  `isbn5` varchar(255) NOT NULL,
  `isbn6` varchar(255) NOT NULL,
  `isbn7` varchar(255) NOT NULL,
  `isbn8` varchar(255) NOT NULL,
  `isbn9` varchar(255) NOT NULL,
  `isbn10` varchar(255) NOT NULL,
  `isbn11` varchar(255) NOT NULL,
  `isbn12` varchar(255) NOT NULL,
  `isbn13` varchar(255) NOT NULL,
  `isbn14` varchar(255) NOT NULL,
  `isbn15` varchar(255) NOT NULL,
  `isbn16` varchar(255) NOT NULL,
  `isbn17` varchar(255) NOT NULL,
  `isbn18` varchar(255) NOT NULL,
  `isbn19` varchar(255) NOT NULL,
  `isbn20` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_holiday`
--

CREATE TABLE `eg_holiday` (
  `id` int(11) NOT NULL,
  `38hol_title` varchar(255) NOT NULL,
  `38hol_date` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_jenisbahan`
--

CREATE TABLE `eg_jenisbahan` (
  `38typeid` int(4) NOT NULL,
  `38type` varchar(50) NOT NULL,
  `38subjectheadingflag` varchar(5) DEFAULT NULL,
  `38defaultlocation` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_jenisbahan`
--

INSERT INTO `eg_jenisbahan` (`38typeid`, `38type`, `38subjectheadingflag`, `38defaultlocation`) VALUES
(1, 'Open Shelf', NULL, NULL),
(2, 'Red Spot', NULL, NULL),
(3, 'Management Encyclopedia', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `eg_jenisbahan_fines`
--

CREATE TABLE `eg_jenisbahan_fines` (
  `id` int(11) NOT NULL,
  `38typeid` int(11) NOT NULL,
  `39fines_initdays` int(11) NOT NULL,
  `39fines_initamount` varchar(150) NOT NULL,
  `39fines_subsequenceamount` varchar(150) NOT NULL,
  `40enforcedon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_jenisbahan_fines`
--

INSERT INTO `eg_jenisbahan_fines` (`id`, `38typeid`, `39fines_initdays`, `39fines_initamount`, `39fines_subsequenceamount`, `40enforcedon`) VALUES
(1, 1, 7, '0.50', '1.00', '1370109805'),
(2, 2, 7, '1', '5', '1542603568'),
(3, 3, 7, '1', '5', '1542603577');

-- --------------------------------------------------------

--
-- Table structure for table `eg_subjectheading`
--

CREATE TABLE `eg_subjectheading` (
  `43subjectid` int(11) NOT NULL,
  `43typeref` int(5) DEFAULT NULL,
  `43acronym` varchar(255) NOT NULL,
  `43subject` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

--
-- Dumping data for table `eg_subjectheading`
--

INSERT INTO `eg_subjectheading` (`43subjectid`, `43typeref`, `43acronym`, `43subject`) VALUES
(1, 0, '000', 'Computer Science, knowledge and system'),
(2, 0, '010', 'Bibliographies'),
(3, 0, '020', 'Library and information sciences'),
(4, 0, '030', 'Encyclopaedias and books of facts'),
(5, 0, '050', 'Magazines, journals and serials'),
(6, 0, '060', 'Associations, organizations and museums'),
(7, 0, '070', 'News media, journalism and publishing'),
(8, 0, '080', 'General knowledge'),
(9, 0, '090', 'Manuscripts and rare books'),
(10, 0, '100', 'Philosophy and Psychology'),
(11, 0, '110', 'Metaphysics'),
(12, 0, '120', 'Epistemology, causation and humankind '),
(13, 0, '130', 'Parapsychology and occultism '),
(14, 0, '140', 'Specific philosophical schools '),
(15, 0, '150', 'Psychology'),
(16, 0, '160', 'Philosophical logic '),
(17, 0, '170', 'Ethics '),
(18, 0, '180', 'Ancient, medieval, and eastern philosophy'),
(19, 0, '190', 'Modern western philosophy'),
(20, 0, '200', 'Religion '),
(21, 0, '210', 'Philosophy and theory of religion'),
(22, 0, '220', 'Bible '),
(23, 0, '230', 'Christianity'),
(24, 0, '240', 'Christian moral and devotional theology'),
(25, 0, '250', 'Christian orders and local church '),
(26, 0, '260', 'Social and ecclesiastical theology '),
(27, 0, '270', 'History, geography, biography of Christianity '),
(28, 0, '280', 'Christian denominations and sects'),
(29, 0, '290', 'Other religions'),
(30, 0, '300', 'Social sciences '),
(31, 0, '310', 'Collections of general statistics'),
(32, 0, '320', 'Political science'),
(33, 0, '330', 'Economics'),
(34, 0, '340', 'Law'),
(35, 0, '350', 'Public administration & military science'),
(36, 0, '360', 'Social problems and services'),
(37, 0, '370', 'Education'),
(38, 0, '380', 'Commerce, communications, transportation'),
(39, 0, '390', 'Customs, etiquette, folklore'),
(40, 0, '400', 'Language '),
(41, 0, '410', 'Linguistics'),
(42, 0, '420', 'English and Old English language'),
(43, 0, '430', 'German and related languages'),
(44, 0, '440', 'French and related languages '),
(45, 0, '450', 'Italian, Romanian and related languages'),
(46, 0, '460', 'Spanish, Portuguese, Galician '),
(47, 0, '470', 'Latin and related Italic language'),
(48, 0, '480', 'Classical Greek and related languages'),
(49, 0, '490', 'Other languages'),
(50, 0, '500', 'Science'),
(51, 0, '510', 'Mathematics'),
(52, 0, '520', 'Astronomy and allied sciences'),
(53, 0, '530', 'Physics'),
(54, 0, '540', 'Chemistry and allied sciences'),
(55, 0, '550', 'Earth sciences'),
(56, 0, '560', 'Palaeontology'),
(57, 0, '570', 'Biology'),
(58, 0, '580', 'Plants (Botany)'),
(59, 0, '590', 'Animals (Zoology)'),
(60, 0, '600', 'Technology'),
(61, 0, '610', 'Medicine and health'),
(62, 0, '620', 'Engineering and allied operations'),
(63, 0, '630', 'Agriculture and related technologies'),
(64, 0, '640', 'Home economics, catering'),
(65, 0, '650', 'Management'),
(66, 0, '660', 'Chemical engineering, food technology'),
(67, 0, '670', 'Manufacturing'),
(68, 0, '680', 'Manufacture for specific uses'),
(69, 0, '690', 'Construction of buildings'),
(70, 0, '700', 'Arts and recreation'),
(71, 0, '710', 'Planning and landscape architecture'),
(72, 0, '720', 'Architecture'),
(73, 0, '730', 'Sculpture and related arts'),
(74, 0, '740', 'Graphic arts and decorative arts'),
(75, 0, '750', 'Painting and paintings'),
(76, 0, '760', 'Printmaking and prints'),
(77, 0, '770', 'Photography, computer art, film, video'),
(78, 0, '780', 'Music'),
(79, 0, '790', 'Recreational and performing arts, sport'),
(80, 0, '800', 'Literature'),
(81, 0, '810', 'American literature'),
(82, 0, '820', 'English and Old English literatures'),
(83, 0, '830', 'German and related literatures'),
(84, 0, '840', 'French and related literatures'),
(85, 0, '850', 'Italian, Romanian and related literatures'),
(86, 0, '860', 'Spanish, Portuguese, Galician literatures'),
(87, 0, '870', 'Latin and Italic literatures'),
(88, 0, '880', 'Classical Greek and related Literatures'),
(89, 0, '890', 'Literature of other languages'),
(90, 0, '900', 'History and geography'),
(91, 0, '910', 'Geography and travel'),
(92, 0, '920', 'Biography'),
(93, 0, '930', 'History of the ancient world'),
(94, 0, '940', 'History of Europe'),
(95, 0, '950', 'History of Asia'),
(96, 0, '960', 'History of Africa'),
(97, 0, '970', 'History of North America'),
(98, 0, '980', 'History of South America'),
(99, 0, '990', 'History of Other Areas');

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog`
--

CREATE TABLE `eg_userlog` (
  `id` int(11) NOT NULL,
  `37keyword` varchar(255) NOT NULL,
  `37type` varchar(20) NOT NULL DEFAULT 'All Type',
  `37freq` int(11) NOT NULL,
  `37lastlog` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_userlog_det`
--

CREATE TABLE `eg_userlog_det` (
  `id` int(11) NOT NULL,
  `38keyword` varchar(255) NOT NULL,
  `38logdate` varchar(25) NOT NULL,
  `38ipaddr` varchar(15) DEFAULT NULL,
  `38type` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eg_working_days`
--

CREATE TABLE `eg_working_days` (
  `id` int(1) NOT NULL,
  `mon` int(1) NOT NULL DEFAULT 0,
  `tue` int(1) NOT NULL DEFAULT 0,
  `wed` int(1) NOT NULL DEFAULT 0,
  `thu` int(1) NOT NULL DEFAULT 0,
  `fri` int(1) NOT NULL DEFAULT 0,
  `sat` int(1) NOT NULL DEFAULT 0,
  `sun` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_swedish_ci ROW_FORMAT=COMPRESSED;

--
-- Dumping data for table `eg_working_days`
--

INSERT INTO `eg_working_days` (`id`, `mon`, `tue`, `wed`, `thu`, `fri`, `sat`, `sun`) VALUES
(1, 1, 1, 1, 1, 1, 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `eg_auth`
--
ALTER TABLE `eg_auth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_auth_allowedloan`
--
ALTER TABLE `eg_auth_allowedloan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_id` (`usertype`);

--
-- Indexes for table `eg_bahan`
--
ALTER TABLE `eg_bahan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `40lastupdateby` (`40lastupdateby`),
  ADD KEY `40inputby` (`40inputby`) USING BTREE,
  ADD KEY `39subjectheading` (`39subjectheading`) USING BTREE;
ALTER TABLE `eg_bahan` ADD FULLTEXT KEY `38title` (`38title`);
ALTER TABLE `eg_bahan` ADD FULLTEXT KEY `38author` (`38author`);
ALTER TABLE `eg_bahan` ADD FULLTEXT KEY `50search_cloud` (`50search_cloud`);

--
-- Indexes for table `eg_bahan2`
--
ALTER TABLE `eg_bahan2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_bahan2_indicator`
--
ALTER TABLE `eg_bahan2_indicator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_bahan_charge`
--
ALTER TABLE `eg_bahan_charge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_bahan_copies`
--
ALTER TABLE `eg_bahan_copies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_bahan_det`
--
ALTER TABLE `eg_bahan_det`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_bahan_isbn`
--
ALTER TABLE `eg_bahan_isbn`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_holiday`
--
ALTER TABLE `eg_holiday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_jenisbahan`
--
ALTER TABLE `eg_jenisbahan`
  ADD PRIMARY KEY (`38typeid`),
  ADD KEY `38typeid` (`38typeid`);

--
-- Indexes for table `eg_jenisbahan_fines`
--
ALTER TABLE `eg_jenisbahan_fines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  ADD PRIMARY KEY (`43subjectid`);

--
-- Indexes for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `eg_working_days`
--
ALTER TABLE `eg_working_days`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `eg_auth`
--
ALTER TABLE `eg_auth`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `eg_auth_allowedloan`
--
ALTER TABLE `eg_auth_allowedloan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `eg_bahan`
--
ALTER TABLE `eg_bahan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan2`
--
ALTER TABLE `eg_bahan2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan2_indicator`
--
ALTER TABLE `eg_bahan2_indicator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan_charge`
--
ALTER TABLE `eg_bahan_charge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan_copies`
--
ALTER TABLE `eg_bahan_copies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan_det`
--
ALTER TABLE `eg_bahan_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_bahan_isbn`
--
ALTER TABLE `eg_bahan_isbn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_holiday`
--
ALTER TABLE `eg_holiday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_jenisbahan`
--
ALTER TABLE `eg_jenisbahan`
  MODIFY `38typeid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `eg_jenisbahan_fines`
--
ALTER TABLE `eg_jenisbahan_fines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `eg_subjectheading`
--
ALTER TABLE `eg_subjectheading`
  MODIFY `43subjectid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `eg_userlog`
--
ALTER TABLE `eg_userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `eg_userlog_det`
--
ALTER TABLE `eg_userlog_det`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
